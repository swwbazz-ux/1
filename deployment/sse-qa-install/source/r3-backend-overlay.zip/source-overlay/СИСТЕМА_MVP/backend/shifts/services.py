from collections import defaultdict
import hashlib
import json
from datetime import timedelta, timezone as datetime_timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core import signing
from django.db import IntegrityError, OperationalError, connection, transaction
from django.db.models import Count, F, Q, Sum
from django.utils import timezone

from core.db_locks import lock_idempotency_key
from core.production_time import (
    assigned_shift_open_bounds,
    production_day_bounds,
    production_work_date_for_shift,
)
from trips.models import Trip, TripStatus

from .equipment_plan_groups import equipment_garage_number_int
from .models import (
    DriverShiftReadingConfirmation,
    EmployeeShift,
    ExcavatorShiftReadingConfirmation,
    EquipmentPlanGroup,
    EquipmentShiftPlan,
    PlanAssignmentStatus,
    PlanCalculationMode,
    ShiftPlan,
    ShiftPlanScope,
    ShiftClientAction,
    ShiftReadingCorrection,
    WatchPeriod,
)


DRIVER_SHIFT_READING_FIELDS = (
    ('start_fuel', 'end_fuel', ShiftReadingCorrection.Metric.FUEL),
    ('start_mileage', 'end_mileage', ShiftReadingCorrection.Metric.MILEAGE),
    ('start_engine_hours', 'end_engine_hours', ShiftReadingCorrection.Metric.ENGINE_HOURS),
)

DRIVER_SHIFT_CLOSE_CONFIRMATION_SALT = 'shifts.driver-close-readings.v1'
EXCAVATOR_SHIFT_CLOSE_CONFIRMATION_SALT = 'shifts.excavator-close-readings.v1'
MAX_SHIFT_READING_VALUE = Decimal('99999999')


class DriverShiftCloseConfirmationRequired(Exception):
    def __init__(self, *, warnings, confirmation_token):
        super().__init__('Подтвердите подозрительные показания.')
        self.warnings = warnings
        self.confirmation_token = confirmation_token


class DriverShiftCloseIdempotencyConflict(ValidationError):
    pass


def driver_open_shift_queryset(employee):
    """Open driver shifts accepted by both the work screen and recovery truth.

    ``workplace_code`` was added after the first driver shifts existed. Keep
    the explicit driver code and the legacy empty-code truck shape in one
    domain helper so the screen and background voice recovery cannot drift.
    """
    return (
        EmployeeShift.objects
        .filter(employee=employee, closed_at__isnull=True)
        .filter(
            Q(workplace_code='driver')
            | Q(workplace_code='', equipment__equipment_type__name='Самосвал')
        )
    )


def _canonical_driver_close_reading(value):
    try:
        number = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return f'invalid:{str(value).strip()}'
    if not number.is_finite():
        return f'invalid:{str(value).strip()}'
    normalized = format(number, 'f')
    if '.' in normalized:
        normalized = normalized.rstrip('0').rstrip('.')
    return normalized or '0'


def _canonical_driver_close_time(value):
    if value in (None, ''):
        return ''
    if not hasattr(value, 'utcoffset') or timezone.is_naive(value):
        return f'invalid:{str(value).strip()}'
    return value.astimezone(datetime_timezone.utc).isoformat(timespec='milliseconds').replace('+00:00', 'Z')


def driver_close_request_signature(
    *, shift_id, employee_id, readings, occurred_at=None, actor_access_id=None,
):
    canonical = {
        'action_type': 'driver_shift_closed',
        'actor_access_id': str(actor_access_id or ''),
        'employee_id': str(employee_id),
        'occurred_at': _canonical_driver_close_time(occurred_at),
        'readings': {
            field: _canonical_driver_close_reading(readings.get(field))
            for field in ('end_fuel', 'end_mileage', 'end_engine_hours')
        },
        'shift_id': str(shift_id),
    }
    encoded = json.dumps(canonical, ensure_ascii=True, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(encoded.encode('utf-8')).hexdigest()


def ensure_driver_close_action_matches(action, request_signature, employee_id):
    if action.employee_id != employee_id:
        raise DriverShiftCloseIdempotencyConflict(
            'ID закрытия смены уже принадлежит другому водителю.'
        )
    # Legacy rows have no signature. Preserve their previous idempotent behavior;
    # every newly created row is protected against payload reuse.
    if action.request_signature and action.request_signature != request_signature:
        raise DriverShiftCloseIdempotencyConflict(
            'ID закрытия смены повторно использован с другими данными.'
        )


class ExcavatorShiftCloseConfirmationRequired(Exception):
    def __init__(self, *, warnings, confirmation_token):
        super().__init__('Подтвердите подозрительные показания.')
        self.warnings = warnings
        self.confirmation_token = confirmation_token


def recent_shift_reading_corrections(*, work_date=None, limit=None):
    corrections = (
        ShiftReadingCorrection.objects
        .select_related(
            'equipment',
            'equipment__equipment_type',
            'previous_shift',
            'previous_shift__employee',
            'new_shift',
            'new_shift__employee',
            'employee',
        )
        .order_by('-corrected_at', '-id')
    )
    if work_date is not None:
        production_start, production_end = production_day_bounds(work_date)
        corrections = corrections.filter(
            corrected_at__gte=production_start,
            corrected_at__lt=production_end,
        )
    if limit is not None:
        corrections = corrections[:limit]
    return list(corrections)


def lock_active_employee_for_shift(employee, *, role_code):
    from users.models import Employee, EmployeeAccess

    locked_employee = Employee.objects.select_for_update().get(pk=employee.pk)
    if not locked_employee.is_active or locked_employee.status != Employee.Status.ACTIVE:
        raise ValidationError('Сотрудник неактивен или уволен. Начало смены недоступно.')
    active_access = (
        EmployeeAccess.objects.select_for_update(of=('self',))
        .filter(
            employee=locked_employee,
            role__code=role_code,
            role__is_active=True,
            status=EmployeeAccess.Status.ACTIVATED,
            is_active=True,
        )
        .order_by('id')
        .first()
    )
    if not active_access:
        raise ValidationError('Активированный доступ сотрудника не найден. Начало смены недоступно.')
    return locked_employee


def open_shift_conflict_message(shift, *, equipment=None):
    if shift is not None:
        equipment = shift.equipment or equipment
        employee_name = str(shift.employee.full_name).strip()
        sentence_end = '' if employee_name.endswith('.') else '.'
        return (
            f'Смена на технике {equipment} уже открыта сотрудником '
            f'{employee_name}{sentence_end}'
        )
    return f'Смена на технике {equipment} уже открыта другим сотрудником.'


# Одна открытая смена на сотрудника во всех контурах (unique_open_shift_per_employee).
# Когда один человек с несколькими ролями открывает смену в новой роли, а в
# старой она ещё открыта, все экраны предлагают одно и то же: «завершить её и
# начать» — вместо отказа (или, как у мастера до 10.09.2026, белого экрана 500).
WORKPLACE_ROLE_LABELS = {
    'driver': 'Водитель',
    'excavator_operator': 'Машинист экскаватора',
    'dispatcher': 'Горный диспетчер',
    'mining_master': 'Горный мастер',
    'oup': 'ОУП',
}
WORKPLACE_ROLE_LABELS_GENITIVE = {
    'driver': 'Водителя',
    'excavator_operator': 'Машиниста экскаватора',
    'dispatcher': 'Горного диспетчера',
    'mining_master': 'Горного мастера',
    'oup': 'ОУП',
}
OTHER_ROLE_SHIFT_OPEN_CODE = 'other_role_shift_open'
OTHER_ROLE_SHIFT_FIELD = 'close_other_role_shift'


def workplace_role_label(workplace_code):
    return WORKPLACE_ROLE_LABELS.get(workplace_code or '', 'другая роль')


def other_role_shift_prompt(shift, *, target_workplace_code):
    """Текст вопроса и данные для окна «Завершить её и начать смену …?»."""
    opened_at = timezone.localtime(shift.opened_at)
    label = workplace_role_label(shift.workplace_code)
    target = WORKPLACE_ROLE_LABELS_GENITIVE.get(target_workplace_code, 'этой роли')
    return {
        'shift_id': shift.pk,
        'workplace_code': shift.workplace_code,
        'workplace_label': label,
        'opened_at_label': opened_at.strftime('%H:%M'),
        'opened_date_label': opened_at.strftime('%d.%m.%Y'),
        'question': (
            f'У вас открыта смена «{label}» с {opened_at:%H:%M}. '
            f'Завершить её и начать смену {target}?'
        ),
        'message': (
            f'У вас открыта смена «{label}» с {opened_at:%H:%M}. '
            f'Подтвердите её завершение, чтобы начать смену {target}.'
        ),
        'accept_label': 'Завершить и начать',
        'field': OTHER_ROLE_SHIFT_FIELD,
    }


class OtherRoleShiftOpen(ValidationError):
    """У сотрудника открыта смена в другой роли, а подтверждения на её закрытие нет."""

    def __init__(self, shift, *, target_workplace_code):
        self.shift = shift
        self.prompt = other_role_shift_prompt(shift, target_workplace_code=target_workplace_code)
        super().__init__(self.prompt['message'], code=OTHER_ROLE_SHIFT_OPEN_CODE)


def find_other_role_open_shift(employee, *, workplace_code, for_update=True):
    """Открытая смена сотрудника в другой роли (пустой workplace_code — старые
    записи, их роль неизвестна, поэтому они не считаются «другой ролью»)."""
    queryset = EmployeeShift.objects.select_related('employee', 'equipment', 'equipment__equipment_type')
    if for_update:
        queryset = queryset.select_for_update(of=('self',))
    return (
        queryset
        .filter(employee=employee, closed_at__isnull=True)
        .exclude(workplace_code__in=[workplace_code, ''])
        .order_by('-opened_at')
        .first()
    )


def handover_other_role_shift(shift, *, closed_by):
    """Служебно закрыть смену в другой роли по подтверждению самого сотрудника.

    Конечные показания техники не запрашиваются — их некому и негде ввести на
    экране другой роли; смена помечается служебным закрытием, как при закрытии
    диспетчером, незавершённые рейсы уходят в перенос."""
    now = timezone.now()
    shift.closed_at = now
    shift.closed_by = closed_by
    shift.is_service_closed = True
    shift.save(update_fields=['closed_at', 'closed_by', 'is_service_closed'])
    from trips.free_bucket import cancel_free_bucket_acceptances_for_shift
    cancel_free_bucket_acceptances_for_shift(shift, cancelled_at=now)
    from downtimes.driver_workflow import close_workflow_downtimes
    close_workflow_downtimes(shift.equipment, ended_at=now)
    from trips.models import OPEN_TRIP_STATUSES
    if shift.equipment_id:
        if equipment_is_truck(shift.equipment):
            Trip.objects.filter(truck=shift.equipment, status__in=OPEN_TRIP_STATUSES).update(is_carryover=True)
            from reports.driver_shift_passport_snapshots import enqueue_driver_shift_passport_capture
            from reports.models import DriverShiftPassportTrigger

            enqueue_driver_shift_passport_capture(
                shift=shift,
                trigger=DriverShiftPassportTrigger.SERVICE_CLOSE,
                captured_by=closed_by,
            )
        else:
            Trip.objects.filter(loading_shift=shift, status__in=OPEN_TRIP_STATUSES).update(is_carryover=True)
    from core.models import bump_operational_state

    bump_operational_state(
        'EmployeeShift:handover_closed',
        event_type='shift_handover_closed',
        object_type='EmployeeShift',
        object_id=shift.pk,
        payload={
            'employee_id': shift.employee_id,
            'workplace_code': shift.workplace_code,
            'equipment_id': shift.equipment_id,
        },
    )
    return shift


def resolve_other_role_shift(employee, *, workplace_code, close_other, closed_by):
    """Перед созданием смены: чужой по роли смены нет — None; есть и
    подтверждено — закрыть и вернуть её; есть без подтверждения — OtherRoleShiftOpen."""
    other_shift = find_other_role_open_shift(employee, workplace_code=workplace_code)
    if other_shift is None:
        return None
    if not close_other:
        raise OtherRoleShiftOpen(other_shift, target_workplace_code=workplace_code)
    return handover_other_role_shift(other_shift, closed_by=closed_by)


def other_role_shift_flag(payload):
    """Флаг подтверждения из формы или JSON: '1', 'true', True."""
    value = payload.get(OTHER_ROLE_SHIFT_FIELD) if payload is not None else None
    if isinstance(value, bool):
        return value
    return str(value or '').strip().lower() in {'1', 'true', 'yes', 'on'}


def shift_reading_is_whole(value):
    if value is None:
        return True
    try:
        parsed = Decimal(value)
    except (InvalidOperation, TypeError, ValueError):
        return False
    return parsed.is_finite() and parsed == parsed.to_integral_value()


def validate_driver_fuel_reading(equipment, value):
    if value is None:
        raise ValidationError('Укажите остаток топлива.')
    if value < 0:
        raise ValidationError('Остаток топлива не может быть отрицательным.')
    if not shift_reading_is_whole(value):
        raise ValidationError('Укажите целый остаток топлива без точки и запятой.')
    limit = getattr(getattr(equipment, 'model', None), 'fuel_capacity_limit_l', None)
    if limit is None:
        raise ValidationError('Для модели этого самосвала не настроен максимальный остаток топлива.')
    if value > limit:
        raise ValidationError(f'Остаток топлива не может превышать {limit:g} л для этой модели.')


def validate_driver_close_readings(shift, *, end_fuel, end_mileage, end_engine_hours):
    errors = {}
    for field_name, value in (
        ('end_fuel', end_fuel),
        ('end_mileage', end_mileage),
        ('end_engine_hours', end_engine_hours),
    ):
        if value is None:
            errors[field_name] = 'Укажите показание на конец смены.'
        elif not shift_reading_is_whole(value):
            errors[field_name] = 'Укажите целое число без точки и запятой.'
    for field_name, value in (
        ('end_fuel', end_fuel),
        ('end_mileage', end_mileage),
        ('end_engine_hours', end_engine_hours),
    ):
        if field_name not in errors and value < 0:
            errors[field_name] = 'Показание не может быть отрицательным.'
    fuel_limit = getattr(getattr(shift.equipment, 'model', None), 'fuel_capacity_limit_l', None)
    if 'end_fuel' not in errors and fuel_limit is None:
        errors['end_fuel'] = 'Для модели этого самосвала не настроена вместимость топливного бака.'
    if errors:
        raise ValidationError(errors)


def _driver_reading_token_value(value):
    if value is None:
        return None
    return format(Decimal(value), 'f')


def _driver_reading_display(value):
    if value is None:
        return 'не указано'
    normalized = Decimal(value)
    if normalized == normalized.to_integral_value():
        return f'{int(normalized):,}'.replace(',', ' ')
    return format(normalized.normalize(), 'f')


def driver_close_reading_warnings(shift, *, end_fuel, end_mileage, end_engine_hours):
    """Return business warnings only; malformed readings stay ValidationError."""
    validate_driver_close_readings(
        shift,
        end_fuel=end_fuel,
        end_mileage=end_mileage,
        end_engine_hours=end_engine_hours,
    )
    warnings = []
    fuel_limit = Decimal(shift.equipment.model.fuel_capacity_limit_l)
    if end_fuel > fuel_limit:
        warnings.append({
            'code': 'fuel_above_capacity',
            'field': 'end_fuel',
            'title': 'Топливо выше вместимости бака',
            'message': (
                f'Вместимость бака: {_driver_reading_display(fuel_limit)} л. '
                f'Введено: {_driver_reading_display(end_fuel)} л. '
                f'Превышение: {_driver_reading_display(end_fuel - fuel_limit)} л.'
            ),
        })

    if shift.start_mileage is None:
        warnings.append({
            'code': 'mileage_start_missing',
            'field': 'end_mileage',
            'title': 'Нет начального показания одометра',
            'message': (
                'В смене отсутствует пробег на начало. '
                f'Введено на конец: {_driver_reading_display(end_mileage)} км; сравнить разницу невозможно.'
            ),
        })
    else:
        start_mileage = Decimal(shift.start_mileage)
        mileage_delta = end_mileage - start_mileage
        if mileage_delta < 0:
            warnings.append({
                'code': 'mileage_decreased',
                'field': 'end_mileage',
                'title': 'Одометр меньше начального показания',
                'message': (
                    f'Пробег на начало: {_driver_reading_display(start_mileage)} км. '
                    f'Введено: {_driver_reading_display(end_mileage)} км. '
                    f'Разница: {_driver_reading_display(mileage_delta)} км.'
                ),
            })
        elif mileage_delta > Decimal('250'):
            warnings.append({
                'code': 'mileage_delta_high',
                'field': 'end_mileage',
                'title': 'Пробег за смену больше 250 км',
                'message': (
                    f'Пробег на начало: {_driver_reading_display(start_mileage)} км. '
                    f'Введено: {_driver_reading_display(end_mileage)} км. '
                    f'Разница: {_driver_reading_display(mileage_delta)} км.'
                ),
            })

    if shift.start_engine_hours is None:
        warnings.append({
            'code': 'engine_hours_start_missing',
            'field': 'end_engine_hours',
            'title': 'Нет начального показания моточасов',
            'message': (
                'В смене отсутствуют моточасы на начало. '
                f'Введено на конец: {_driver_reading_display(end_engine_hours)} м/ч; сравнить разницу невозможно.'
            ),
        })
    else:
        start_engine_hours = Decimal(shift.start_engine_hours)
        engine_hours_delta = end_engine_hours - start_engine_hours
        if engine_hours_delta < 0:
            warnings.append({
                'code': 'engine_hours_decreased',
                'field': 'end_engine_hours',
                'title': 'Моточасы меньше начального показания',
                'message': (
                    f'Моточасы на начало: {_driver_reading_display(start_engine_hours)} м/ч. '
                    f'Введено: {_driver_reading_display(end_engine_hours)} м/ч. '
                    f'Разница: {_driver_reading_display(engine_hours_delta)} м/ч.'
                ),
            })
        elif engine_hours_delta > Decimal('12'):
            warnings.append({
                'code': 'engine_hours_delta_high',
                'field': 'end_engine_hours',
                'title': 'Моточасы за смену выросли больше чем на 12',
                'message': (
                    f'Моточасы на начало: {_driver_reading_display(start_engine_hours)} м/ч. '
                    f'Введено: {_driver_reading_display(end_engine_hours)} м/ч. '
                    f'Разница: {_driver_reading_display(engine_hours_delta)} м/ч.'
                ),
            })
    return warnings


def _driver_close_confirmation_payload(shift, employee, readings, client_action_id, warnings):
    fuel_limit = getattr(getattr(shift.equipment, 'model', None), 'fuel_capacity_limit_l', None)
    return {
        'version': 1,
        'employee_id': employee.pk,
        'shift_id': shift.pk,
        'client_action_id': client_action_id,
        'readings': {
            field_name: _driver_reading_token_value(value)
            for field_name, value in readings.items()
        },
        'start_readings': {
            'start_fuel': _driver_reading_token_value(shift.start_fuel),
            'start_mileage': _driver_reading_token_value(shift.start_mileage),
            'start_engine_hours': _driver_reading_token_value(shift.start_engine_hours),
        },
        'fuel_capacity_limit_l': _driver_reading_token_value(fuel_limit),
        'warning_codes': [warning['code'] for warning in warnings],
    }


def issue_driver_close_confirmation(shift, employee, readings, client_action_id, warnings):
    return signing.dumps(
        _driver_close_confirmation_payload(shift, employee, readings, client_action_id, warnings),
        salt=DRIVER_SHIFT_CLOSE_CONFIRMATION_SALT,
        compress=True,
    )


def validate_driver_close_confirmation(token, shift, employee, readings, client_action_id, warnings):
    max_age = getattr(settings, 'DRIVER_SHIFT_CLOSE_CONFIRMATION_MAX_AGE_SECONDS', 30 * 60)
    try:
        signed_payload = signing.loads(
            token,
            salt=DRIVER_SHIFT_CLOSE_CONFIRMATION_SALT,
            max_age=max_age,
        )
    except signing.SignatureExpired as error:
        raise ValidationError('Подтверждение истекло. Проверьте показания ещё раз.') from error
    except signing.BadSignature as error:
        raise ValidationError('Подтверждение повреждено или не принадлежит этой смене.') from error
    expected_payload = _driver_close_confirmation_payload(
        shift,
        employee,
        readings,
        client_action_id,
        warnings,
    )
    if signed_payload != expected_payload:
        raise ValidationError('Показания изменились. Получите новое подтверждение.')


def _existing_driver_shift_action(action_type, client_action_id):
    action = ShiftClientAction.objects.select_related('shift').filter(
        action_type=action_type,
        client_action_id=client_action_id,
    ).first()
    return action.shift if action else None


def _try_lock_watch_period_catalog_for_snapshot():
    """Keep the catalog stable without making a driver wait for a catalog writer."""
    from users.models import WatchComposition

    if connection.vendor != 'postgresql':
        return True
    if not connection.in_atomic_block:
        raise RuntimeError('Watch-period snapshot requires an atomic transaction.')
    table_names = ', '.join(
        connection.ops.quote_name(model._meta.db_table)
        for model in (WatchComposition, WatchPeriod)
    )
    try:
        # The savepoint restores the outer shift transaction after SQLSTATE
        # 55P03. A successful table lock survives savepoint release and stays
        # until the surrounding shift transaction commits.
        with transaction.atomic():
            with connection.cursor() as cursor:
                cursor.execute(f'LOCK TABLE {table_names} IN SHARE MODE NOWAIT')
    except OperationalError as error:
        cause = error.__cause__
        sqlstate = (
            getattr(cause, 'sqlstate', None)
            or getattr(cause, 'pgcode', None)
        )
        if sqlstate == '55P03':
            return False
        raise
    return True


def resolve_published_watch_period_for_shift(
    *,
    employee,
    equipment,
    shift_type,
    role_code,
    opened_at,
):
    """Return the roster-backed watch snapshot for the deputy's published plan."""
    from assignments.models import CrewPlanSlot, CrewPlanStatus, WorkShiftType

    if shift_type not in WorkShiftType.values:
        return None
    if not employee.watch_composition_id:
        return None
    work_date = production_work_date_for_shift(opened_at, shift_type)
    is_published_placement = CrewPlanSlot.objects.filter(
        plan__work_date=work_date,
        plan__role__code=role_code,
        plan__status=CrewPlanStatus.PUBLISHED,
        plan__published_at__isnull=False,
        plan__published_at__lte=opened_at,
        plan__published_by__accesses__role__code='deputy_mining_manager',
        plan__published_by__accesses__role__is_active=True,
        plan__published_by__accesses__status='activated',
        plan__published_by__accesses__is_active=True,
        plan__published_by__accesses__created_at__lte=F('plan__published_at'),
        plan__published_by__status='active',
        plan__published_by__is_active=True,
        employee=employee,
        equipment=equipment,
        shift_type=shift_type,
    ).exists()
    if not is_published_placement:
        return None

    if not _try_lock_watch_period_catalog_for_snapshot():
        return None
    candidates = list(
        WatchPeriod.objects
        .filter(
            watch_composition_id=employee.watch_composition_id,
            watch_composition__is_active=True,
            is_active=True,
            starts_on__lte=work_date,
            ends_on__gte=work_date,
        )
        .order_by('id')[:2]
    )
    if len(candidates) != 1:
        return None
    return candidates[0]


def open_driver_shift(*, employee, work_assignment, readings, client_action_id, close_other_role_shift=False):
    existing_shift = _existing_driver_shift_action('driver_shift_opened', client_action_id)
    if existing_shift:
        return existing_shift, False
    from references.models import Equipment
    try:
        with transaction.atomic():
            lock_idempotency_key('driver_shift_opened', client_action_id)
            existing_shift = _existing_driver_shift_action('driver_shift_opened', client_action_id)
            if existing_shift:
                return existing_shift, False
            employee = lock_active_employee_for_shift(employee, role_code='driver')
            from assignments.models import AssignmentStatus, EquipmentAssignment
            locked_assignment = (
                EquipmentAssignment.objects
                .select_for_update(of=('self',))
                .select_related('equipment', 'equipment__model', 'role')
                .filter(
                    pk=work_assignment.pk,
                    employee=employee,
                    role__code='driver',
                    status=AssignmentStatus.ACCEPTED,
                    ended_at__isnull=True,
                    shift__isnull=True,
                    shift_type__isnull=False,
                    equipment__is_active=True,
                )
                .first()
            )
            if not locked_assignment:
                raise ValidationError(
                    'Назначение изменилось. Обновите экран перед началом смены.'
                )
            equipment = (
                Equipment.objects
                .select_for_update(of=('self',))
                .select_related('model')
                .get(pk=locked_assignment.equipment_id)
            )
            resolve_other_role_shift(
                employee,
                workplace_code='driver',
                close_other=close_other_role_shift,
                closed_by=employee,
            )
            employee_open_shift = (
                EmployeeShift.objects
                .select_related('employee', 'equipment', 'equipment__equipment_type')
                .filter(employee=employee, closed_at__isnull=True)
                .order_by('id')
                .first()
            )
            if employee_open_shift:
                raise ValidationError(open_shift_conflict_message(employee_open_shift))
            equipment_open_shift = (
                EmployeeShift.objects
                .select_related('employee', 'equipment', 'equipment__equipment_type')
                .filter(equipment=equipment, closed_at__isnull=True)
                .order_by('id')
                .first()
            )
            if equipment_open_shift:
                raise ValidationError(open_shift_conflict_message(equipment_open_shift))
            reading_errors = {}
            for field_name in ('start_fuel', 'start_mileage', 'start_engine_hours'):
                value = readings.get(field_name)
                if not shift_reading_is_whole(value):
                    reading_errors[field_name] = 'Укажите целое число без точки и запятой.'
            if reading_errors:
                raise ValidationError(reading_errors)
            validate_driver_fuel_reading(equipment, readings['start_fuel'])
            previous_shift = EmployeeShift.objects.filter(
                equipment=equipment, closed_at__isnull=False,
            ).order_by('-closed_at').first()
            opened_at = timezone.now()
            watch_period = resolve_published_watch_period_for_shift(
                employee=employee,
                equipment=equipment,
                shift_type=locked_assignment.shift_type,
                role_code='driver',
                opened_at=opened_at,
            )
            shift = EmployeeShift.objects.create(
                employee=employee,
                opened_by=employee,
                shift_type=locked_assignment.shift_type,
                workplace_code='driver',
                watch_period=watch_period,
                equipment=equipment,
                opened_at=opened_at,
                **readings,
            )
            assign_shift_plan_snapshot(shift)
            corrections = []
            if previous_shift:
                for start_field, end_field, metric in DRIVER_SHIFT_READING_FIELDS:
                    inherited = getattr(previous_shift, end_field)
                    actual = getattr(shift, start_field)
                    if inherited is not None and actual != inherited:
                        corrections.append(ShiftReadingCorrection(
                            equipment=equipment,
                            new_shift=shift,
                            previous_shift=previous_shift,
                            metric=metric,
                            transferred_value=inherited,
                            actual_value=actual,
                            employee=employee,
                        ))
                ShiftReadingCorrection.objects.bulk_create(corrections)
            response = {'ok': True, 'shift_id': shift.pk, 'truck_id': equipment.pk, 'driver_id': employee.pk}
            ShiftClientAction.objects.create(
                action_type='driver_shift_opened',
                client_action_id=client_action_id,
                employee=employee,
                shift=shift,
                response_payload=response,
            )
            from core.models import bump_operational_state
            if corrections:
                bump_operational_state(
                    'DriverShift:readings_corrected', event_type='shift_readings_corrected',
                    object_type='EmployeeShift', object_id=shift.pk,
                    payload={**response, 'previous_shift_id': previous_shift.pk, 'fields': [item.metric for item in corrections]},
                )
            bump_operational_state(
                'DriverShift:opened', event_type='driver_shift_opened', object_type='EmployeeShift', object_id=shift.pk,
                payload=response,
            )
            return shift, True
    except IntegrityError as error:
        existing_shift = _existing_driver_shift_action('driver_shift_opened', client_action_id)
        if existing_shift:
            return existing_shift, False
        equipment_open_shift = (
            EmployeeShift.objects
            .select_related('employee', 'equipment', 'equipment__equipment_type')
            .filter(equipment=work_assignment.equipment, closed_at__isnull=True)
            .order_by('id')
            .first()
        )
        raise ValidationError(
            open_shift_conflict_message(
                equipment_open_shift,
                equipment=work_assignment.equipment,
            )
        ) from error


def close_driver_shift(
    *, shift, employee, readings, client_action_id, confirmation_token='',
    occurred_at=None, actor_access_id=None, request_signature=None,
):
    request_signature = request_signature or driver_close_request_signature(
        shift_id=shift.pk,
        employee_id=employee.pk,
        actor_access_id=actor_access_id,
        readings=readings,
        occurred_at=occurred_at,
    )
    existing_action = ShiftClientAction.objects.select_related('shift').filter(
        action_type='driver_shift_closed',
        client_action_id=client_action_id,
    ).first()
    if existing_action:
        ensure_driver_close_action_matches(existing_action, request_signature, employee.pk)
        return existing_action.shift, False
    from references.models import Equipment
    from trips.models import OPEN_TRIP_STATUSES
    from users.models import Employee
    with transaction.atomic():
        lock_idempotency_key('driver_shift_closed', client_action_id)
        existing_action = ShiftClientAction.objects.select_related('shift').filter(
            action_type='driver_shift_closed',
            client_action_id=client_action_id,
        ).first()
        if existing_action:
            ensure_driver_close_action_matches(existing_action, request_signature, employee.pk)
            return existing_action.shift, False
        Employee.objects.select_for_update().get(pk=employee.pk)
        locked_shift = EmployeeShift.objects.select_for_update(of=('self',)).select_related('equipment__model').get(pk=shift.pk)
        Equipment.objects.select_for_update().get(pk=locked_shift.equipment_id)
        if locked_shift.employee_id != employee.pk:
            raise ValidationError('Смена не принадлежит этому водителю.')
        if locked_shift.closed_at:
            raise ValidationError('Смена уже закрыта.')
        validate_driver_close_readings(locked_shift, **readings)
        warnings = driver_close_reading_warnings(locked_shift, **readings)
        if confirmation_token:
            validate_driver_close_confirmation(
                confirmation_token,
                locked_shift,
                employee,
                readings,
                client_action_id,
                warnings,
            )
        elif warnings:
            raise DriverShiftCloseConfirmationRequired(
                warnings=warnings,
                confirmation_token=issue_driver_close_confirmation(
                    locked_shift,
                    employee,
                    readings,
                    client_action_id,
                    warnings,
                ),
            )
        for field, value in readings.items():
            setattr(locked_shift, field, value)
        received_at = timezone.now()
        device_occurred_at = occurred_at
        closed_at = occurred_at or received_at
        clock_adjusted = False
        if timezone.is_naive(closed_at):
            raise ValidationError('Время закрытия смены должно содержать часовой пояс.')
        if closed_at > received_at + timedelta(minutes=5):
            closed_at = received_at
            clock_adjusted = True
        if closed_at < locked_shift.opened_at:
            # A close request for this still-open shift cannot legitimately
            # precede its opening. If the server receives it while the shift is
            # open, use the receipt time and retain the device value in the
            # idempotent action response for audit.
            if received_at >= locked_shift.opened_at:
                closed_at = received_at
                clock_adjusted = True
            else:
                raise ValidationError('Время закрытия смены раньше времени открытия смены.')
        locked_shift.closed_at = closed_at
        locked_shift.closed_by = employee
        locked_shift.save(update_fields=[*readings, 'closed_at', 'closed_by'])
        from trips.free_bucket import cancel_free_bucket_acceptances_for_shift
        cancel_free_bucket_acceptances_for_shift(locked_shift, cancelled_at=closed_at)
        from downtimes.driver_workflow import close_workflow_downtimes
        close_workflow_downtimes(locked_shift.equipment, ended_at=locked_shift.closed_at)
        Trip.objects.filter(
            truck=locked_shift.equipment,
            status__in=OPEN_TRIP_STATUSES,
        ).update(is_carryover=True)
        from reports.driver_shift_passport_snapshots import (
            enqueue_driver_shift_passport_capture,
        )
        from reports.models import DriverShiftPassportTrigger

        enqueue_driver_shift_passport_capture(
            shift=locked_shift,
            trigger=DriverShiftPassportTrigger.DRIVER_CLOSE,
            captured_by=employee,
        )
        response = {
            'ok': True, 'shift_id': locked_shift.pk, 'truck_id': locked_shift.equipment_id, 'driver_id': employee.pk,
            'anomalous_readings_confirmed': bool(warnings),
            'device_clock_adjusted': clock_adjusted,
            'device_occurred_at': (
                device_occurred_at.isoformat() if device_occurred_at else None
            ),
            'effective_occurred_at': closed_at.isoformat(),
            'time_source': 'server_receipt' if clock_adjusted or device_occurred_at is None else 'driver_device',
        }
        ShiftClientAction.objects.create(
            action_type='driver_shift_closed', client_action_id=client_action_id,
            employee=employee, shift=locked_shift, response_payload=response,
            request_signature=request_signature,
        )
        if warnings:
            DriverShiftReadingConfirmation.objects.create(
                shift=locked_shift,
                employee=employee,
                client_action_id=client_action_id,
                start_fuel=locked_shift.start_fuel,
                start_mileage=locked_shift.start_mileage,
                start_engine_hours=locked_shift.start_engine_hours,
                end_fuel=readings['end_fuel'],
                end_mileage=readings['end_mileage'],
                end_engine_hours=readings['end_engine_hours'],
                warnings=warnings,
            )
        from core.models import bump_operational_state
        bump_operational_state(
            'DriverShift:closed', event_type='driver_shift_closed', object_type='EmployeeShift', object_id=locked_shift.pk,
            payload=response,
        )
        return locked_shift, True


def decimal_zero():
    return Decimal('0')


def plan_status_label(status):
    labels = {
        PlanAssignmentStatus.ASSIGNED: 'План назначен',
        PlanAssignmentStatus.NO_PLAN_GROUP: 'Нет группы плана',
        PlanAssignmentStatus.NO_ACTIVE_PLAN: 'Нет активного плана',
        'plan_not_assigned': 'План не назначен',
        'legacy_plan': 'План из старой схемы',
    }
    return labels.get(status or '', 'Нет плана')


def plan_unit_label(calculation_mode):
    if calculation_mode == PlanCalculationMode.TRIPS:
        return 'рейсов'
    if calculation_mode == PlanCalculationMode.VOLUME:
        return 'м³'
    if calculation_mode == PlanCalculationMode.TONNAGE:
        return 'т'
    return ''


def percent(fact, plan):
    if not plan or Decimal(plan) <= 0:
        return None
    return ((Decimal(fact or 0) / Decimal(plan)) * Decimal('100')).quantize(Decimal('0.1'))


def format_progress_percent(value):
    if value is None:
        return None
    try:
        value = Decimal(value)
    except Exception:
        return None
    return int(max(Decimal('0'), value).quantize(Decimal('1')))


def progress_cycle_visual_context(percent):
    value = format_progress_percent(percent)
    if value is None:
        value = 0

    completed_loops, loop_progress = divmod(value, 100)
    # Keep an exact completed boundary visible as a finished active cycle.
    # This prevents the indicator from jumping from 99% to an empty ring.
    if value and loop_progress == 0:
        loop_progress = 100
        completed_loops = max(0, completed_loops - 1)

    if not value:
        # Факта нет — красить нечего. Иначе минимальная видимая заливка на
        # плитке (max(--tile-progress, 7%)) читается как «рейс уже отвезли».
        phase = ''
    elif completed_loops == 0:
        phase = 'green'
    elif completed_loops == 1:
        phase = 'amber'
    elif completed_loops == 2:
        phase = 'cyan'
    else:
        phase = 'orange'
    return {
        'percent': value,
        'loop_progress': loop_progress,
        'completed_loops': completed_loops,
        'phase': phase,
        'has_completed_loops': completed_loops > 0,
        'is_overrun': completed_loops > 0,
        'text_class': '',
    }


def empty_progress(equipment, date=None, shift_type=None, *, status=PlanAssignmentStatus.NO_PLAN_GROUP, shift=None):
    return {
        'equipment': equipment,
        'date': date,
        'shift_type': shift_type,
        'shift': shift,
        'plan': None,
        'plan_group': None,
        'plan_group_name': '',
        'plan_status': status,
        'calculation_mode': '',
        'plan_value': None,
        'trip_count': 0,
        'volume_m3': Decimal('0'),
        'tonnage': Decimal('0'),
        'progress_percent': None,
    }


def empty_shift_plan_totals_by_shift():
    return defaultdict(lambda: {
        'trips': 0,
        'volume_m3': decimal_zero(),
        'tonnage': decimal_zero(),
    })


def shift_plan_totals_for_dates(dates):
    dates = tuple(sorted(set(dates)))
    if not dates:
        return {}

    totals_by_date = {
        date: empty_shift_plan_totals_by_shift()
        for date in dates
    }
    production_start = production_day_bounds(dates[0])[0]
    production_end = production_day_bounds(dates[-1])[1]
    snapshot_shifts = (
        EmployeeShift.objects
        .filter(
            opened_at__gte=production_start - timedelta(days=1),
            opened_at__lt=production_end + timedelta(days=1),
            plan_status=PlanAssignmentStatus.ASSIGNED,
            plan_value__isnull=False,
        )
    )
    snapshot_dates = set()
    for shift in snapshot_shifts:
        work_date = production_work_date_for_shift(
            shift.opened_at,
            shift.shift_type,
        )
        if work_date not in totals_by_date:
            continue
        snapshot_dates.add(work_date)
        totals = totals_by_date[work_date]
        if shift.plan_calculation_mode == PlanCalculationMode.TRIPS:
            totals[shift.shift_type]['trips'] += int(shift.plan_value or 0)
        elif shift.plan_calculation_mode == PlanCalculationMode.VOLUME:
            totals[shift.shift_type]['volume_m3'] += shift.plan_value or Decimal('0')
        elif shift.plan_calculation_mode == PlanCalculationMode.TONNAGE:
            totals[shift.shift_type]['tonnage'] += shift.plan_value or Decimal('0')

    plan_dates = [date for date in dates if date not in snapshot_dates]
    plans = (
        ShiftPlan.objects
        .filter(
            date__in=plan_dates,
            is_active=True,
            plan_scope__in=[ShiftPlanScope.DAY_SHIFT, ShiftPlanScope.NIGHT_SHIFT],
        )
        .annotate(
            active_equipment_plan_count=Count(
                'equipment_plans',
                filter=Q(equipment_plans__is_active=True),
            ),
            equipment_plan_trips=Sum(
                'equipment_plans__plan_trips',
                filter=Q(equipment_plans__is_active=True),
            ),
            equipment_plan_volume_m3=Sum(
                'equipment_plans__plan_volume_m3',
                filter=Q(equipment_plans__is_active=True),
            ),
            equipment_plan_tonnage=Sum(
                'equipment_plans__plan_tonnage',
                filter=Q(equipment_plans__is_active=True),
            ),
        )
    )
    for shift_plan in plans:
        totals = totals_by_date[shift_plan.date]
        if shift_plan.active_equipment_plan_count:
            totals[shift_plan.shift_type]['trips'] += shift_plan.equipment_plan_trips or 0
            totals[shift_plan.shift_type]['volume_m3'] += shift_plan.equipment_plan_volume_m3 or Decimal('0')
            totals[shift_plan.shift_type]['tonnage'] += shift_plan.equipment_plan_tonnage or Decimal('0')
            continue

        totals[shift_plan.shift_type]['trips'] += shift_plan.plan_trips or 0
        totals[shift_plan.shift_type]['volume_m3'] += shift_plan.plan_volume_m3 or Decimal('0')
        totals[shift_plan.shift_type]['tonnage'] += shift_plan.plan_tonnage or Decimal('0')
    return {
        date: {
            'trips': sum(item['trips'] for item in by_shift.values()),
            'volume_m3': sum((item['volume_m3'] for item in by_shift.values()), Decimal('0')),
            'tonnage': sum((item['tonnage'] for item in by_shift.values()), Decimal('0')),
            'by_shift': by_shift,
        }
        for date, by_shift in totals_by_date.items()
    }


def shift_plan_totals(date):
    return shift_plan_totals_for_dates([date])[date]


def get_equipment_shift_plan(equipment, date, shift_type):
    if not equipment or not date or not shift_type:
        return None
    return (
        EquipmentShiftPlan.objects
        .select_related('shift_plan', 'equipment', 'employee')
        .filter(
            equipment=equipment,
            is_active=True,
            shift_plan__date=date,
            shift_plan__shift_type=shift_type,
            shift_plan__is_active=True,
        )
        .first()
    )


def get_equipment_plan_group(equipment):
    if not equipment:
        return None
    return (
        EquipmentPlanGroup.objects
        .filter(equipment=equipment)
        .prefetch_related('equipment')
        .order_by('-is_active', '-active_from', 'name')
        .first()
    )


def assign_shift_plan_snapshot(shift):
    if not shift or not shift.equipment_id:
        if shift:
            shift.plan_assigned_at = timezone.now()
            shift.plan_group = None
            shift.plan_group_name = ''
            shift.plan_status = PlanAssignmentStatus.NO_PLAN_GROUP
            shift.plan_calculation_mode = ''
            shift.plan_value = None
            shift.save(update_fields=[
                'plan_group',
                'plan_group_name',
                'plan_calculation_mode',
                'plan_value',
                'plan_assigned_at',
                'plan_status',
            ])
        return empty_progress(None, shift=shift)

    group = get_equipment_plan_group(shift.equipment)
    shift_date = production_work_date_for_shift(
        shift.opened_at if shift.opened_at else timezone.now(),
        shift.shift_type,
    )
    shift.plan_assigned_at = timezone.now()
    shift.plan_group = group
    shift.plan_group_name = group.name if group else ''

    if not group:
        shift.plan_status = PlanAssignmentStatus.NO_PLAN_GROUP
        shift.plan_calculation_mode = ''
        shift.plan_value = None
    elif (
        not group.is_active
        or (group.active_from and group.active_from > shift_date)
        or not group.plan_value
        or Decimal(group.plan_value) <= 0
    ):
        shift.plan_status = PlanAssignmentStatus.NO_ACTIVE_PLAN
        shift.plan_calculation_mode = group.calculation_mode
        shift.plan_value = None
    else:
        shift.plan_status = PlanAssignmentStatus.ASSIGNED
        shift.plan_calculation_mode = group.calculation_mode
        shift.plan_value = group.plan_value

    shift.save(update_fields=[
        'plan_group',
        'plan_group_name',
        'plan_calculation_mode',
        'plan_value',
        'plan_assigned_at',
        'plan_status',
    ])
    return calculate_open_shift_progress(shift)


def refresh_open_shift_plan_snapshots_for_group(group):
    """Reassign the current plan to open shifts affected by a group save."""
    if not group or not group.pk:
        return 0

    current_equipment_ids = group.equipment.values_list('id', flat=True)
    open_shifts = (
        EmployeeShift.objects
        .select_related('equipment', 'equipment__equipment_type')
        .filter(closed_at__isnull=True)
        .filter(Q(plan_group_id=group.pk) | Q(equipment_id__in=current_equipment_ids))
        .distinct()
        .order_by('id')
    )
    updated_count = 0
    for shift in open_shifts:
        assign_shift_plan_snapshot(shift)
        updated_count += 1
    return updated_count


def equipment_is_excavator(equipment):
    return bool(equipment and equipment.equipment_type and 'экскаватор' in equipment.equipment_type.name.lower())


def equipment_is_truck(equipment):
    return bool(equipment and equipment.equipment_type and 'самосвал' in equipment.equipment_type.name.lower())


def equipment_shift_trip_queryset(equipment, date, shift_type):
    if not equipment or not date or not shift_type:
        return Trip.objects.none()

    assigned_start, assigned_end = assigned_shift_open_bounds(date, shift_type)
    shift_filter = {
        'shift_type': shift_type,
        'opened_at__gte': assigned_start,
        'opened_at__lt': assigned_end,
    }
    if equipment_is_excavator(equipment):
        query = Q(loading_shift__equipment=equipment, **{f'loading_shift__{key}': value for key, value in shift_filter.items()})
    else:
        query = Q(unloading_shift__equipment=equipment, **{f'unloading_shift__{key}': value for key, value in shift_filter.items()})
    trips = Trip.objects.filter(query)
    if equipment_is_excavator(equipment):
        return trips.exclude(status=TripStatus.CANCELLED)
    return trips.filter(status=TripStatus.COMPLETED)


def aggregate_trip_facts(trips):
    facts = trips.aggregate(
        trip_count=Count('id'),
        volume_m3=Sum('volume_m3'),
        tonnage=Sum('tonnage'),
    )
    return normalize_trip_facts(facts)


def normalize_trip_facts(facts=None):
    facts = facts or {}
    return {
        'trip_count': facts.get('trip_count') or 0,
        'volume_m3': facts.get('volume_m3') or Decimal('0'),
        'tonnage': facts.get('tonnage') or Decimal('0'),
    }


def aggregate_completed_trip_facts_by_shift(*, unloading_shift_ids=(), loading_shift_ids=()):
    """Return completed-trip facts for many shift snapshots in two grouped queries."""

    def grouped_facts(shift_field, shift_ids):
        shift_ids = tuple(dict.fromkeys(shift_id for shift_id in shift_ids if shift_id))
        if not shift_ids:
            return {}
        shift_key = f'{shift_field}_id'
        trips = Trip.objects.filter(**{f'{shift_key}__in': shift_ids})
        trips = trips.exclude(status=TripStatus.CANCELLED) if shift_field == 'loading_shift' else trips.filter(status=TripStatus.COMPLETED)
        rows = (
            trips
            .values(shift_key)
            .annotate(
                trip_count=Count('id'),
                volume_m3=Sum('volume_m3'),
                tonnage=Sum('tonnage'),
            )
        )
        return {
            row[shift_key]: normalize_trip_facts(row)
            for row in rows
        }

    return {
        'unloading': grouped_facts('unloading_shift', unloading_shift_ids),
        'loading': grouped_facts('loading_shift', loading_shift_ids),
    }


def calculate_progress_from_snapshot_facts(shift, facts=None):
    facts = normalize_trip_facts(facts)
    date = (
        production_work_date_for_shift(shift.opened_at, shift.shift_type)
        if shift and shift.opened_at
        else None
    )
    result = {
        'equipment': shift.equipment if shift else None,
        'date': date,
        'shift_type': shift.shift_type if shift else None,
        'shift': shift,
        'plan': None,
        'plan_group': shift.plan_group if shift else None,
        'plan_group_name': shift.plan_group_name if shift else '',
        'plan_status': shift.plan_status or PlanAssignmentStatus.NO_PLAN_GROUP,
        'calculation_mode': shift.plan_calculation_mode or '',
        'plan_value': shift.plan_value,
        **facts,
        'progress_percent': None,
    }

    if result['plan_status'] != PlanAssignmentStatus.ASSIGNED:
        return result

    if shift.plan_calculation_mode == PlanCalculationMode.TRIPS:
        progress_percent = percent(result['trip_count'], shift.plan_value)
    elif shift.plan_calculation_mode == PlanCalculationMode.TONNAGE:
        progress_percent = percent(result['tonnage'], shift.plan_value)
    else:
        progress_percent = percent(result['volume_m3'], shift.plan_value)
    result['progress_percent'] = progress_percent
    return result


def calculate_progress_from_snapshot(shift, trips):
    return calculate_progress_from_snapshot_facts(shift, aggregate_trip_facts(trips))


def calculate_progress_from_trip_queryset(equipment, date, shift_type, trips):
    plan = get_equipment_shift_plan(equipment, date, shift_type)
    facts = aggregate_trip_facts(trips)
    trip_count = facts['trip_count']
    volume_m3 = facts['volume_m3']
    tonnage = facts['tonnage']

    if not plan:
        return {
            'equipment': equipment,
            'date': date,
            'shift_type': shift_type,
            'shift': None,
            'plan': None,
            'plan_group': None,
            'plan_group_name': '',
            'plan_status': PlanAssignmentStatus.NO_ACTIVE_PLAN,
            'calculation_mode': '',
            'plan_value': None,
            'trip_count': trip_count,
            'volume_m3': volume_m3,
            'tonnage': tonnage,
            'progress_percent': None,
        }

    trip_percent = percent(trip_count, plan.plan_trips)
    volume_percent = percent(volume_m3, plan.plan_volume_m3)
    tonnage_percent = percent(tonnage, plan.plan_tonnage)
    if plan.calculation_mode == PlanCalculationMode.TRIPS:
        progress_percent = trip_percent
    elif plan.calculation_mode == PlanCalculationMode.TONNAGE:
        progress_percent = tonnage_percent
    elif plan.calculation_mode == PlanCalculationMode.MIXED:
        available = [value for value in (trip_percent, volume_percent, tonnage_percent) if value is not None]
        progress_percent = (sum(available, Decimal('0')) / len(available)).quantize(Decimal('0.1')) if available else None
    else:
        progress_percent = volume_percent

    return {
        'equipment': equipment,
        'date': date,
        'shift_type': shift_type,
        'shift': None,
        'plan': plan,
        'plan_group': None,
        'plan_group_name': '',
        'plan_status': 'legacy_plan',
        'calculation_mode': plan.calculation_mode,
        'plan_value': (
            plan.plan_trips
            if plan.calculation_mode == PlanCalculationMode.TRIPS
            else plan.plan_tonnage
            if plan.calculation_mode == PlanCalculationMode.TONNAGE
            else plan.plan_volume_m3
        ),
        'trip_count': trip_count,
        'volume_m3': volume_m3,
        'tonnage': tonnage,
        'progress_percent': progress_percent,
    }


def calculate_equipment_shift_progress(equipment, date, shift_type):
    trips = equipment_shift_trip_queryset(equipment, date, shift_type)
    return calculate_progress_from_trip_queryset(equipment, date, shift_type, trips)


def calculate_truck_shift_progress(truck, reference_shift=None):
    if not truck:
        return None
    if reference_shift and getattr(reference_shift, 'equipment_id', None) == getattr(truck, 'id', None):
        trips = Trip.objects.filter(
            status=TripStatus.COMPLETED,
            truck=truck,
            unloading_shift=reference_shift,
        )
        return calculate_progress_from_snapshot(reference_shift, trips)
    truck_shift = (
        EmployeeShift.objects
        .filter(equipment=truck, closed_at__isnull=True)
        .select_related('equipment', 'equipment__equipment_type', 'plan_group')
        .order_by('-opened_at')
        .first()
    )
    if truck_shift:
        trips = Trip.objects.filter(
            status=TripStatus.COMPLETED,
            truck=truck,
            unloading_shift=truck_shift,
        )
        return calculate_progress_from_snapshot(truck_shift, trips)

    if reference_shift and reference_shift.opened_at and reference_shift.shift_type:
        date = production_work_date_for_shift(
            reference_shift.opened_at,
            reference_shift.shift_type,
        )
        return calculate_equipment_shift_progress(truck, date, reference_shift.shift_type)
    return empty_progress(truck, status=PlanAssignmentStatus.NO_PLAN_GROUP)


def calculate_open_shift_progress(open_shift):
    if not open_shift:
        return None
    if open_shift.plan_status:
        if equipment_is_excavator(open_shift.equipment):
            trips = Trip.objects.filter(loading_shift=open_shift).exclude(status=TripStatus.CANCELLED)
        else:
            trips = Trip.objects.filter(status=TripStatus.COMPLETED, unloading_shift=open_shift)
        return calculate_progress_from_snapshot(open_shift, trips)

    return calculate_equipment_shift_progress(
        open_shift.equipment,
        production_work_date_for_shift(open_shift.opened_at, open_shift.shift_type),
        open_shift.shift_type,
    )


class ExcavatorShiftError(Exception):
    def __init__(self, message, *, field_errors=None, status=400, code='invalid_readings', extra=None):
        super().__init__(message)
        self.message = message
        self.field_errors = field_errors or {}
        self.status = status
        self.code = code
        # Дополнительные данные ответа (например, вопрос «завершить и начать»).
        self.extra = extra or {}


def parse_required_shift_integer(value, label, field_name):
    raw = str(value if value is not None else '').strip().replace('\u00a0', '').replace(' ', '').replace(',', '.')
    if not raw:
        raise ExcavatorShiftError(
            f'{label}: укажите значение.',
            field_errors={field_name: f'Укажите значение «{label.lower()}».'},
        )
    try:
        parsed = Decimal(raw)
    except (InvalidOperation, ValueError):
        parsed = None
    if parsed is None or not parsed.is_finite():
        raise ExcavatorShiftError(
            f'{label}: укажите корректное число.',
            field_errors={field_name: 'Введите корректное число.'},
        )
    if parsed < 0:
        raise ExcavatorShiftError(
            f'{label}: значение не может быть меньше нуля.',
            field_errors={field_name: 'Значение не может быть меньше нуля.'},
        )
    if parsed != parsed.to_integral_value():
        raise ExcavatorShiftError(
            f'{label}: нужно указать целое число.',
            field_errors={field_name: 'Укажите целое число без точки и запятой.'},
        )
    # EmployeeShift stores these readings in DecimalField(max_digits=10,
    # decimal_places=2): at most eight digits are available before the point.
    if parsed > MAX_SHIFT_READING_VALUE:
        raise ExcavatorShiftError(
            f'{label}: значение слишком большое.',
            field_errors={field_name: 'Укажите значение не больше 99 999 999.'},
        )
    try:
        return parsed.quantize(Decimal('1'))
    except InvalidOperation:
        raise ExcavatorShiftError(
            f'{label}: значение имеет недопустимый формат.',
            field_errors={field_name: 'Введите корректное целое число.'},
        )


def excavator_fuel_limit(equipment):
    model = getattr(equipment, 'model', None)
    limit = getattr(model, 'fuel_capacity_limit_l', None)
    if limit is None:
        raise ExcavatorShiftError(
            'Для модели этого экскаватора не настроен допустимый объем топлива. Обратитесь к администратору.',
            field_errors={'fuel': 'Лимит топлива для модели не настроен.'},
            status=409,
            code='fuel_limit_not_configured',
        )
    return Decimal(limit)


def excavator_fuel_capacity_l(equipment):
    garage_number = equipment_garage_number_int(equipment)
    if garage_number in {1, 8}:
        return Decimal('7450')
    if garage_number in {2, 3, 4, 5, 6, 7}:
        return Decimal('5700')
    configured_limit = getattr(getattr(equipment, 'model', None), 'fuel_capacity_limit_l', None)
    return Decimal(configured_limit) if configured_limit is not None else Decimal('0')


def excavator_fuel_liters_from_percent(equipment, percent_value, *, allow_above_100=False):
    percent = parse_required_shift_integer(percent_value, 'Топливо, %', 'fuel')
    if percent > Decimal('100') and not allow_above_100:
        raise ExcavatorShiftError(
            'Топливо не может превышать 100%.',
            field_errors={'fuel': 'Укажите значение от 0 до 100%.'},
        )
    capacity = excavator_fuel_capacity_l(equipment)
    if capacity <= 0:
        raise ExcavatorShiftError(
            'Для этого экскаватора не настроена вместимость топливного бака. Обратитесь к администратору.',
            field_errors={'fuel': 'Вместимость топливного бака не настроена.'},
            status=409,
            code='fuel_capacity_not_configured',
        )
    liters = (capacity * percent / Decimal('100')).quantize(Decimal('1'), rounding=ROUND_HALF_UP)
    if liters > MAX_SHIFT_READING_VALUE:
        raise ExcavatorShiftError(
            'Топливо: рассчитанное значение слишком большое.',
            field_errors={'fuel': 'Укажите процент, при котором объём не превышает 99 999 999 л.'},
        )
    return liters, percent, capacity


def validate_excavator_shift_readings(
    equipment,
    fuel_value,
    engine_hours_value,
    *,
    opening_shift=None,
    fuel_limit_override=None,
):
    fuel = parse_required_shift_integer(fuel_value, 'Топливо', 'fuel')
    engine_hours = parse_required_shift_integer(engine_hours_value, 'Моточасы', 'engine_hours')
    fuel_limit = Decimal(fuel_limit_override) if fuel_limit_override is not None else excavator_fuel_limit(equipment)
    if fuel > fuel_limit:
        raise ExcavatorShiftError(
            f'Топливо не может превышать {int(fuel_limit)} л для модели этого экскаватора.',
            field_errors={'fuel': f'Максимум для этой модели: {int(fuel_limit)} л.'},
        )
    if opening_shift is not None:
        start_hours = (
            opening_shift.start_engine_hours.to_integral_value(rounding=ROUND_HALF_UP)
            if opening_shift.start_engine_hours is not None
            else None
        )
        if start_hours is None:
            raise ExcavatorShiftError('В открытой смене отсутствуют начальные моточасы.', status=409)
        if engine_hours < start_hours:
            raise ExcavatorShiftError(
                'Конечные моточасы не могут быть меньше начальных.',
                field_errors={'engine_hours': f'Не меньше {start_hours}.'},
            )
        if engine_hours - start_hours > Decimal('12'):
            raise ExcavatorShiftError(
                'Моточасы за смену не могут увеличиться более чем на 12. Проверьте показания.',
                field_errors={'engine_hours': 'Допустимый прирост за смену: не более 12 моточасов.'},
            )
    return fuel, engine_hours


def validate_excavator_close_readings(
    equipment,
    fuel_value,
    engine_hours_value,
    *,
    fuel_limit_override=None,
):
    """Validate input shape only; plausible business anomalies require confirmation."""
    fuel = parse_required_shift_integer(fuel_value, 'Топливо', 'fuel')
    engine_hours = parse_required_shift_integer(engine_hours_value, 'Моточасы', 'engine_hours')
    fuel_limit = Decimal(fuel_limit_override) if fuel_limit_override is not None else excavator_fuel_limit(equipment)
    if fuel_limit <= 0:
        raise ExcavatorShiftError(
            'Для этого экскаватора не настроена вместимость топливного бака. Обратитесь к администратору.',
            field_errors={'fuel': 'Вместимость топливного бака не настроена.'},
            status=409,
            code='fuel_capacity_not_configured',
        )
    return fuel, engine_hours, fuel_limit


def excavator_close_reading_warnings(
    shift,
    *,
    end_fuel,
    end_engine_hours,
    fuel_capacity_l,
    submitted_fuel_percent=None,
):
    warnings = []
    fuel_capacity_l = Decimal(fuel_capacity_l)
    if end_fuel > fuel_capacity_l:
        warnings.append({
            'code': 'fuel_above_capacity',
            'field': 'fuel',
            'title': 'Топливо выше вместимости бака',
            'message': (
                f'Вместимость бака: {_driver_reading_display(fuel_capacity_l)} л. '
                + (
                    f'Введено: {_driver_reading_display(submitted_fuel_percent)}% '
                    f'({_driver_reading_display(end_fuel)} л). '
                    if submitted_fuel_percent is not None
                    else f'Введено: {_driver_reading_display(end_fuel)} л. '
                )
                + f'Превышение: {_driver_reading_display(end_fuel - fuel_capacity_l)} л.'
            ),
        })

    if shift.start_engine_hours is None:
        warnings.append({
            'code': 'engine_hours_start_missing',
            'field': 'engine_hours',
            'title': 'Нет начального показания моточасов',
            'message': (
                'В смене отсутствуют моточасы на начало. '
                f'Введено на конец: {_driver_reading_display(end_engine_hours)} м/ч; '
                'сравнить разницу невозможно.'
            ),
        })
    else:
        start_engine_hours = Decimal(shift.start_engine_hours)
        engine_hours_delta = end_engine_hours - start_engine_hours
        if engine_hours_delta < 0:
            warnings.append({
                'code': 'engine_hours_decreased',
                'field': 'engine_hours',
                'title': 'Моточасы меньше начального показания',
                'message': (
                    f'Моточасы на начало: {_driver_reading_display(start_engine_hours)} м/ч. '
                    f'Введено: {_driver_reading_display(end_engine_hours)} м/ч. '
                    f'Разница: {_driver_reading_display(engine_hours_delta)} м/ч.'
                ),
            })
        elif engine_hours_delta > Decimal('12'):
            warnings.append({
                'code': 'engine_hours_delta_high',
                'field': 'engine_hours',
                'title': 'Моточасы за смену выросли больше чем на 12',
                'message': (
                    f'Моточасы на начало: {_driver_reading_display(start_engine_hours)} м/ч. '
                    f'Введено: {_driver_reading_display(end_engine_hours)} м/ч. '
                    f'Разница: {_driver_reading_display(engine_hours_delta)} м/ч.'
                ),
            })
    return warnings


def _excavator_close_confirmation_payload(
    shift,
    employee,
    *,
    end_fuel,
    end_engine_hours,
    submitted_fuel_percent,
    fuel_capacity_l,
    client_action_id,
    warnings,
):
    return {
        'version': 1,
        'employee_id': employee.pk,
        'shift_id': shift.pk,
        'equipment_id': shift.equipment_id,
        'client_action_id': client_action_id,
        'readings': {
            'submitted_fuel_percent': _driver_reading_token_value(submitted_fuel_percent),
            'end_fuel': _driver_reading_token_value(end_fuel),
            'end_engine_hours': _driver_reading_token_value(end_engine_hours),
        },
        'start_readings': {
            'start_fuel': _driver_reading_token_value(shift.start_fuel),
            'start_engine_hours': _driver_reading_token_value(shift.start_engine_hours),
        },
        'fuel_capacity_l': _driver_reading_token_value(fuel_capacity_l),
        'warning_codes': [warning['code'] for warning in warnings],
    }


def issue_excavator_close_confirmation(shift, employee, **payload):
    return signing.dumps(
        _excavator_close_confirmation_payload(shift, employee, **payload),
        salt=EXCAVATOR_SHIFT_CLOSE_CONFIRMATION_SALT,
        compress=True,
    )


def validate_excavator_close_confirmation(token, shift, employee, **payload):
    max_age = getattr(settings, 'EXCAVATOR_SHIFT_CLOSE_CONFIRMATION_MAX_AGE_SECONDS', 30 * 60)
    try:
        signed_payload = signing.loads(
            token,
            salt=EXCAVATOR_SHIFT_CLOSE_CONFIRMATION_SALT,
            max_age=max_age,
        )
    except signing.SignatureExpired as error:
        raise ExcavatorShiftError(
            'Подтверждение истекло. Проверьте показания ещё раз.',
            status=422,
            code='confirmation_expired',
        ) from error
    except signing.BadSignature as error:
        raise ExcavatorShiftError(
            'Подтверждение повреждено или не принадлежит этой смене.',
            status=422,
            code='confirmation_invalid',
        ) from error
    expected_payload = _excavator_close_confirmation_payload(shift, employee, **payload)
    if signed_payload != expected_payload:
        raise ExcavatorShiftError(
            'Показания или смена изменились. Получите новое подтверждение.',
            status=422,
            code='confirmation_context_changed',
        )


def existing_shift_action_payload(
    action_type,
    client_action_id,
    *,
    employee=None,
    expected_shift_id=None,
    request_signature=None,
):
    action = ShiftClientAction.objects.filter(
        action_type=action_type,
        client_action_id=client_action_id,
    ).select_related('shift').first()
    if not action:
        return None
    if employee is not None and action.employee_id != employee.pk:
        raise ExcavatorShiftError(
            'ID действия уже принадлежит другому сотруднику.',
            status=409,
            code='client_action_conflict',
        )
    if expected_shift_id is not None and str(action.shift_id) != str(expected_shift_id):
        raise ExcavatorShiftError(
            'ID действия уже использован для другой смены.',
            status=409,
            code='client_action_conflict',
        )
    payload = dict(action.response_payload or {})
    stored_signature = payload.pop('_request_signature', None)
    if request_signature is not None and stored_signature != request_signature:
        raise ExcavatorShiftError(
            'ID действия уже использован с другими показаниями.',
            status=409,
            code='client_action_conflict',
        )
    payload['deduplicated'] = True
    return payload


def excavator_close_request_signature(*, fuel, engine_hours, submitted_fuel_percent):
    return {
        'fuel': _driver_reading_token_value(fuel),
        'engine_hours': _driver_reading_token_value(engine_hours),
        'submitted_fuel_percent': _driver_reading_token_value(submitted_fuel_percent),
    }


@transaction.atomic
def _open_excavator_shift_atomic(
    *,
    employee,
    equipment,
    shift_type,
    fuel_value,
    engine_hours_value,
    client_action_id,
    fuel_limit_override=None,
    close_other_role_shift=False,
):
    from references.models import Equipment

    action_type = 'excavator_shift_opened'
    existing = existing_shift_action_payload(action_type, client_action_id, employee=employee)
    if existing:
        return existing

    lock_idempotency_key(action_type, client_action_id)
    existing = existing_shift_action_payload(action_type, client_action_id, employee=employee)
    if existing:
        return existing

    try:
        employee = lock_active_employee_for_shift(employee, role_code='excavator_operator')
    except ValidationError as error:
        raise ExcavatorShiftError(
            '; '.join(error.messages),
            status=409,
            code='employee_inactive',
        ) from error
    equipment = Equipment.objects.select_for_update(of=('self',)).select_related('model', 'equipment_type').get(pk=equipment.pk)
    existing = existing_shift_action_payload(action_type, client_action_id, employee=employee)
    if existing:
        return existing

    try:
        resolve_other_role_shift(
            employee,
            workplace_code='excavator_operator',
            close_other=close_other_role_shift,
            closed_by=employee,
        )
    except OtherRoleShiftOpen as error:
        raise ExcavatorShiftError(
            error.prompt['message'],
            status=409,
            code=OTHER_ROLE_SHIFT_OPEN_CODE,
            extra={'other_role_shift': error.prompt},
        ) from error
    employee_open_shift = (
        EmployeeShift.objects
        .select_related('employee', 'equipment', 'equipment__equipment_type')
        .filter(employee=employee, closed_at__isnull=True)
        .order_by('id')
        .first()
    )
    if employee_open_shift:
        raise ExcavatorShiftError(
            open_shift_conflict_message(employee_open_shift),
            status=409,
            code='employee_shift_already_open',
        )
    equipment_open_shift = (
        EmployeeShift.objects
        .select_related('employee', 'equipment', 'equipment__equipment_type')
        .filter(equipment=equipment, closed_at__isnull=True)
        .order_by('id')
        .first()
    )
    if equipment_open_shift:
        raise ExcavatorShiftError(
            open_shift_conflict_message(equipment_open_shift),
            status=409,
            code='equipment_shift_already_open',
        )

    fuel, engine_hours = validate_excavator_shift_readings(
        equipment,
        fuel_value,
        engine_hours_value,
        fuel_limit_override=fuel_limit_override,
    )
    previous_shift = (
        EmployeeShift.objects.select_for_update(of=('self',))
        .filter(equipment=equipment, closed_at__isnull=False)
        .order_by('-closed_at', '-opened_at')
        .first()
    )
    shift = EmployeeShift.objects.create(
        employee=employee,
        equipment=equipment,
        shift_type=shift_type,
        workplace_code='excavator_operator',
        start_fuel=fuel,
        start_mileage=None,
        start_engine_hours=engine_hours,
        opened_at=timezone.now(),
        opened_by=employee,
    )
    shift_progress = assign_shift_plan_snapshot(shift)

    corrected_metrics = []
    if previous_shift:
        transferred_values = {
            ShiftReadingCorrection.Metric.FUEL: previous_shift.end_fuel,
            ShiftReadingCorrection.Metric.ENGINE_HOURS: previous_shift.end_engine_hours,
        }
        actual_values = {
            ShiftReadingCorrection.Metric.FUEL: fuel,
            ShiftReadingCorrection.Metric.ENGINE_HOURS: engine_hours,
        }
        for metric, transferred in transferred_values.items():
            if transferred is not None and transferred != actual_values[metric]:
                ShiftReadingCorrection.objects.create(
                    equipment=equipment,
                    new_shift=shift,
                    previous_shift=previous_shift,
                    metric=metric,
                    transferred_value=transferred,
                    actual_value=actual_values[metric],
                    employee=employee,
                )
                corrected_metrics.append(metric)

    if corrected_metrics:
        from core.models import bump_operational_state
        bump_operational_state(
            'excavator_shift_readings_corrected',
            event_type='excavator_shift_readings_corrected',
            object_type='EmployeeShift',
            object_id=shift.id,
            payload={
                'action': 'excavator_shift_readings_corrected',
                'shift_id': shift.id,
                'previous_shift_id': previous_shift.id,
                'equipment_id': equipment.id,
                'employee_id': employee.id,
                'metrics': corrected_metrics,
            },
        )

    response = {
        'ok': True,
        'action': action_type,
        'client_action_id': client_action_id,
        'shift_id': shift.id,
        'shift_open': True,
        'equipment_id': equipment.id,
        'plan_status': shift_progress.get('plan_status'),
        'plan_value': str(shift_progress.get('plan_value') or ''),
        'calculation_mode': shift_progress.get('calculation_mode') or '',
    }
    client_action = ShiftClientAction.objects.create(
        action_type=action_type,
        client_action_id=client_action_id,
        employee=employee,
        shift=shift,
        response_payload=response,
    )
    from core.models import bump_operational_state
    state = bump_operational_state(
        action_type,
        event_type=action_type,
        object_type='EmployeeShift',
        object_id=shift.id,
        payload={**response, 'employee_id': employee.id},
    )
    response['version'] = state.version
    client_action.response_payload = response
    client_action.save(update_fields=['response_payload'])
    return response


def open_excavator_shift(
    *,
    employee,
    equipment,
    shift_type,
    fuel_value,
    engine_hours_value,
    client_action_id,
    fuel_limit_override=None,
    close_other_role_shift=False,
):
    try:
        return _open_excavator_shift_atomic(
            employee=employee,
            equipment=equipment,
            shift_type=shift_type,
            fuel_value=fuel_value,
            engine_hours_value=engine_hours_value,
            client_action_id=client_action_id,
            fuel_limit_override=fuel_limit_override,
            close_other_role_shift=close_other_role_shift,
        )
    except IntegrityError as error:
        existing = existing_shift_action_payload(
            'excavator_shift_opened',
            client_action_id,
            employee=employee,
        )
        if existing:
            return existing
        equipment_open_shift = (
            EmployeeShift.objects
            .select_related('employee', 'equipment', 'equipment__equipment_type')
            .filter(equipment=equipment, closed_at__isnull=True)
            .order_by('id')
            .first()
        )
        employee_open_shift = (
            EmployeeShift.objects
            .select_related('employee', 'equipment', 'equipment__equipment_type')
            .filter(employee=employee, closed_at__isnull=True)
            .order_by('id')
            .first()
        )
        conflict_shift = equipment_open_shift or employee_open_shift
        if conflict_shift:
            raise ExcavatorShiftError(
                open_shift_conflict_message(conflict_shift, equipment=equipment),
                status=409,
                code=(
                    'equipment_shift_already_open'
                    if equipment_open_shift
                    else 'employee_shift_already_open'
                ),
            ) from error
        raise


@transaction.atomic
def close_excavator_shift(
    *,
    employee,
    fuel_value,
    engine_hours_value,
    client_action_id,
    fuel_limit_override=None,
    submitted_fuel_percent=None,
    confirmation_token='',
    expected_shift_id=None,
    occurred_at=None,
):
    from references.models import Equipment
    from trips.models import OPEN_TRIP_STATUSES, Trip
    from users.models import Employee

    action_type = 'excavator_shift_closed'
    if expected_shift_id is None or not str(expected_shift_id).strip():
        raise ExcavatorShiftError(
            'Не указан ID закрываемой смены. Обновите экран и повторите действие.',
            status=409,
            code='shift_context_required',
        )
    raw_shift_id = str(expected_shift_id).strip()
    if not raw_shift_id.isascii() or not raw_shift_id.isdigit():
        raise ExcavatorShiftError(
            'Некорректный ID закрываемой смены. Обновите экран и повторите действие.',
            status=400,
            code='invalid_shift_context',
        )
    expected_shift_id = int(raw_shift_id)
    if expected_shift_id <= 0 or expected_shift_id > 9223372036854775807:
        raise ExcavatorShiftError(
            'Некорректный ID закрываемой смены. Обновите экран и повторите действие.',
            status=400,
            code='invalid_shift_context',
        )

    lock_idempotency_key(action_type, client_action_id)
    Employee.objects.select_for_update().get(pk=employee.pk)
    shift = (
        EmployeeShift.objects.select_for_update(of=('self',))
        .select_related('equipment', 'equipment__model', 'equipment__equipment_type')
        .filter(pk=expected_shift_id, employee=employee)
        .filter(equipment__equipment_type__name='Экскаватор')
        .filter(
            Q(workplace_code='excavator_operator')
            | Q(workplace_code='')
        )
        .first()
    )
    if not shift:
        raise ExcavatorShiftError(
            'Смена на сервере уже изменилась. Обновите экран и проверьте её состояние.',
            status=409,
            code='shift_context_changed',
        )
    equipment = (
        Equipment.objects.select_for_update(of=('self',))
        .select_related('model', 'equipment_type')
        .get(pk=shift.equipment_id)
    )
    shift.equipment = equipment

    normalized_fuel_percent = None
    if submitted_fuel_percent is not None and str(submitted_fuel_percent).strip():
        fuel, normalized_fuel_percent, fuel_capacity_l = excavator_fuel_liters_from_percent(
            equipment,
            submitted_fuel_percent,
            allow_above_100=True,
        )
        if fuel_value is not None and str(fuel_value).strip():
            posted_fuel = parse_required_shift_integer(fuel_value, 'Топливо', 'fuel')
        else:
            posted_fuel = fuel
        if posted_fuel != fuel:
            raise ExcavatorShiftError(
                'Показание топлива изменилось. Повторите закрытие смены.',
                field_errors={'fuel': 'Проценты и рассчитанные литры не совпадают.'},
                status=422,
                code='fuel_reading_mismatch',
            )
        engine_hours = parse_required_shift_integer(engine_hours_value, 'Моточасы', 'engine_hours')
    else:
        fuel, engine_hours, fuel_capacity_l = validate_excavator_close_readings(
            equipment,
            fuel_value,
            engine_hours_value,
            fuel_limit_override=fuel_limit_override,
        )
    request_signature = excavator_close_request_signature(
        fuel=fuel,
        engine_hours=engine_hours,
        submitted_fuel_percent=normalized_fuel_percent,
    )
    existing = existing_shift_action_payload(
        action_type,
        client_action_id,
        employee=employee,
        expected_shift_id=expected_shift_id,
        request_signature=request_signature,
    )
    if existing:
        return existing
    if shift.closed_at:
        raise ExcavatorShiftError('Открытая смена уже закрыта.', status=409, code='shift_already_closed')
    warnings = excavator_close_reading_warnings(
        shift,
        end_fuel=fuel,
        end_engine_hours=engine_hours,
        fuel_capacity_l=fuel_capacity_l,
        submitted_fuel_percent=normalized_fuel_percent,
    )
    confirmation_payload = {
        'end_fuel': fuel,
        'end_engine_hours': engine_hours,
        'submitted_fuel_percent': normalized_fuel_percent,
        'fuel_capacity_l': fuel_capacity_l,
        'client_action_id': client_action_id,
        'warnings': warnings,
    }
    if confirmation_token:
        validate_excavator_close_confirmation(
            confirmation_token,
            shift,
            employee,
            **confirmation_payload,
        )
    elif warnings:
        raise ExcavatorShiftCloseConfirmationRequired(
            warnings=warnings,
            confirmation_token=issue_excavator_close_confirmation(
                shift,
                employee,
                **confirmation_payload,
            ),
        )
    shift.end_fuel = fuel
    shift.end_mileage = None
    shift.end_engine_hours = engine_hours
    received_at = timezone.now()
    closed_at = occurred_at or received_at
    if timezone.is_naive(closed_at):
        raise ExcavatorShiftError(
            'Время закрытия смены должно содержать часовой пояс.',
            status=422,
            code='invalid_occurred_at',
        )
    if closed_at < shift.opened_at:
        raise ExcavatorShiftError(
            'Время закрытия смены раньше времени открытия смены.',
            status=409,
            code='event_before_shift',
        )
    if closed_at > received_at + timedelta(minutes=5):
        raise ExcavatorShiftError(
            'Часы устройства заметно опережают сервер. Требуется сверка.',
            status=409,
            code='device_clock_ahead',
        )
    shift.closed_at = closed_at
    shift.closed_by = employee
    shift.save(update_fields=['end_fuel', 'end_mileage', 'end_engine_hours', 'closed_at', 'closed_by'])
    from trips.free_bucket import cancel_free_bucket_acceptances_for_shift
    cancel_free_bucket_acceptances_for_shift(shift, cancelled_at=closed_at)
    from downtimes.driver_workflow import close_workflow_downtimes
    close_workflow_downtimes(shift.equipment, ended_at=shift.closed_at)
    # Переходное право существует только до конца конкретной смены старого
    # экскаватора. После закрытия оно не должно всплыть в следующей смене.
    from assignments.services import expire_haul_handoffs_for_shift
    expire_haul_handoffs_for_shift(shift, now=shift.closed_at)
    Trip.objects.filter(loading_shift=shift, status__in=OPEN_TRIP_STATUSES).update(is_carryover=True)

    response = {
        'ok': True,
        'action': action_type,
        'client_action_id': client_action_id,
        'shift_id': shift.id,
        'shift_open': False,
        'anomalous_readings_confirmed': bool(warnings),
    }
    stored_response = {**response, '_request_signature': request_signature}
    client_action = ShiftClientAction.objects.create(
        action_type=action_type,
        client_action_id=client_action_id,
        employee=employee,
        shift=shift,
        response_payload=stored_response,
    )
    if warnings:
        ExcavatorShiftReadingConfirmation.objects.create(
            shift=shift,
            employee=employee,
            equipment=equipment,
            client_action_id=client_action_id,
            submitted_fuel_percent=normalized_fuel_percent,
            fuel_capacity_l=fuel_capacity_l,
            start_fuel=shift.start_fuel,
            start_engine_hours=shift.start_engine_hours,
            end_fuel=fuel,
            end_engine_hours=engine_hours,
            warnings=warnings,
        )
    from core.models import bump_operational_state
    state = bump_operational_state(
        action_type,
        event_type=action_type,
        object_type='EmployeeShift',
        object_id=shift.id,
        payload={**response, 'employee_id': employee.id, 'equipment_id': shift.equipment_id},
    )
    response['version'] = state.version
    stored_response['version'] = state.version
    client_action.response_payload = stored_response
    client_action.save(update_fields=['response_payload'])
    return response
