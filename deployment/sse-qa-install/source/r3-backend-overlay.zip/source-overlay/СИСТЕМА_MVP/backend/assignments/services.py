from datetime import timedelta

import hashlib
import logging
import os
from pathlib import Path
import threading
import tempfile
import time

from django.core.exceptions import ValidationError
from django.core.files import locks
from django.db import IntegrityError, connection, transaction
from django.db.models import F, Max, Q
from django.utils import timezone

logger = logging.getLogger(__name__)

from core.models import bump_operational_state, lock_production_state
from core.production_time import production_work_date as contract_production_work_date
from references.models import Equipment
from shifts.models import EmployeeShift
from users.models import Employee, EmployeeAccess, Role
from users.work_profiles import effective_specialization, employee_has_effective_access_role

from .models import (
    AssignmentStatus,
    CrewPlan,
    CrewPlanSlot,
    CrewPlanStatus,
    EquipmentAssignment,
    HaulAssignment,
    HaulAssignmentAction,
    HaulAssignmentHandoff,
    HaulAssignmentHandoffStatus,
    WorkShiftType,
)


HAUL_ASSIGNMENT_DELAY = timedelta(minutes=5)
HAUL_ASSIGNMENT_ZERO_DELAY_TRUCKS = frozenset({'ТЕСТ-1'})
WORK_ASSIGNMENT_ROLE_EQUIPMENT_TYPES = {
    'driver': 'Самосвал',
    'excavator_operator': 'Экскаватор',
}
CREW_PLAN_ROLE_CODES = frozenset(WORK_ASSIGNMENT_ROLE_EQUIPMENT_TYPES)


def haul_assignment_effective_at(truck, now):
    """Оставляет штатную паузу всем, кроме явно названной тестовой машины."""
    garage_number = str(getattr(truck, 'garage_number', '') or '').strip().upper()
    delay = (
        timedelta(0)
        if garage_number in HAUL_ASSIGNMENT_ZERO_DELAY_TRUCKS
        else HAUL_ASSIGNMENT_DELAY
    )
    return now + delay
CREW_SLOT_POSITION_PRIMARY = 'primary'
CREW_SLOT_POSITION_SECONDARY = 'secondary'
CREW_SLOT_POSITIONS = frozenset({
    CREW_SLOT_POSITION_PRIMARY,
    CREW_SLOT_POSITION_SECONDARY,
})


def _bulk_create_published_plan_assignments(assignments):
    assignments = list(assignments)
    for assignment in assignments:
        if (
            assignment.source_kind
            != EquipmentAssignment.SourceKind.DEPUTY_PUBLISHED_PLAN
            or assignment.source_crew_plan_slot_id is None
        ):
            raise ValidationError(
                'Публикация может создавать только назначения с точным официальным источником.',
                code='invalid_published_assignment_provenance',
            )
        assignment.full_clean()
    with transaction.atomic():
        return EquipmentAssignment._base_manager.bulk_create(assignments)


def production_work_date(now=None):
    """Return the date of the 07:00–07:00 production day."""
    return contract_production_work_date(now)


def _crew_plan_role(role):
    if isinstance(role, Role):
        resolved = role
    else:
        try:
            resolved = Role.objects.get(code=str(role or ''))
        except Role.DoesNotExist as error:
            raise ValidationError('Рабочая роль не найдена.', code='invalid_role') from error
    if resolved.code not in CREW_PLAN_ROLE_CODES:
        raise ValidationError('Для этой роли планирование экипажей не поддерживается.', code='invalid_role')
    if not resolved.is_active:
        raise ValidationError('Рабочая роль неактивна.', code='inactive_role')
    return resolved


def _crew_plan_instance(plan, *, for_update=False):
    plan_id = plan.pk if isinstance(plan, CrewPlan) else plan
    queryset = CrewPlan.objects.select_related('role')
    if for_update:
        queryset = queryset.select_for_update()
    try:
        return queryset.get(pk=plan_id)
    except CrewPlan.DoesNotExist as error:
        raise ValidationError('План расстановки не найден.', code='plan_not_found') from error


def _locked_deputy_publish_access(*, actor_access, actor):
    """Lock and verify the exact server-side deputy access before publication."""
    access_id = getattr(actor_access, 'pk', actor_access)
    try:
        access_snapshot = EmployeeAccess.objects.filter(pk=access_id).values(
            'pk', 'employee_id',
        ).get()
    except (EmployeeAccess.DoesNotExist, TypeError, ValueError) as error:
        raise ValidationError(
            'Активный доступ заместителя не найден.',
            code='deputy_access_required',
        ) from error
    locked_employee = Employee.objects.select_for_update().get(
        pk=access_snapshot['employee_id'],
    )
    access = (
        EmployeeAccess.objects.select_related('role')
        .select_for_update(of=('self',))
        .get(pk=access_snapshot['pk'])
    )
    actor_id = getattr(actor, 'pk', actor)
    if (
        access.employee_id != locked_employee.pk
        or actor_id not in (None, locked_employee.pk)
        or not access.is_active
        or access.status in {
            EmployeeAccess.Status.BLOCKED,
            EmployeeAccess.Status.DEACTIVATED,
        }
        or not locked_employee.is_active
        or locked_employee.status != Employee.Status.ACTIVE
        or not access.role.is_active
        or access.role.code != 'deputy_mining_manager'
    ):
        raise ValidationError(
            'Активный доступ заместителя не найден.',
            code='deputy_access_required',
        )
    return locked_employee, access


def _validate_current_crew_plan(plan):
    if plan.work_date != production_work_date():
        raise ValidationError(
            'Производственные сутки этого черновика уже завершены. Обновите страницу.',
            code='plan_work_date_closed',
        )


def _crew_plan_equipment(equipment):
    if isinstance(equipment, Equipment):
        return equipment
    try:
        return Equipment.objects.select_related(
            'equipment_type', 'model', 'contractor_organization'
        ).get(pk=equipment)
    except Equipment.DoesNotExist as error:
        raise ValidationError('Техника не найдена.', code='equipment_not_found') from error


def _crew_plan_employee(employee):
    if employee in (None, ''):
        return None
    if isinstance(employee, Employee):
        return employee
    try:
        return Employee.objects.get(pk=employee)
    except Employee.DoesNotExist as error:
        raise ValidationError('Сотрудник не найден.', code='employee_not_found') from error


def employee_matches_work_role(employee, role):
    return employee_has_effective_access_role(employee, role.code)


def secondary_employee_matches_work_role(employee, role):
    if role.code == 'driver':
        return employee_matches_work_role(employee, role)
    if role.code == 'excavator_operator':
        specialization = effective_specialization(employee)
        return bool(
            specialization
            and specialization.is_active
            and specialization.code == 'assistant_excavator_operator'
        )
    return False


def _validate_crew_employee(employee, role, *, position=CREW_SLOT_POSITION_PRIMARY):
    if not employee.is_active or employee.status != Employee.Status.ACTIVE:
        raise ValidationError('Сотрудник неактивен.', code='inactive_employee')
    if position not in CREW_SLOT_POSITIONS:
        raise ValidationError('Неизвестная позиция в экипаже.', code='invalid_crew_position')
    matches_position = (
        employee_matches_work_role(employee, role)
        if position == CREW_SLOT_POSITION_PRIMARY
        else secondary_employee_matches_work_role(employee, role)
    )
    if not matches_position:
        position_label = (
            'основной рабочей роли'
            if position == CREW_SLOT_POSITION_PRIMARY
            else ('стажёра' if role.code == 'driver' else 'помощника машиниста')
        )
        raise ValidationError(
            f'Производственная специализация сотрудника не соответствует позиции {position_label}.',
            code='invalid_work_category',
        )
    has_other_role_assignment = (
        EquipmentAssignment.objects
        .filter(
            employee=employee,
            status=AssignmentStatus.ACCEPTED,
            ended_at__isnull=True,
            shift__isnull=True,
            role__isnull=False,
            shift_type__in=WorkShiftType.values,
        )
        .exclude(role=role)
        .exists()
    )
    if has_other_role_assignment:
        raise ValidationError(
            'Сотрудник уже назначен по другой рабочей роли.',
            code='assignment_conflict',
        )


def validate_employee_equipment_organization(employee, equipment):
    """Подрядчик может работать только на технике своей организации."""
    if employee.employment_type != Employee.EmploymentType.CONTRACTOR:
        return
    if not employee.contractor_access_is_valid():
        raise ValidationError(
            'Допуск сотрудника подрядчика не действует.',
            code='contractor_access_expired',
        )
    if not equipment.contractor_organization_id:
        raise ValidationError(
            'Сотрудника подрядчика можно назначить только на подрядную технику его организации.',
            code='contractor_equipment_required',
        )
    if equipment.contractor_organization_id != employee.contractor_organization_id:
        raise ValidationError(
            'Организация сотрудника не совпадает с владельцем техники.',
            code='contractor_organization_mismatch',
        )


def _validate_crew_equipment(equipment, role):
    if not equipment_queryset_for_work_role(role.code).filter(pk=equipment.pk).exists():
        raise ValidationError(
            'Техника неактивна или не соответствует выбранной рабочей роли.',
            code='invalid_equipment',
        )


def _sync_crew_draft_equipment_slots(plan, *, actor=None, bump_version=True):
    """Reconcile an editable crew draft with the active equipment directory.

    Active equipment may legitimately arrive or leave during a watch. New
    equipment receives day/night slots. Equipment disabled in the directory is
    removed from the draft together with its slots, so its crew members return
    to the unassigned pool instead of blocking publication.
    """
    equipment = list(equipment_queryset_for_work_role(plan.role.code))
    active_equipment_ids = {item.id for item in equipment}
    obsolete_slots = plan.slots.exclude(equipment_id__in=active_equipment_ids)
    removed_slot_count = obsolete_slots.count()
    if removed_slot_count:
        obsolete_slots.delete()

    existing_slots = set(
        plan.slots.values_list('equipment_id', 'shift_type')
    )
    missing_equipment_ids = {
        item.id
        for item in equipment
        if any(
            (item.id, shift_type) not in existing_slots
            for shift_type in WorkShiftType.values
        )
    }
    if not missing_equipment_ids and not removed_slot_count:
        return 0

    active_assignments = (
        EquipmentAssignment.objects
        .filter(
            role=plan.role,
            equipment_id__in=missing_equipment_ids,
            shift_type__in=WorkShiftType.values,
            status=AssignmentStatus.ACCEPTED,
            ended_at__isnull=True,
            shift__isnull=True,
        )
        .order_by('-assigned_at', '-id')
    )
    baseline_by_slot = {}
    for assignment in active_assignments:
        baseline_by_slot.setdefault(
            (assignment.equipment_id, assignment.shift_type),
            assignment.employee_id,
        )

    published_plan = (
        CrewPlan.objects.filter(
            work_date=plan.work_date,
            role=plan.role,
            status=CrewPlanStatus.PUBLISHED,
        )
        .exclude(pk=plan.pk)
        .order_by('-revision')
        .first()
    )
    baseline_secondary_by_slot = {}
    if published_plan:
        baseline_secondary_by_slot = {
            (equipment_id, shift_type): employee_id
            for equipment_id, shift_type, employee_id in published_plan.slots.values_list(
                'equipment_id',
                'shift_type',
                'secondary_employee_id',
            )
        }

    used_employee_ids = set(
        plan.slots.exclude(employee_id__isnull=True).values_list('employee_id', flat=True)
    )
    used_employee_ids.update(
        plan.slots.exclude(secondary_employee_id__isnull=True).values_list(
            'secondary_employee_id',
            flat=True,
        )
    )
    slots = []
    for item in equipment:
        if item.id not in missing_equipment_ids:
            continue
        for shift_type in WorkShiftType.values:
            slot_key = (item.id, shift_type)
            if slot_key in existing_slots:
                continue
            employee_id = baseline_by_slot.get(slot_key)
            if employee_id in used_employee_ids:
                employee_id = None
            if employee_id:
                used_employee_ids.add(employee_id)
            secondary_employee_id = baseline_secondary_by_slot.get(slot_key)
            if secondary_employee_id in used_employee_ids:
                secondary_employee_id = None
            if secondary_employee_id:
                used_employee_ids.add(secondary_employee_id)
            slots.append(CrewPlanSlot(
                plan=plan,
                equipment=item,
                shift_type=shift_type,
                employee_id=employee_id,
                secondary_employee_id=secondary_employee_id,
                baseline_employee_id=employee_id,
                baseline_secondary_employee_id=secondary_employee_id,
            ))

    CrewPlanSlot.objects.bulk_create(slots)
    if (slots or removed_slot_count) and bump_version:
        plan.version += 1
        update_fields = ['version', 'updated_at']
        if actor is not None:
            plan.updated_by = actor
            update_fields.append('updated_by')
        plan.save(update_fields=update_fields)
    return len(slots) + removed_slot_count


@transaction.atomic
def get_or_create_crew_draft(*, role, work_date=None, actor=None):
    role = _crew_plan_role(role)
    work_date = work_date or production_work_date()
    existing = (
        CrewPlan.objects.select_for_update()
        .filter(work_date=work_date, role=role, status=CrewPlanStatus.DRAFT)
        .order_by('-revision')
        .first()
    )
    if existing:
        _sync_crew_draft_equipment_slots(existing, actor=actor)
        return existing, False

    latest_revision = (
        CrewPlan.objects.filter(work_date=work_date, role=role)
        .aggregate(value=Max('revision'))['value']
        or 0
    )
    try:
        with transaction.atomic():
            plan = CrewPlan.objects.create(
                work_date=work_date,
                role=role,
                revision=latest_revision + 1,
                created_by=actor,
                updated_by=actor,
            )
    except IntegrityError:
        concurrent_draft = (
            CrewPlan.objects.select_for_update()
            .filter(work_date=work_date, role=role, status=CrewPlanStatus.DRAFT)
            .order_by('-revision')
            .first()
        )
        if concurrent_draft:
            _sync_crew_draft_equipment_slots(concurrent_draft, actor=actor)
            return concurrent_draft, False
        raise
    _sync_crew_draft_equipment_slots(plan, actor=actor, bump_version=False)
    return plan, True


@transaction.atomic
def update_crew_draft_slot(
    *,
    plan,
    equipment,
    shift_type,
    employee,
    expected_version,
    actor=None,
    position=CREW_SLOT_POSITION_PRIMARY,
):
    locked_plan = _crew_plan_instance(plan, for_update=True)
    role = _crew_plan_role(locked_plan.role)
    if locked_plan.status != CrewPlanStatus.DRAFT:
        raise ValidationError('Опубликованный план нельзя редактировать.', code='plan_not_draft')
    _validate_current_crew_plan(locked_plan)
    if locked_plan.version != expected_version:
        raise ValidationError(
            'Черновик уже изменен в другом окне. Обновите данные.',
            code='stale_version',
        )
    if shift_type not in WorkShiftType.values:
        raise ValidationError('Выберите смену 1 или смену 2.', code='invalid_shift')
    position = str(position or CREW_SLOT_POSITION_PRIMARY)
    if position not in CREW_SLOT_POSITIONS:
        raise ValidationError('Неизвестная позиция в экипаже.', code='invalid_crew_position')
    employee_field = (
        'employee'
        if position == CREW_SLOT_POSITION_PRIMARY
        else 'secondary_employee'
    )

    equipment = _crew_plan_equipment(equipment)
    _validate_crew_equipment(equipment, role)
    try:
        target_slot = (
            CrewPlanSlot.objects.select_for_update(of=('self',))
            .select_related('employee', 'secondary_employee')
            .get(plan=locked_plan, equipment=equipment, shift_type=shift_type)
        )
    except CrewPlanSlot.DoesNotExist as error:
        raise ValidationError('Слот техники не найден в черновике.', code='slot_not_found') from error

    employee = _crew_plan_employee(employee)
    if employee:
        employee = (
            Employee.objects.select_for_update(of=('self',))
            .select_related('contractor_organization')
            .get(pk=employee.pk)
        )
        _validate_crew_employee(employee, role, position=position)
        validate_employee_equipment_organization(employee, equipment)
    if getattr(target_slot, f'{employee_field}_id') == getattr(employee, 'id', None):
        return locked_plan

    source_slot = None
    source_position = None
    if employee:
        source_slots = list(
            CrewPlanSlot.objects.select_for_update(of=('self',))
            .select_related('employee', 'secondary_employee')
            .filter(
                Q(employee=employee) | Q(secondary_employee=employee),
                plan=locked_plan,
            )
            .order_by('pk')
        )
        if source_slots:
            source_slot = source_slots[0]
            source_position = (
                CREW_SLOT_POSITION_PRIMARY
                if source_slot.employee_id == employee.id
                else CREW_SLOT_POSITION_SECONDARY
            )

    if source_slot:
        source_field = (
            'employee'
            if source_position == CREW_SLOT_POSITION_PRIMARY
            else 'secondary_employee'
        )
        displaced_employee = getattr(target_slot, employee_field)
        if displaced_employee:
            _validate_crew_employee(
                displaced_employee,
                role,
                position=source_position,
            )
            validate_employee_equipment_organization(
                displaced_employee,
                source_slot.equipment,
            )
        # Clear the exact source and target columns first so swaps remain portable
        # across SQLite and PostgreSQL unique constraints.
        CrewPlanSlot.objects.filter(pk=source_slot.pk).update(**{source_field: None})
        CrewPlanSlot.objects.filter(pk=target_slot.pk).update(**{employee_field: None})
        setattr(source_slot, source_field, displaced_employee)
        setattr(target_slot, employee_field, employee)
        if source_slot.pk == target_slot.pk:
            setattr(source_slot, employee_field, employee)
            source_slot.save(update_fields=list({source_field, employee_field}))
        else:
            source_slot.save(update_fields=[source_field])
            target_slot.save(update_fields=[employee_field])
    else:
        setattr(target_slot, employee_field, employee)
        target_slot.save(update_fields=[employee_field])

    locked_plan.version += 1
    locked_plan.updated_by = actor
    locked_plan.save(update_fields=['version', 'updated_by', 'updated_at'])
    return locked_plan


@transaction.atomic
def _publish_crew_plan_once(*, plan, expected_version, actor=None, actor_access=None):
    if actor_access is not None:
        actor, actor_access = _locked_deputy_publish_access(
            actor_access=actor_access,
            actor=actor,
        )
    locked_plan = _crew_plan_instance(plan, for_update=True)
    role = _crew_plan_role(locked_plan.role)
    if locked_plan.status != CrewPlanStatus.DRAFT:
        raise ValidationError('Этот план уже опубликован.', code='plan_not_draft')
    _validate_current_crew_plan(locked_plan)
    if locked_plan.version != expected_version:
        raise ValidationError(
            'Черновик уже изменен в другом окне. Обновите данные.',
            code='stale_version',
        )

    slots = list(
        CrewPlanSlot.objects.select_for_update(of=('self',))
        .filter(plan=locked_plan)
        .select_related(
            'equipment',
            'equipment__equipment_type',
            'equipment__contractor_organization',
            'employee',
            'employee__contractor_organization',
            'secondary_employee',
            'secondary_employee__contractor_organization',
            'baseline_employee',
            'baseline_employee__contractor_organization',
            'baseline_secondary_employee',
            'baseline_secondary_employee__contractor_organization',
        )
        .order_by('equipment_id', 'shift_type')
    )
    active_equipment = list(equipment_queryset_for_work_role(role.code))
    active_equipment_ids = {item.id for item in active_equipment}
    expected_slot_keys = {
        (equipment_id, shift_type)
        for equipment_id in active_equipment_ids
        for shift_type in WorkShiftType.values
    }
    actual_slot_keys = {(slot.equipment_id, slot.shift_type) for slot in slots}
    if actual_slot_keys != expected_slot_keys:
        raise ValidationError(
            'Состав активной техники изменился. Создайте свежий черновик.',
            code='stale_baseline',
        )

    target_employee_ids = set()
    for slot in slots:
        _validate_crew_equipment(slot.equipment, role)
        for position, employee in (
            (CREW_SLOT_POSITION_PRIMARY, slot.employee),
            (CREW_SLOT_POSITION_SECONDARY, slot.secondary_employee),
        ):
            if not employee:
                continue
            _validate_crew_employee(employee, role, position=position)
            validate_employee_equipment_organization(employee, slot.equipment)
            if employee.id in target_employee_ids:
                raise ValidationError(
                    'Сотрудник назначен более чем в одну позицию экипажа.',
                    code='duplicate_employee',
                )
            target_employee_ids.add(employee.id)

    if target_employee_ids:
        list(
            Employee.objects.select_for_update()
            .filter(id__in=target_employee_ids)
            .order_by('id')
        )
        refreshed_employees = (
            Employee.objects.select_related('contractor_organization')
            .in_bulk(target_employee_ids)
        )
        for slot in slots:
            if slot.employee_id:
                slot.employee = refreshed_employees[slot.employee_id]
                _validate_crew_employee(
                    slot.employee,
                    role,
                    position=CREW_SLOT_POSITION_PRIMARY,
                )
                validate_employee_equipment_organization(slot.employee, slot.equipment)
            if slot.secondary_employee_id:
                slot.secondary_employee = refreshed_employees[slot.secondary_employee_id]
                _validate_crew_employee(
                    slot.secondary_employee,
                    role,
                    position=CREW_SLOT_POSITION_SECONDARY,
                )
                validate_employee_equipment_organization(
                    slot.secondary_employee,
                    slot.equipment,
                )

    current_published_plan = (
        CrewPlan.objects.select_for_update()
        .filter(
            work_date=locked_plan.work_date,
            role=role,
            status=CrewPlanStatus.PUBLISHED,
        )
        .exclude(pk=locked_plan.pk)
        .order_by('-revision')
        .first()
    )
    current_secondary_by_slot = {}
    if current_published_plan:
        current_secondary_by_slot = {
            (equipment_id, shift_type): employee_id
            for equipment_id, shift_type, employee_id in (
                CrewPlanSlot.objects.select_for_update(of=('self',))
                .filter(plan=current_published_plan)
                .values_list('equipment_id', 'shift_type', 'secondary_employee_id')
            )
        }
    if any(
        current_secondary_by_slot.get((slot.equipment_id, slot.shift_type))
        != slot.baseline_secondary_employee_id
        for slot in slots
    ):
        raise ValidationError(
            'Состав помощников и стажёров изменился после создания черновика. Обновите данные.',
            code='stale_baseline',
        )

    current_role_assignments = list(
        EquipmentAssignment.objects.select_for_update()
        .filter(
            role=role,
            status=AssignmentStatus.ACCEPTED,
            ended_at__isnull=True,
            shift__isnull=True,
            shift_type__in=WorkShiftType.values,
        )
        .order_by('-assigned_at', '-id')
    )
    current_by_slot = {}
    for assignment in current_role_assignments:
        current_by_slot.setdefault(
            (assignment.equipment_id, assignment.shift_type),
            assignment.employee_id,
        )
    stale_slots = [
        slot
        for slot in slots
        if current_by_slot.get((slot.equipment_id, slot.shift_type)) != slot.baseline_employee_id
    ]
    if stale_slots:
        raise ValidationError(
            'Базовая расстановка изменилась после создания черновика. Обновите данные.',
            code='stale_baseline',
        )

    target_slot_keys = {
        (slot.equipment_id, slot.shift_type)
        for slot in slots
        if slot.employee_id
    }
    primary_employee_ids = {slot.employee_id for slot in slots if slot.employee_id}
    other_role_employee_conflict = (
        EquipmentAssignment.objects.select_for_update()
        .filter(
            employee_id__in=primary_employee_ids,
            status=AssignmentStatus.ACCEPTED,
            ended_at__isnull=True,
            shift__isnull=True,
            role__isnull=False,
            shift_type__in=WorkShiftType.values,
        )
        .exclude(role=role)
        .first()
    )
    if other_role_employee_conflict:
        raise ValidationError(
            'Один из сотрудников уже назначен по другой рабочей роли.',
            code='assignment_conflict',
        )

    outside_slot_assignments = list(
        EquipmentAssignment.objects.select_for_update()
        .filter(
            equipment_id__in={key[0] for key in target_slot_keys},
            shift_type__in={key[1] for key in target_slot_keys},
            status=AssignmentStatus.ACCEPTED,
            ended_at__isnull=True,
            shift__isnull=True,
            role__isnull=False,
        )
        .exclude(role=role)
    )
    outside_slot_conflict = next(
        (
            assignment
            for assignment in outside_slot_assignments
            if (assignment.equipment_id, assignment.shift_type) in target_slot_keys
        ),
        None,
    )
    if outside_slot_conflict:
        raise ValidationError(
            'Один из слотов уже занят назначением вне публикуемого плана.',
            code='assignment_conflict',
        )

    current_scope_assignments = list(
        EquipmentAssignment.objects.select_for_update()
        .filter(
            role=role,
            status__in=(AssignmentStatus.PENDING, AssignmentStatus.ACCEPTED),
            ended_at__isnull=True,
            shift__isnull=True,
            shift_type__in=WorkShiftType.values,
        )
    )
    desired_slots = {
        (slot.equipment_id, slot.shift_type, slot.employee_id): slot
        for slot in slots
        if slot.employee_id
    }
    current_semantic_triples = {
        (assignment.equipment_id, assignment.shift_type, assignment.employee_id)
        for assignment in current_scope_assignments
        if assignment.employee_id
    }
    changed_semantic_triples = current_semantic_triples.symmetric_difference(
        desired_slots.keys()
    )
    unchanged_triples = set()
    for assignment in current_scope_assignments:
        assignment_key = (
            assignment.equipment_id,
            assignment.shift_type,
            assignment.employee_id,
        )
        source_slot = desired_slots.get(assignment_key)
        if (
            assignment.status == AssignmentStatus.ACCEPTED
            and source_slot is not None
            and assignment.source_kind
            == EquipmentAssignment.SourceKind.DEPUTY_PUBLISHED_PLAN
            and assignment.source_crew_plan_slot_id == source_slot.pk
        ):
            unchanged_triples.add(assignment_key)
    assignments_to_close = [
        assignment
        for assignment in current_scope_assignments
        if assignment.status == AssignmentStatus.PENDING
        or (assignment.equipment_id, assignment.shift_type, assignment.employee_id) not in unchanged_triples
    ]

    now = timezone.now()
    for assignment in assignments_to_close:
        if assignment.status == AssignmentStatus.PENDING:
            assignment.status = AssignmentStatus.CANCELLED
        assignment.ended_at = now
        assignment.ended_by = actor
    if assignments_to_close:
        EquipmentAssignment.objects.bulk_update(
            assignments_to_close,
            ['status', 'ended_at', 'ended_by'],
        )

    new_assignments = [
        EquipmentAssignment(
            employee=slot.employee,
            role=role,
            equipment=slot.equipment,
            shift_type=slot.shift_type,
            assigned_by=actor,
            status=AssignmentStatus.ACCEPTED,
            accepted_at=now,
            source_kind=EquipmentAssignment.SourceKind.DEPUTY_PUBLISHED_PLAN,
            source_crew_plan_slot=slot,
        )
        for slot in slots
        if slot.employee_id
        and (slot.equipment_id, slot.shift_type, slot.employee_id) not in unchanged_triples
    ]
    # Replacing a legacy/manual row with an equivalent published-plan row changes
    # provenance, not the employee's visible assignment. Keep realtime scope tied
    # to the semantic before/after difference so unchanged workers do not refresh.
    changed_employee_ids = {
        employee_id
        for _equipment_id, _shift_type, employee_id in changed_semantic_triples
        if employee_id
    }
    changed_equipment_ids = {
        equipment_id
        for equipment_id, _shift_type, _employee_id in changed_semantic_triples
        if equipment_id
    }
    changed_secondary_employee_ids = {
        employee_id
        for slot in slots
        for employee_id in (
            slot.secondary_employee_id,
            slot.baseline_secondary_employee_id,
        )
        if employee_id
        and slot.secondary_employee_id != slot.baseline_secondary_employee_id
    }
    changed_secondary_equipment_ids = {
        slot.equipment_id
        for slot in slots
        if slot.secondary_employee_id != slot.baseline_secondary_employee_id
    }
    changed_employee_ids.update(changed_secondary_employee_ids)
    changed_equipment_ids.update(changed_secondary_equipment_ids)
    (
        CrewPlan.objects.select_for_update()
        .filter(
            work_date=locked_plan.work_date,
            role=role,
            status=CrewPlanStatus.PUBLISHED,
        )
        .exclude(pk=locked_plan.pk)
        .update(status=CrewPlanStatus.SUPERSEDED)
    )
    locked_plan.status = CrewPlanStatus.PUBLISHED
    locked_plan.version += 1
    locked_plan.updated_by = actor
    locked_plan.published_by = actor
    locked_plan.published_at = now
    locked_plan.save(update_fields=[
        'status',
        'version',
        'updated_by',
        'published_by',
        'published_at',
        'updated_at',
    ])
    try:
        _bulk_create_published_plan_assignments(new_assignments)
    except IntegrityError as error:
        raise ValidationError(
            'Публикация конфликтует с другим активным назначением. Обновите данные.',
            code='assignment_conflict',
        ) from error
    if actor_access is not None:
        from rotations.arrival_roster_routing import _record_published_crew_plan_routing

        _record_published_crew_plan_routing(
            plan=locked_plan,
            slots=slots,
            actor_access=actor_access,
        )
    bump_operational_state(
        'CrewPlan:published',
        event_type='personnel_assignment_changed',
        object_type='CrewPlan',
        object_id=locked_plan.id,
        payload={
            'action': 'crew_plan_published',
            'plan_id': locked_plan.id,
            'work_date': locked_plan.work_date.isoformat(),
            'role_code': role.code,
            'employee_ids': sorted(changed_employee_ids),
            'equipment_ids': sorted(changed_equipment_ids),
        },
    )
    return locked_plan


def publish_crew_plan(*, plan, expected_version, actor=None, actor_access=None):
    """Publish once; retain a controlled OUP-role review outside a rolled-back draft."""
    try:
        return _publish_crew_plan_once(
            plan=plan,
            expected_version=expected_version,
            actor=actor,
            actor_access=actor_access,
        )
    except ValidationError as error:
        if actor_access is not None and getattr(error, 'code', '') == 'invalid_work_category':
            from rotations.arrival_roster_routing import _record_crew_plan_role_review

            _record_crew_plan_role_review(
                plan=plan,
                actor_access=actor_access,
            )
        raise


def equipment_queryset_for_work_role(role_code):
    equipment_type_name = WORK_ASSIGNMENT_ROLE_EQUIPMENT_TYPES.get(str(role_code or ''))
    if not equipment_type_name:
        return Equipment.objects.none()
    return (
        Equipment.objects
        .filter(
            is_active=True,
            equipment_type__is_active=True,
            equipment_type__name__iexact=equipment_type_name,
        )
        .select_related('equipment_type', 'model', 'contractor_organization')
        .distinct()
        .order_by('garage_number')
    )


def get_active_equipment_assignment(employee, role_code=None):
    assignments = (
        EquipmentAssignment.objects
        .filter(
            employee=employee,
            status=AssignmentStatus.ACCEPTED,
            ended_at__isnull=True,
            shift__isnull=True,
            role__isnull=False,
            shift_type__isnull=False,
        )
        .select_related('employee', 'role', 'equipment', 'equipment__equipment_type', 'assigned_by')
        .order_by('-assigned_at', '-id')
    )
    if role_code:
        assignments = assignments.filter(role__code=role_code)
    return assignments.first()


def validate_work_assignment(*, employee, role, equipment, shift_type, exclude_assignment=None):
    if role.code not in WORK_ASSIGNMENT_ROLE_EQUIPMENT_TYPES:
        raise ValidationError('Для этой роли назначение техники не поддерживается.')
    if shift_type not in WorkShiftType.values:
        raise ValidationError('Выберите смену 1 или смену 2.')
    if not employee.is_active or employee.status not in {
        Employee.Status.ACTIVE,
        Employee.Status.NOT_ACTIVATED,
    }:
        raise ValidationError('Сотрудник неактивен.')
    if not employee_matches_work_role(employee, role):
        raise ValidationError('Производственная специализация сотрудника не соответствует выбранной роли.')
    if not equipment_queryset_for_work_role(role.code).filter(id=equipment.id).exists():
        raise ValidationError('Выбранная техника не соответствует рабочей роли или неактивна.')
    validate_employee_equipment_organization(employee, equipment)

    conflict = EquipmentAssignment.objects.filter(
        equipment=equipment,
        shift_type=shift_type,
        status=AssignmentStatus.ACCEPTED,
        ended_at__isnull=True,
        shift__isnull=True,
    ).exclude(employee=employee)
    if exclude_assignment:
        conflict = conflict.exclude(id=exclude_assignment.id)
    if conflict.exists():
        raise ValidationError('Эта техника уже назначена другому сотруднику в выбранной смене.')


def work_assignment_state(employee, assignment):
    if not assignment:
        return 'no_active_assignment'
    if not employee.is_active:
        return 'employee_inactive'
    if not employee.accesses.filter(
        role=assignment.role,
        is_active=True,
    ).exclude(status='deactivated').exists():
        return 'access_inactive'
    if not assignment.equipment.is_active:
        return 'equipment_inactive'
    has_conflicting_shift = EmployeeShift.objects.filter(
        equipment=assignment.equipment,
        closed_at__isnull=True,
    ).exclude(employee=employee).exists()
    if has_conflicting_shift:
        return 'assignment_conflict'
    return 'assigned'


def _emit_work_assignment_changed(assignment, action):
    bump_operational_state(
        f'EquipmentAssignment:{action}',
        event_type='personnel_assignment_changed',
        object_type='EquipmentAssignment',
        object_id=assignment.id if assignment else '',
        payload={
            'action': action,
            'employee_ids': [assignment.employee_id] if assignment else [],
            'equipment_ids': [assignment.equipment_id] if assignment else [],
            'shift_type': assignment.shift_type if assignment else '',
            'role_code': assignment.role.code if assignment and assignment.role_id else '',
        },
    )


@transaction.atomic
def set_active_equipment_assignment(*, employee, role, equipment, shift_type, assigned_by=None, now=None):
    now = now or timezone.now()
    employee = employee.__class__.objects.select_for_update().get(pk=employee.pk)
    equipment = Equipment.objects.select_for_update().get(pk=equipment.pk)
    current = (
        EquipmentAssignment.objects.select_for_update()
        .filter(
            employee=employee,
            status__in=(AssignmentStatus.PENDING, AssignmentStatus.ACCEPTED),
            ended_at__isnull=True,
            shift__isnull=True,
            role__isnull=False,
            shift_type__isnull=False,
        )
        .select_related('role', 'equipment')
        .order_by('-assigned_at', '-id')
        .first()
    )
    validate_work_assignment(
        employee=employee,
        role=role,
        equipment=equipment,
        shift_type=shift_type,
        exclude_assignment=current,
    )
    if (
        current
        and current.status == AssignmentStatus.ACCEPTED
        and current.role_id == role.id
        and current.equipment_id == equipment.id
        and current.shift_type == shift_type
    ):
        return current, False

    open_assignments = list(
        EquipmentAssignment.objects.select_for_update()
        .filter(
            employee=employee,
            status__in=(AssignmentStatus.PENDING, AssignmentStatus.ACCEPTED),
            ended_at__isnull=True,
            shift__isnull=True,
            role__isnull=False,
            shift_type__isnull=False,
        )
    )
    for item in open_assignments:
        if item.status == AssignmentStatus.PENDING:
            item.status = AssignmentStatus.CANCELLED
        item.ended_at = now
        item.ended_by = assigned_by
    if open_assignments:
        EquipmentAssignment.objects.bulk_update(open_assignments, ['status', 'ended_at', 'ended_by'])

    try:
        assignment = EquipmentAssignment.objects.create(
            employee=employee,
            role=role,
            equipment=equipment,
            shift_type=shift_type,
            assigned_by=assigned_by,
            status=AssignmentStatus.ACCEPTED,
            accepted_at=now,
        )
    except IntegrityError as error:
        raise ValidationError('Назначение конфликтует с другим активным назначением. Обновите страницу.') from error
    _emit_work_assignment_changed(assignment, 'assigned')
    return assignment, True


@transaction.atomic
def clear_active_equipment_assignment(*, employee, assigned_by=None, now=None, role_code=None):
    now = now or timezone.now()
    employee.__class__.objects.select_for_update().get(pk=employee.pk)
    assignment_queryset = (
        EquipmentAssignment.objects.select_for_update().filter(
            employee=employee,
            status__in=(AssignmentStatus.PENDING, AssignmentStatus.ACCEPTED),
            ended_at__isnull=True,
            shift__isnull=True,
            role__isnull=False,
            shift_type__isnull=False,
        )
        .select_related('role')
    )
    if role_code:
        assignment_queryset = assignment_queryset.filter(role__code=role_code)
    assignments = list(assignment_queryset)
    for assignment in assignments:
        if assignment.status == AssignmentStatus.PENDING:
            assignment.status = AssignmentStatus.CANCELLED
        assignment.ended_at = now
        assignment.ended_by = assigned_by
    if assignments:
        EquipmentAssignment.objects.bulk_update(assignments, ['status', 'ended_at', 'ended_by'])
        _emit_work_assignment_changed(assignments[0], 'cleared')
    return len(assignments)


def _emit_assignment_changed(
        *, action, truck_id, excavator_ids, assignment_id=None,
        target_excavator_id=None, source_excavator_id=None, effective_at=None):
    related_equipment_ids = {
        value for value in [
            truck_id,
            source_excavator_id,
            target_excavator_id,
            *excavator_ids,
        ] if value
    }
    equipment_numbers = dict(
        Equipment.objects
        .filter(id__in=related_equipment_ids)
        .values_list('id', 'garage_number')
    )
    bump_operational_state(
        f'HaulAssignment:{action}',
        event_type='assignment_changed',
        object_type='HaulAssignment',
        object_id=assignment_id or '',
        payload={
            'action': action,
            'truck_ids': [truck_id],
            'truck_number': str(equipment_numbers.get(truck_id, '') or ''),
            'excavator_ids': sorted({value for value in excavator_ids if value}),
            'source_excavator_id': source_excavator_id,
            'source_excavator_number': str(
                equipment_numbers.get(source_excavator_id, '') or ''
            ),
            'target_excavator_id': target_excavator_id,
            'target_excavator_number': str(
                equipment_numbers.get(target_excavator_id, '') or ''
            ),
            'effective_at': effective_at.isoformat() if effective_at else '',
        },
    )


def _cancel_assignments(assignments, now):
    changed = []
    for assignment in assignments:
        if assignment.status == AssignmentStatus.CANCELLED and assignment.ended_at:
            continue
        assignment.status = AssignmentStatus.CANCELLED
        assignment.ended_at = now
        changed.append(assignment)
    if changed:
        HaulAssignment.objects.bulk_update(changed, ['status', 'ended_at'])
    return changed


class HaulAssignmentStateConflict(Exception):
    """Команда была сформирована по уже устаревшему состоянию самосвала."""

    def __init__(self, *, expected_state_id, actual_state_id):
        self.expected_state_id = expected_state_id
        self.actual_state_id = actual_state_id
        super().__init__('Состояние назначения самосвала изменилось.')


def haul_assignment_state_id(assignments):
    """Возвращает версию текущего диспетчерского решения по самосвалу.

    Открытая ожидающая команда новее принятого назначения и поэтому является
    состоянием, которое видит диспетчер. При равном времени порядок стабилен по
    первичному ключу.
    """
    latest = max(
        assignments,
        key=lambda item: (item.assigned_at, item.id or 0),
        default=None,
    )
    return latest.id if latest else 0


def _validate_haul_assignment_state(open_assignments, expected_state_id):
    if expected_state_id is None:
        return
    try:
        expected_state_id = int(expected_state_id)
    except (TypeError, ValueError):
        raise HaulAssignmentStateConflict(
            expected_state_id=expected_state_id,
            actual_state_id=haul_assignment_state_id(open_assignments),
        )
    actual_state_id = haul_assignment_state_id(open_assignments)
    if expected_state_id != actual_state_id:
        raise HaulAssignmentStateConflict(
            expected_state_id=expected_state_id,
            actual_state_id=actual_state_id,
        )


def projected_haul_assignments(*, for_update=False):
    """Одна целевая диспетчерская позиция на каждый самосвал.

    Это не активный рейс и не обязательно принятое водителем назначение. Здесь
    намеренно выбирается последняя открытая команда: ASSIGN показывает целевой
    комплекс сразу, RELEASE показывает гараж сразу.
    """
    queryset = (
        HaulAssignment.objects
        .filter(ended_at__isnull=True)
        .exclude(status=AssignmentStatus.CANCELLED)
        .select_related('truck', 'excavator')
        .order_by('truck_id', '-assigned_at', '-id')
    )
    if for_update:
        queryset = queryset.select_for_update()
    projected = {}
    for assignment in queryset:
        projected.setdefault(assignment.truck_id, assignment)
    return projected


def projected_haul_assignments_for_excavator(excavator, *, for_update=False):
    return [
        assignment
        for assignment in projected_haul_assignments(for_update=for_update).values()
        if (
            assignment.action == HaulAssignmentAction.ASSIGN
            and assignment.excavator_id == excavator.id
        )
    ]


def active_haul_handoffs(*, for_update=False):
    """Единая серверная выборка только фактически действующих переводов."""
    queryset = (
        HaulAssignmentHandoff.objects
        .filter(
            status=HaulAssignmentHandoffStatus.OPEN,
            resolved_at__isnull=True,
            target_assignment__action=HaulAssignmentAction.ASSIGN,
            target_assignment__status=AssignmentStatus.PENDING,
            target_assignment__ended_at__isnull=True,
            target_assignment__effective_at__isnull=False,
            source_assignment__truck_id=F('truck_id'),
            target_assignment__truck_id=F('truck_id'),
        )
        .exclude(source_excavator_id=F('target_assignment__excavator_id'))
    )
    if for_update:
        queryset = queryset.select_for_update(of=('self',))
    return queryset


def excavator_load_assignment_queryset(shift):
    """Карточки текущего экскаватора, включая обе стороны перевода."""
    if not shift or shift.closed_at or not shift.equipment_id:
        return HaulAssignment.objects.none()
    return (
        HaulAssignment.objects
        .filter(excavator_id=shift.equipment_id)
        .filter(
            Q(
                status=AssignmentStatus.ACCEPTED,
                ended_at__isnull=True,
            )
            | Q(
                status=AssignmentStatus.PENDING,
                ended_at__isnull=True,
                action=HaulAssignmentAction.ASSIGN,
                effective_at__isnull=False,
            )
        )
        .select_related('truck', 'truck__model', 'excavator')
        .order_by('truck__garage_number', '-assigned_at', '-id')
    )


def resolve_excavator_load_authority(
    *, truck_id, excavator_id, source_shift, requested_assignment_id=None, now=None,
):
    """Под блокировкой подтверждает право текущего или целевого экскаватора."""
    now = now or timezone.now()
    assignments = (
        HaulAssignment.objects
        .select_for_update(of=('self',))
        .select_related('truck', 'truck__model', 'excavator')
        .filter(truck_id=truck_id, excavator_id=excavator_id)
    )
    current = assignments.filter(
        status=AssignmentStatus.ACCEPTED,
        ended_at__isnull=True,
    ).first()
    if current:
        if (
            requested_assignment_id is not None
            and current.id != requested_assignment_id
        ):
            return None, None
        latest_open = (
            HaulAssignment.objects
            .select_for_update(of=('self',))
            .filter(truck_id=truck_id, ended_at__isnull=True)
            .exclude(status=AssignmentStatus.CANCELLED)
            .order_by('-assigned_at', '-id')
            .first()
        )
        outgoing_transition = None
        if latest_open and latest_open.id != current.id:
            if (
                latest_open.status != AssignmentStatus.PENDING
                or latest_open.effective_at is None
                or latest_open.effective_at <= now
            ):
                return None, None
            if (
                latest_open.action == HaulAssignmentAction.RELEASE
                and latest_open.excavator_id == current.excavator_id
            ):
                current.outgoing_transition_assignment = latest_open
            elif (
                latest_open.action == HaulAssignmentAction.ASSIGN
                and latest_open.excavator_id != current.excavator_id
            ):
                outgoing_transition = (
                    active_haul_handoffs(for_update=True)
                    .filter(
                        source_assignment=current,
                        source_shift=source_shift,
                        target_assignment=latest_open,
                    )
                    .first()
                )
                if not outgoing_transition:
                    return None, None
                current.outgoing_transition_assignment = latest_open
            else:
                return None, None
            current.is_outgoing_transition = True
        current.is_handoff_completion = False
        return current, outgoing_transition

    pending = assignments.filter(
        status=AssignmentStatus.PENDING,
        ended_at__isnull=True,
        action=HaulAssignmentAction.ASSIGN,
        effective_at__isnull=False,
    ).first()
    if not pending:
        return None, None
    handoffs = active_haul_handoffs(for_update=True).filter(
        truck_id=truck_id,
        target_assignment=pending,
        target_assignment__excavator_id=excavator_id,
    )
    if requested_assignment_id is not None:
        handoffs = handoffs.filter(target_assignment_id=requested_assignment_id)
    handoff = handoffs.first()
    if not handoff:
        if requested_assignment_id is None or pending.id != requested_assignment_id:
            return None, None
        latest_open = (
            HaulAssignment.objects.select_for_update(of=('self',))
            .filter(truck_id=truck_id, ended_at__isnull=True)
            .exclude(status=AssignmentStatus.CANCELLED)
            .order_by('-assigned_at', '-id')
            .first()
        )
        if latest_open is None or latest_open.id != pending.id:
            return None, None
        if HaulAssignment.objects.filter(
            truck_id=truck_id,
            status=AssignmentStatus.ACCEPTED,
            ended_at__isnull=True,
        ).exclude(pk=pending.pk).exists():
            return None, None
    pending.is_handoff_completion = False
    pending.is_transfer_target = True
    return pending, handoff


def resolve_haul_handoffs_for_trip(trip, *, now=None):
    """Рейс целевого экскаватора атомарно применяет перевод досрочно."""
    now = now or timezone.now()
    handoff = (
        active_haul_handoffs(for_update=True)
        .select_related('target_assignment')
        .filter(
            truck_id=trip.truck_id,
            target_assignment__excavator_id=trip.excavator_id,
        )
        .order_by('-created_at', '-id')
        .first()
    )
    target = None
    if handoff:
        target = HaulAssignment.objects.select_for_update().get(pk=handoff.target_assignment_id)
    else:
        target = (
            HaulAssignment.objects.select_for_update()
            .filter(
                truck_id=trip.truck_id,
                excavator_id=trip.excavator_id,
                status=AssignmentStatus.PENDING,
                ended_at__isnull=True,
                action=HaulAssignmentAction.ASSIGN,
                effective_at__isnull=False,
            )
            .order_by('-assigned_at', '-id')
            .first()
        )
    if not target:
        return 0
    if (
        target.status != AssignmentStatus.PENDING
        or target.ended_at is not None
        or target.action != HaulAssignmentAction.ASSIGN
    ):
        return 0
    open_assignments = list(
        HaulAssignment.objects.select_for_update()
        .filter(truck_id=trip.truck_id, ended_at__isnull=True)
        .exclude(status=AssignmentStatus.CANCELLED)
    )
    latest_open = max(
        open_assignments,
        key=lambda item: (item.assigned_at or item.created_at, item.id or 0),
        default=None,
    )
    if latest_open is None or latest_open.id != target.id:
        return 0
    if not handoff and any(
        item.id != target.id and item.status == AssignmentStatus.ACCEPTED
        for item in open_assignments
    ):
        return 0
    _cancel_assignments([item for item in open_assignments if item.id != target.id], now)
    target.status = AssignmentStatus.ACCEPTED
    target.accepted_at = now
    target.save(update_fields=['status', 'accepted_at'])
    if handoff:
        handoff.status = HaulAssignmentHandoffStatus.RESOLVED
        handoff.resolved_at = now
        handoff.resolved_by_trip = trip
        handoff.save(update_fields=['status', 'resolved_at', 'resolved_by_trip'])
    other_handoffs = HaulAssignmentHandoff.objects.filter(
        truck_id=trip.truck_id,
        status=HaulAssignmentHandoffStatus.OPEN,
        resolved_at__isnull=True,
    )
    if handoff:
        other_handoffs = other_handoffs.exclude(pk=handoff.pk)
    other_handoffs.update(
        status=HaulAssignmentHandoffStatus.EXPIRED,
        resolved_at=now,
        resolved_by_trip=None,
    )
    _emit_assignment_changed(
        action='transfer_completed_by_trip' if handoff else 'assignment_completed_by_trip',
        truck_id=trip.truck_id,
        excavator_ids=[item.excavator_id for item in open_assignments],
        assignment_id=target.id,
        target_excavator_id=target.excavator_id,
    )
    return 1


def expire_haul_handoffs_for_shift(shift, *, now=None):
    """Чистит только осиротевшие переходы; закрытие старой смены срок не отменяет."""
    if not shift:
        return 0
    now = now or timezone.now()
    return (
        HaulAssignmentHandoff.objects
        .filter(
            source_shift=shift,
            status=HaulAssignmentHandoffStatus.OPEN,
            resolved_at__isnull=True,
        )
        .exclude(
            target_assignment__status=AssignmentStatus.PENDING,
            target_assignment__ended_at__isnull=True,
        )
        .update(
            status=HaulAssignmentHandoffStatus.EXPIRED,
            resolved_at=now,
            resolved_by_trip=None,
        )
    )


def _handoff_source_shift(assignment):
    return (
        EmployeeShift.objects
        .filter(
            equipment_id=assignment.excavator_id,
            closed_at__isnull=True,
        )
        .filter(
            Q(workplace_code='excavator_operator')
            | Q(
                workplace_code='',
                equipment__equipment_type__name='Экскаватор',
            )
        )
        .order_by('-opened_at', '-id')
        .first()
    )


def _preserve_previous_loading_authority(
    *, previous_assignment, target_assignment,
):
    if not previous_assignment:
        return None
    if (
        target_assignment.action != HaulAssignmentAction.ASSIGN
        or previous_assignment.excavator_id == target_assignment.excavator_id
    ):
        return None
    source_shift = _handoff_source_shift(previous_assignment)
    if not source_shift:
        return None
    handoff, _ = HaulAssignmentHandoff.objects.get_or_create(
        truck_id=previous_assignment.truck_id,
        source_assignment=previous_assignment,
        target_assignment=target_assignment,
        source_excavator_id=previous_assignment.excavator_id,
        source_shift=source_shift,
        status=HaulAssignmentHandoffStatus.OPEN,
    )
    return handoff


def _expire_handoffs_for_target_assignments(assignments, now):
    target_ids = [item.id for item in assignments if item and item.id]
    if not target_ids:
        return 0
    return HaulAssignmentHandoff.objects.filter(
        target_assignment_id__in=target_ids,
        status=HaulAssignmentHandoffStatus.OPEN,
        resolved_at__isnull=True,
    ).update(
        status=HaulAssignmentHandoffStatus.EXPIRED,
        resolved_at=now,
        resolved_by_trip=None,
    )


def expire_invalid_haul_handoffs(*, now=None, truck_id=None):
    """Закрывает переходы, чьё целевое назначение уже не ожидает применения."""
    now = now or timezone.now()
    queryset = HaulAssignmentHandoff.objects.filter(
        status=HaulAssignmentHandoffStatus.OPEN,
        resolved_at__isnull=True,
    )
    if truck_id:
        queryset = queryset.filter(truck_id=truck_id)
    valid_ids = active_haul_handoffs().values('id')
    invalid_handoffs = queryset.exclude(id__in=valid_ids)
    if not invalid_handoffs.exists():
        return 0
    return invalid_handoffs.update(
        status=HaulAssignmentHandoffStatus.EXPIRED,
        resolved_at=now,
        resolved_by_trip=None,
    )


def validate_projected_excavator_state(assignments, expected_states):
    """Проверяет, что массовое действие применяется к видимому составу."""
    actual = {str(item.truck_id): item.id for item in assignments}
    try:
        expected = {
            str(int(truck_id)): int(state_id)
            for truck_id, state_id in (expected_states or {}).items()
        }
    except (AttributeError, TypeError, ValueError):
        expected = None
    if expected is None or expected != actual:
        raise HaulAssignmentStateConflict(
            expected_state_id=expected,
            actual_state_id=actual,
        )


@transaction.atomic
# select_for_update требует активную транзакцию. У соседней schedule_haul_release
# декоратор уже стоял, а здесь его не было — молчало, пока действие «Назначить
# самосвал» не сработало на редком стечении данных, и тогда падало 500-й ошибкой
# ровно на той кнопке, которой горный мастер и диспетчер пользуются каждый день.
def schedule_haul_assignment(
    *, truck, excavator, assigned_by=None, now=None, expected_state_id=None,
):
    now = now or timezone.now()
    lock_production_state()
    truck = Equipment.objects.select_for_update().get(pk=truck.pk)
    open_assignments = list(
        HaulAssignment.objects.select_for_update()
        .filter(truck=truck, ended_at__isnull=True)
        .exclude(status=AssignmentStatus.CANCELLED)
        .order_by('-assigned_at', '-id')
    )
    _validate_haul_assignment_state(open_assignments, expected_state_id)
    accepted = next((item for item in open_assignments if item.status == AssignmentStatus.ACCEPTED), None)
    current_pending = next((item for item in open_assignments if item.status == AssignmentStatus.PENDING), None)
    if (
        current_pending
        and current_pending.action == HaulAssignmentAction.ASSIGN
        and current_pending.excavator_id == excavator.id
    ):
        return current_pending, False
    pending_to_cancel = [item for item in open_assignments if item.status == AssignmentStatus.PENDING]
    _expire_handoffs_for_target_assignments(pending_to_cancel, now)
    cancelled = _cancel_assignments(pending_to_cancel, now)
    if accepted and accepted.excavator_id == excavator.id:
        if cancelled:
            excavator_ids = [accepted.excavator_id, *(item.excavator_id for item in cancelled)]
            _emit_assignment_changed(
                action='pending_cancelled', truck_id=truck.id,
                excavator_ids=excavator_ids, assignment_id=accepted.id,
                target_excavator_id=accepted.excavator_id,
            )
        return accepted, False

    assignment = HaulAssignment.objects.create(
        truck=truck,
        excavator=excavator,
        assigned_by=assigned_by,
        action=HaulAssignmentAction.ASSIGN,
        status=AssignmentStatus.PENDING,
        effective_at=haul_assignment_effective_at(truck, now),
    )
    _preserve_previous_loading_authority(
        previous_assignment=accepted,
        target_assignment=assignment,
    )
    excavator_ids = [
        excavator.id,
        getattr(accepted, 'excavator_id', None),
        *(item.excavator_id for item in cancelled),
    ]
    _emit_assignment_changed(
        action='assignment_pending', truck_id=truck.id,
        excavator_ids=excavator_ids, assignment_id=assignment.id,
        source_excavator_id=getattr(accepted, 'excavator_id', None),
        target_excavator_id=excavator.id,
        effective_at=assignment.effective_at,
    )
    return assignment, True


@transaction.atomic
def schedule_haul_release(*, truck, assigned_by=None, now=None, expected_state_id=None):
    now = now or timezone.now()
    lock_production_state()
    truck = Equipment.objects.select_for_update().get(pk=truck.pk)
    open_assignments = list(
        HaulAssignment.objects.select_for_update(of=('self',))
        .filter(truck=truck, ended_at__isnull=True)
        .exclude(status=AssignmentStatus.CANCELLED)
        .select_related('excavator')
        .order_by('-assigned_at', '-id')
    )
    _validate_haul_assignment_state(open_assignments, expected_state_id)
    accepted = next((item for item in open_assignments if item.status == AssignmentStatus.ACCEPTED), None)
    pending = [item for item in open_assignments if item.status == AssignmentStatus.PENDING]
    current_pending = pending[0] if pending else None
    if current_pending and current_pending.action == HaulAssignmentAction.RELEASE:
        return current_pending, False
    source = accepted or (pending[0] if pending else None)
    _expire_handoffs_for_target_assignments(pending, now)
    _cancel_assignments(pending, now)
    if not source:
        return None, False

    assignment = HaulAssignment.objects.create(
        truck=truck,
        excavator=source.excavator,
        assigned_by=assigned_by,
        action=HaulAssignmentAction.RELEASE,
        status=AssignmentStatus.PENDING,
        effective_at=haul_assignment_effective_at(truck, now),
    )
    _emit_assignment_changed(
        action='release_pending', truck_id=truck.id,
        excavator_ids=[source.excavator_id], assignment_id=assignment.id,
        effective_at=assignment.effective_at,
    )
    return assignment, True


@transaction.atomic
def notify_excavator_assignment_changed(assignment, *, released, previous_excavator_ids=()):
    """Сообщает машинисту, что ему дали или забрали самосвал.

    Внутри приложения об этом уже говорит звук и сообщение на экране, но при
    свёрнутом приложении человек ничего не узнает и может ждать машину,
    которую у него забрали. Ошибки отправки проглатываются: уведомление не
    должно ломать саму расстановку.
    """
    from shifts.models import EmployeeShift
    from users.webpush import notify_employee

    try:
        truck_number = (
            getattr(assignment.truck, 'garage_number', '') or 'без номера'
        )
        # При снятии назначение уже закрыто, поэтому берём экскаваторы, которые
        # были заняты этим самосвалом до применения.
        excavator_ids = (
            list(previous_excavator_ids)
            if released
            else [assignment.excavator_id]
        )
        for excavator_id in {item for item in excavator_ids if item}:
            shift = (
                EmployeeShift.objects
                .select_related('employee')
                .filter(equipment_id=excavator_id, closed_at__isnull=True)
                .filter(
                    Q(workplace_code='excavator_operator')
                    | Q(workplace_code='', equipment__equipment_type__name='Экскаватор')
                )
                .order_by('-opened_at')
                .first()
            )
            if not shift or not shift.employee_id:
                continue
            if released:
                title = 'Самосвал снят'
                body = f'{truck_number} больше не закреплён за вами.'
            else:
                title = 'Назначен самосвал'
                body = f'{truck_number} закреплён за вашим экскаватором.'
            notify_employee(
                shift.employee,
                title=title,
                body=body,
                url='/excavator/work/',
                tag='excavator-assignment',
                kind='excavator_assignment_released' if released else 'excavator_assignment_added',
            )
    except Exception:
        logger.exception('Не удалось отправить машинисту уведомление о назначении.')


def apply_pending_haul_assignment(assignment_id, *, now=None):
    # select_for_update требует активную транзакцию — без неё Django отказывает
    # запросом, а не блокировкой. Раньше функция вызывалась без transaction.atomic,
    # и это молчало, пока не появилось первое просроченное назначение: тогда
    # опрос состояния (дергает эту функцию каждые 5 секунд) стал падать 500-й
    # ошибкой у всех, кто в приложениях, — не только у того, чьё назначение.
    now = now or timezone.now()
    with transaction.atomic():
        lock_production_state()
        pending_truck_id = (
            HaulAssignment.objects
            .filter(
                id=assignment_id,
                status=AssignmentStatus.PENDING,
                ended_at__isnull=True,
            )
            .values_list('truck_id', flat=True)
            .first()
        )
        if not pending_truck_id:
            return None
        # Единый порядок всех команд: сначала блокируем самосвал, затем его
        # назначения. Это сериализует таймер, принятие водителем, DnD
        # диспетчера и отправку рейса экскаваторщиком.
        Equipment.objects.select_for_update().get(pk=pending_truck_id)
        pending = (
            HaulAssignment.objects.select_for_update()
            .filter(id=assignment_id, status=AssignmentStatus.PENDING, ended_at__isnull=True)
            .first()
        )
        if not pending:
            return None

        open_assignments = list(
            HaulAssignment.objects.select_for_update()
            .filter(truck_id=pending.truck_id, ended_at__isnull=True)
            .exclude(status=AssignmentStatus.CANCELLED)
            .order_by('-assigned_at', '-id')
        )
        handoffs = list(
            HaulAssignmentHandoff.objects.select_for_update(of=('self',)).filter(
                target_assignment=pending,
                status=HaulAssignmentHandoffStatus.OPEN,
                resolved_at__isnull=True,
            )
        )
        excavator_ids = [item.excavator_id for item in open_assignments]
        if pending.action == HaulAssignmentAction.RELEASE:
            _cancel_assignments(open_assignments, now)
            applied_action = 'release_applied'
        else:
            _cancel_assignments([item for item in open_assignments if item.id != pending.id], now)
            pending.status = AssignmentStatus.ACCEPTED
            pending.accepted_at = now
            pending.save(update_fields=['status', 'accepted_at'])
            applied_action = 'assignment_applied'
        if handoffs:
            HaulAssignmentHandoff.objects.filter(pk__in=[item.pk for item in handoffs]).update(
                status=HaulAssignmentHandoffStatus.EXPIRED,
                resolved_at=now,
                resolved_by_trip=None,
            )

        # The assignment mutation and its durable operational event are one
        # commit unit. In particular, release uses bulk_update() above and has
        # no model signal to fall back to if the process stops after commit.
        _emit_assignment_changed(
            action=applied_action, truck_id=pending.truck_id,
            excavator_ids=excavator_ids, assignment_id=pending.id,
            target_excavator_id=(
                pending.excavator_id
                if pending.action != HaulAssignmentAction.RELEASE
                else None
            ),
        )

    # Уведомления — за пределами блокировки: сетевой вызов внутри select_for_update
    # держал бы строки взаперти, пока не ответит сервер уведомлений.
    notify_excavator_assignment_changed(
        pending,
        released=pending.action == HaulAssignmentAction.RELEASE,
        previous_excavator_ids=excavator_ids,
    )
    return pending


def reconcile_due_haul_assignments(*, truck_id=None, now=None):
    now = now or timezone.now()
    due = HaulAssignment.objects.filter(
        status=AssignmentStatus.PENDING,
        ended_at__isnull=True,
        effective_at__isnull=False,
        effective_at__lte=now,
    )
    if truck_id:
        due = due.filter(truck_id=truck_id)
    applied = 0
    for assignment_id in due.order_by('effective_at', 'id').values_list('id', flat=True):
        if apply_pending_haul_assignment(assignment_id, now=now):
            applied += 1
    expire_invalid_haul_handoffs(now=now, truck_id=truck_id)
    return applied


RECONCILE_INTERVAL_SECONDS = 5


def _reconcile_lock_path():
    database = connection.settings_dict
    identity = '|'.join(
        str(database.get(field) or '')
        for field in ('ENGINE', 'HOST', 'PORT', 'NAME')
    )
    digest = hashlib.sha256(identity.encode('utf-8')).hexdigest()[:16]
    return Path(tempfile.gettempdir()) / f'accounting-mvp-due-reconcile-v1-{digest}.lock'


RECONCILE_LOCK_PATH = _reconcile_lock_path()
RECONCILE_PROCESS_ONLY = object()
_reconcile_gate = threading.Lock()
_reconcile_next_check = 0.0
_reconcile_running = False


def _acquire_reconcile_process_gate():
    global _reconcile_next_check, _reconcile_running

    now = time.monotonic()
    with _reconcile_gate:
        if _reconcile_running or now < _reconcile_next_check:
            return False
        _reconcile_running = True
        _reconcile_next_check = now + RECONCILE_INTERVAL_SECONDS
    return True


def _release_reconcile_process_gate():
    global _reconcile_running

    with _reconcile_gate:
        _reconcile_running = False


def _acquire_reconcile_server_gate():
    try:
        RECONCILE_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
        lock_file = RECONCILE_LOCK_PATH.open('a+b')
    except OSError:
        return RECONCILE_PROCESS_ONLY
    locked = False
    try:
        if not locks.lock(lock_file, locks.LOCK_EX | locks.LOCK_NB):
            lock_file.close()
            return None
        locked = True
        lock_file.seek(0)
        try:
            next_check = float(lock_file.read().decode('ascii').strip() or 0)
        except (UnicodeDecodeError, ValueError):
            next_check = 0
        if time.time() < next_check:
            locks.unlock(lock_file)
            locked = False
            lock_file.close()
            return None
        return lock_file
    except OSError:
        if locked:
            try:
                locks.unlock(lock_file)
            except OSError:
                pass
        try:
            lock_file.close()
        except OSError:
            pass
        return RECONCILE_PROCESS_ONLY


def _release_reconcile_server_gate(lock_file):
    try:
        try:
            lock_file.seek(0)
            lock_file.truncate()
            lock_file.write(
                f'{time.time() + RECONCILE_INTERVAL_SECONDS:.6f}'.encode('ascii')
            )
            lock_file.flush()
            os.fsync(lock_file.fileno())
        except OSError:
            pass
    finally:
        try:
            locks.unlock(lock_file)
        except OSError:
            pass
        try:
            lock_file.close()
        except OSError:
            pass


def reconcile_due_haul_assignments_throttled():
    if not _acquire_reconcile_process_gate():
        return 0
    try:
        lock_file = _acquire_reconcile_server_gate()
        if lock_file is None:
            return 0
        try:
            return reconcile_due_haul_assignments()
        finally:
            if lock_file is not RECONCILE_PROCESS_ONLY:
                _release_reconcile_server_gate(lock_file)
    finally:
        _release_reconcile_process_gate()
