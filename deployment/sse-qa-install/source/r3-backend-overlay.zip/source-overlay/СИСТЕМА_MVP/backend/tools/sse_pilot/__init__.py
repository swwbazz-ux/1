"""Local-only tools for validating the isolated SSE pilot."""

