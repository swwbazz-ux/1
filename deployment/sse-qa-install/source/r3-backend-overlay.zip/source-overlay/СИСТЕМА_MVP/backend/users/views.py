import secrets
import json
from datetime import datetime, timedelta
from contextlib import nullcontext
from decimal import Decimal
from io import BytesIO
from types import SimpleNamespace
from urllib.parse import urlencode

from django.conf import settings
from django.contrib import messages
from django import forms
from django.core.exceptions import FieldDoesNotExist, ValidationError
from django.forms import modelform_factory
from django.forms.models import construct_instance
from django.db import transaction
from django.db.models import Count, Q
from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404
from django.shortcuts import redirect, render
from django.templatetags.static import static
from django.urls import reverse
from django.utils import timezone
from django.utils.dateparse import parse_datetime
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_GET, require_POST
from openpyxl import Workbook

from assignments.models import (
    AssignmentStatus,
    ExcavatorDumpPointSetting,
    ExcavatorPlacement,
    HaulAssignment,
    HaulAssignmentAction,
)
from assignments.services import (
    WORK_ASSIGNMENT_ROLE_EQUIPMENT_TYPES,
    apply_pending_haul_assignment,
    clear_active_equipment_assignment,
    get_active_equipment_assignment,
    reconcile_due_haul_assignments,
    work_assignment_state,
)
from core.models import (
    OfflineFieldEvent,
    OperationalStateEvent,
    OperationalStateVersion,
    bump_operational_state,
    lock_production_state,
    rotate_operational_journal_epoch,
)
from core.operational_fragments import operational_fragment_response
from downtimes.driver_workflow import (
    DRIVER_DOWNTIME_FLOW_WAITING_LOADING,
    DRIVER_DOWNTIME_FLOW_WAITING_UNLOAD,
    driver_downtime_flow,
    driver_downtime_opens_work,
    driver_downtime_requires_empty_truck,
    driver_downtime_requires_loaded_trip,
    driver_downtime_required_dump_point_key,
    driver_downtime_start_conflict,
    driver_downtime_unavailable_message,
)
from downtimes.models import DowntimeEvent, DowntimeReason
from references.models import (
    Dormitory,
    DormitorySection,
    DumpPoint,
    Equipment,
    EquipmentModel,
    EquipmentState,
    EquipmentType,
    RockType,
    TruckCapacityRule,
)
from reports.forms import RatingPeriodReferenceForm
from reports.models import RatingPeriod, ReportTemplate
from reports.rating_period_generation import inspect_rating_period_calendar
from shifts.forms import EquipmentPlanGroupForm
from shifts.models import (
    AchievementPrize,
    EmployeeShift,
    EquipmentPlanGroup,
    EquipmentShiftPlan,
    PlanAssignmentStatus,
    PlanCalculationMode,
    ShiftClientAction,
    ShiftPlan,
    ShiftPlanScope,
)
from shifts.services import (
    calculate_truck_shift_progress,
    close_driver_shift,
    DriverShiftCloseConfirmationRequired,
    DriverShiftCloseIdempotencyConflict,
    driver_close_request_signature,
    driver_open_shift_queryset,
    ensure_driver_close_action_matches,
    find_other_role_open_shift,
    open_driver_shift,
    open_shift_conflict_message,
    other_role_shift_flag,
    other_role_shift_prompt,
    plan_status_label,
    plan_unit_label,
    progress_cycle_visual_context,
    recent_shift_reading_corrections,
    refresh_open_shift_plan_snapshots_for_group,
)
from trips.manual_loading import trip_driver_control_filter
from trips.models import DispatcherActionLog, OPEN_TRIP_STATUSES, Trip, TripClientAction, TripStatus

from .access_auth import (
    format_phone_for_display,
    find_employee_access_by_credentials,
    find_unactivated_accesses_by_phone,
)
from .app_catalog import (
    APP_CATALOG_ROLE_CODES,
    APP_CATALOG_ROLES,
    app_catalog_public_url,
    app_catalog_items,
    role_app_qr_asset_path,
)
from .active_role import (
    ACTIVE_ROLE_CODE_SESSION_KEY,
    ACTIVE_ROLE_GENERATION_SESSION_KEY,
    ACTIVE_ROLE_SESSION_KEY,
    activate_role_session,
    role_session_state,
)
from .protected_cards import (
    PROTECTED_WRITE_CODE,
    allow_protected_card_write,
)
from .privacy_consent import (
    PRIVACY_CONSENT_FIELD,
    PRIVACY_CONSENT_REQUIRED_MESSAGE,
    PRIVACY_CONSENT_SESSION_KEY,
    PRIVACY_POLICY_VERSION,
    accept_current_privacy_policy,
    privacy_consent_cookie_matches_access,
    privacy_consent_matches_access,
    privacy_consent_submission_is_current,
    set_current_privacy_consent_cookie,
)
from .forms import (
    AdminAccessBlockForm,
    AccessActivationForm,
    AdminAccessRoleForm,
    AdminEmployeeEditForm,
    AdminEmployeeForm,
    DriverCloseShiftForm,
    DriverOpenShiftForm,
    DriverPrimaryRegistrationForm,
    normalize_phone,
    PersonnelPositionReferenceForm,
)
from .models import (
    AdminActionLog,
    AdminConflict,
    ContractorOrganization,
    DriverPrimaryRegistration,
    Employee,
    EmployeeAccess,
    PersonnelDepartment,
    PersonnelPosition,
    ProductionSpecialization,
    Role,
    TemporaryWorkTransfer,
    WatchComposition,
    WorkSchedule,
)
from .live_monitor import attach_application_presence, application_presence_by_employee_ids
from .registration_dashboard import build_registration_dashboard
from .oup_undo import (
    get_oup_action_undo_state,
    undo_oup_action,
)
from .role_apps import (
    APP_CONTRACT_VERSION,
    get_role_app,
    get_role_app_for_request,
    role_app_manifest_response,
    role_app_service_worker_response,
)
from .session_device import (
    detect_session_device_kind,
    get_session_device_kind,
    set_session_device_kind,
)
from .work_profiles import (
    cancel_temporary_work_transfer,
    effective_specialization,
    employee_has_effective_access_role,
    expire_due_temporary_work_transfers,
    production_access_is_out_of_sync,
    sync_employee_production_access,
)


ROLE_INTERFACE_NAMES = {
    'admin': 'Админка',
    'driver': 'Интерфейс водителя самосвала',
    'excavator_operator': 'Интерфейс машиниста экскаватора',
    'mining_master': 'Интерфейс горного мастера',
    'deputy_mining_manager': 'Планирование смены зам. начальника горного участка',
    'oup': 'Рабочее место ОУП',
    'timekeeper': 'Рабочее место табельщика',
    'site_manager': 'Согласование продлений начальником участка',
    'employee_portal': 'Личные запросы сотрудника',
    'dispatcher': 'Диспетчерский экран',
    'mechanic': 'Интерфейс механика',
    'manager': 'Витрина руководства',
    'settlement_clerk': 'Рабочее место делопроизводителя',
}


ADMIN_RESTORABLE_EMPLOYEE_STATUSES = {
    Employee.Status.DEACTIVATED,
    Employee.Status.ARCHIVED,
    Employee.Status.DISMISSED,
    Employee.Status.DELETED,
}


INTERFACE_MAP = [
    {
        'section': 'Вход и администрирование',
        'items': [
            {'title': 'Единый вход', 'url': '/', 'code': 'любой демо-код', 'note': 'Открывает интерфейс по роли'},
            {'title': 'Карта интерфейсов', 'url': '/interfaces/', 'code': '-', 'note': 'Все готовые экраны MVP в одном месте'},
            {'title': 'Админка MVP', 'url': '/system-admin/', 'code': '1000', 'note': 'Сотрудники, доступы, справочники, конфликты и выгрузки'},
            {'title': 'Сотрудники админки', 'url': '/system-admin/employees/', 'code': '1000', 'note': 'Список сотрудников, фильтр по статусу, карточки и Excel'},
            {'title': 'Справочники админки', 'url': '/system-admin/references/', 'code': '1000', 'note': 'Единый реестр справочников первого этапа'},
            {'title': 'Конфликты админки', 'url': '/system-admin/conflicts/', 'code': '1000', 'note': 'Заблокированные рискованные действия и причины'},
            {'title': 'Журнал действий админки', 'url': '/system-admin/logs/', 'code': '1000', 'note': 'История важных административных действий'},
            {'title': 'Django-админка', 'url': '/admin/', 'code': 'администратор Django', 'note': 'Техническое управление справочниками и данными'},
        ],
    },
    {
        'section': 'Рабочие интерфейсы',
        'items': [
            {'title': 'Работа водителя самосвала', 'url': '/driver/', 'code': '2000', 'note': 'Главный PWA-экран Работа, смена, простои и путевка'},
            {'title': 'Машинист экскаватора', 'url': '/excavator/work/', 'code': '3000', 'note': 'Создание рейса и параметры для отчета заказчику'},
            {'title': 'Горный мастер', 'url': '/mining-master/assignments/', 'code': '4000', 'note': 'Назначение самосвалов под экскаваторы'},
            {'title': 'Зам. начальника горного участка', 'url': '/deputy-mining-manager/', 'code': 'роль зам. начальника', 'note': 'Расстановка сотрудников по технике на две смены'},
            {'title': 'Отдел управления персоналом', 'url': '/oup/', 'code': '800000 / роль ОУП', 'note': 'Создание, ведение и увольнение сотрудников'},
            {'title': 'Табельщик', 'url': '/timekeeper/', 'code': '900000 / роль табельщика', 'note': 'Сбор данных перевахты, Excel и оформление одобренных продлений'},
            {'title': 'Начальник участка', 'url': '/site-manager/extensions/', 'code': '910000 / роль начальника участка', 'note': 'Согласование заявок на продление вахты'},
            {'title': 'Ответ сотрудника по перевахте', 'url': '/my/rotation/', 'code': '920000 / любой активный доступ', 'note': 'Маршрут, даты, смена или запрос на продление'},
            {'title': 'Диспетчерский пульт', 'url': '/dispatcher/control/', 'code': '5000', 'note': 'Контроль активных рейсов и назначений'},
            {'title': 'Механическая служба', 'url': '/mechanic/downtimes/', 'code': '7000 / роль механика', 'note': 'Открытие и закрытие механических простоев по технике'},
        ],
    },
    {
        'section': 'Отчеты и руководство',
        'items': [
            {'title': 'Отчет по объемам', 'url': '/reports/volume/', 'code': '5000 / 6000', 'note': 'Фильтры, шаблоны, группировки и Excel'},
            {'title': 'Конструктор шаблонов отчетов', 'url': '/reports/templates/', 'code': '5000 / 1000', 'note': 'Столбцы, названия, фильтры, группировки, расчетные поля'},
            {'title': 'Суточный отчет заказчику', 'url': '/reports/customer-daily/', 'code': '5000 / 6000', 'note': 'Суточный отчет к 08:00 и Excel-выгрузка'},
            {'title': 'Отчет по механическим простоям', 'url': '/reports/downtimes/', 'code': '5000 / 6000 / 7000', 'note': 'Фильтры по датам, технике, причине, статусу и Excel'},
            {'title': 'Витрина руководства', 'url': '/reports/management/', 'code': '6000', 'note': 'Суточный срез, накопленная картина и показатели'},
            {'title': 'Excel-выгрузка витрины руководства', 'url': '/reports/management/export/', 'code': '6000', 'note': 'Сводка, динамика за 7 дней и сравнение день/ночь в Excel'},
            {'title': 'Чеклист пилотной проверки отчетов', 'url': '/reports/pilot-checklist/', 'code': '5000 / 6000 / 1000', 'note': 'Рабочая навигация перед пилотом: экраны, Excel-выгрузки и вопросы для сверки с текущими отчетами'},
            {'title': 'Сценарий пилотного запуска', 'url': '/reports/pilot-scenario/', 'code': '5000 / 6000 / 1000', 'note': 'Пошаговая проверка пилота по ролям: от расстановки и рейса до отчетов и витрины'},
            {'title': 'Журнал замечаний пилота', 'url': '/reports/pilot-feedback/', 'code': '5000 / 6000 / 1000', 'note': 'Фиксация замечаний, приоритетов, решений и переносов во время пилотной проверки'},
        ],
    },
]


DEMO_ACCESS_CODES = [
    ('+79000000001', '100000', 'Администратор'),
    ('+79000000002', '200000', 'Водитель самосвала'),
    ('+79000000003', '300000', 'Машинист экскаватора'),
    ('+79000000004', '400000', 'Горный мастер'),
    ('+79000000005', '500000', 'Диспетчер'),
    ('+79000000007', '700000', 'Механик'),
    ('+79000000006', '600000', 'Руководство'),
    ('+79000000008', '800000', 'Специалист ОУП'),
    ('+79000000009', '900000', 'Табельщик'),
    ('+79000000010', '910000', 'Начальник участка'),
    ('+79000000011', '920000', 'Сотрудник'),
]


DRIVER_SHELL_VERSION = 'driver-mobile-shell-v360'

DRIVER_MANIFEST = {
    'id': '/driver/',
    'name': 'Водитель самосвала',
    'short_name': 'Водитель',
    'description': 'Мобильное рабочее место водителя самосвала: работа, смена, простои и путевка.',
    'start_url': '/driver/',
    'scope': '/driver/',
    'display': 'standalone',
    'display_override': ['standalone', 'fullscreen'],
    'orientation': 'portrait',
    'background_color': '#030708',
    'theme_color': '#030708',
    'categories': ['business', 'productivity'],
    'icons': [
        {
            'src': '/static/img/pwa/driver-180.png',
            'sizes': '180x180',
            'type': 'image/png',
        },
        {
            'src': '/static/img/pwa/driver-192.png',
            'sizes': '192x192',
            'type': 'image/png',
        },
        {
            'src': '/static/img/pwa/driver-512.png',
            'sizes': '512x512',
            'type': 'image/png',
        },
        {
            'src': '/static/img/pwa/driver-maskable-512.png',
            'sizes': '512x512',
            'type': 'image/png',
            'purpose': 'maskable',
        },
    ],
}

DRIVER_SERVICE_WORKER_JS = f"""
const APP_CONTRACT_VERSION = {json.dumps(APP_CONTRACT_VERSION)};
const ROLE_CODE = "driver";
const CACHE_NAME = "{DRIVER_SHELL_VERSION}";
const CACHE_PREFIX = "driver-mobile-shell-";
const APP_SHELL_URL = "/driver/";
const LEGACY_SHELL_URL = "/driver/shift/";
const MANIFEST_URL = "/driver.webmanifest";
const SHELL_URLS = [APP_SHELL_URL, LEGACY_SHELL_URL];
const PRIVACY_POLICY_PATH = "/company/privacy/";
const PRIVACY_POLICY_URL = "/company/privacy/?from=role-login";
const CORE_ASSETS = [
    MANIFEST_URL,
    PRIVACY_POLICY_URL,
    "/static/portal/css/portal-shell-v5.css?v=7",
    "/static/js/driver-offline-outbox-v2.js?v={DRIVER_SHELL_VERSION}",
    "/static/js/driver-haptics-v1.js?v={DRIVER_SHELL_VERSION}",
    "/static/js/driver-native-push-v1.js?v={DRIVER_SHELL_VERSION}",
    "/static/css/mobile-dial-actions-v1.css?v={DRIVER_SHELL_VERSION}",
    "/static/js/mobile-dial-actions-v1.js?v={DRIVER_SHELL_VERSION}",
    "/static/css/driver-free-bucket-v1.css?v={DRIVER_SHELL_VERSION}",
    "/static/js/driver-free-bucket-v1.js?v={DRIVER_SHELL_VERSION}",
    "/static/css/excavator-work-v55.css?v={DRIVER_SHELL_VERSION}",
    "/static/css/excavator-work-v55-final.css?v={DRIVER_SHELL_VERSION}",
    "/static/css/excavator-work-v55-shift.css?v={DRIVER_SHELL_VERSION}",
    "/static/css/excavator-manual-loading-v1.css?v={DRIVER_SHELL_VERSION}",
    "/static/css/excavator-free-bucket-v1.css?v={DRIVER_SHELL_VERSION}",
    "/static/css/driver-manual-excavator-workspace-v1.css?v={DRIVER_SHELL_VERSION}",
    "/static/js/excavator-dashboard-drag-v1.js?v={DRIVER_SHELL_VERSION}",
    "/static/js/excavator-dump-return-swipe-v1.js?v={DRIVER_SHELL_VERSION}",
    "/static/js/equipment-label-fit-v1.js?v={DRIVER_SHELL_VERSION}",
    "/static/js/driver-manual-excavator-workspace-v1.js?v={DRIVER_SHELL_VERSION}",
    "/static/css/driver-downtime-drum-v1.css?v={DRIVER_SHELL_VERSION}",
    "/static/js/driver-downtime-drum-v1.js?v={DRIVER_SHELL_VERSION}",
    "/static/portal/js/portal-shell-v5.js",
    "/static/css/app.css",
    "/static/css/mobile-role-login-v1.css",
    "/static/css/mobile-shift-unified-v1.css",
    "/static/js/mobile-shift-unified-v1.js",
    "/static/js/mobile-operational-sounds-v1.js",
    "/static/css/native-app-update-v1.css",
  "/static/js/realtime-client.js",
  "/static/js/role-readonly.js",
    "/static/favicon.ico",
    "/static/img/pwa/driver-180.png",
    "/static/img/pwa/driver-192.png",
    "/static/img/pwa/driver-512.png",
    "/static/img/pwa/driver-maskable-512.png",
    "/static/img/start/start-hero-v1.webp",
    "/static/img/start/start-hero-v1.jpg",
    "/static/audio/driver/driver_truck_assigned.wav",
    "/static/audio/driver/driver_action_ok.wav",
    "/static/audio/driver/driver_action_error.wav",
    "/static/audio/driver/driver_connection_lost.wav",
    "/static/audio/driver/driver_connection_restored.wav",
    "/static/audio/driver/driver_shift_start.wav",
    "/static/audio/driver/driver_shift_end.wav",
    "/static/audio/driver/driver_assignment_notice.wav",
    "/static/audio/driver/driver_action_success_notice.wav",
    "/static/audio/driver/driver_assignment_removed_notice.wav",
    "/static/audio/driver/driver_shift_notice.wav",
    "/static/audio/driver/driver_action_failed_notice.wav",
    "/static/audio/driver/driver_connection_lost_notice.wav",
    "/static/audio/driver/driver_connection_restored_notice.wav"
];

self.addEventListener("install", (event) => {{
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => cache.addAll(CORE_ASSETS))
            .then(async () => {{
                const cache = await caches.open(CACHE_NAME);
                let prepared = false;
                await Promise.all(SHELL_URLS.map(async (url) => {{
                    try {{
                        const response = await fetch(new Request(url, {{ cache: "no-store", credentials: "same-origin" }}));
                        if (await cacheAuthenticatedDriverShell(cache, url, response)) {{
                            prepared = true;
                        }}
                    }} catch (error) {{}}
                }}));
                if (prepared || await migratePreviousAuthenticatedShell()) return;
                throw new Error("Authenticated driver shell is unavailable for offline installation.");
            }})
            .then(() => self.skipWaiting())
    );
}});

self.addEventListener("activate", (event) => {{
    event.waitUntil(
        hasValidatedCurrentShell().then((prepared) => caches.keys().then((keys) => {{
            if (!prepared) return [];
            return Promise.all(
                keys
                    .filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME)
                    .map((key) => caches.delete(key))
            );
        }})).then(() => self.clients.claim())
    );
}});

async function networkFirst(request, fallbackUrl) {{
    const cache = await caches.open(CACHE_NAME);
    try {{
        const freshRequest = new Request(request, {{ cache: "no-store" }});
        const response = await fetch(freshRequest);
        if (response && response.ok) {{
            cache.put(request, response.clone());
        }}
        return response;
    }} catch (error) {{
        return (await cache.match(request)) || (fallbackUrl ? cache.match(fallbackUrl) : undefined) || Response.error();
    }}
}}

async function isValidatedDriverShell(response) {{
    if (!response || !response.ok) return false;
    let finalUrl;
    try {{ finalUrl = new URL(response.url, self.location.origin); }} catch (error) {{ return false; }}
    if (finalUrl.origin !== self.location.origin || !SHELL_URLS.includes(finalUrl.pathname)) return false;
    const contentType = String(response.headers.get("Content-Type") || "");
    if (!contentType.includes("text/html")) return false;
    const html = await response.clone().text();
    return html.includes("data-driver-shell") && html.includes('data-driver-access-id="');
}}

function driverShellStaticDependencies(html) {{
    const dependencies = [];
    const seen = new Set();
    const tagPattern = /<(?:script|link)\\b[^>]*(?:src|href)\\s*=\\s*["']([^"']+)["'][^>]*>/gi;
    let match;
    while ((match = tagPattern.exec(String(html || ""))) !== null) {{
        let url;
        try {{ url = new URL(match[1].replaceAll("&amp;", "&"), self.location.origin); }} catch (error) {{ continue; }}
        if (url.origin !== self.location.origin || !url.pathname.startsWith("/static/")) continue;
        const exactUrl = url.pathname + url.search;
        if (!seen.has(exactUrl)) {{
            seen.add(exactUrl);
            dependencies.push(exactUrl);
        }}
    }}
    return dependencies;
}}

async function driverShellClosureComplete(cache, response) {{
    if (!await isValidatedDriverShell(response)) return false;
    const html = await response.clone().text();
    const dependencies = driverShellStaticDependencies(html);
    if (!dependencies.length) return false;
    for (const dependency of dependencies) {{
        const cached = await cache.match(dependency);
        if (!cached || !cached.ok) return false;
    }}
    return true;
}}

async function cacheAuthenticatedDriverShell(cache, shellUrl, response) {{
    if (!await isValidatedDriverShell(response)) return false;
    const html = await response.clone().text();
    const dependencies = driverShellStaticDependencies(html);
    if (!dependencies.length) return false;
    try {{
        for (const dependency of dependencies) {{
            const request = new Request(dependency, {{ cache: "no-store", credentials: "same-origin" }});
            const asset = await fetch(request);
            if (!asset || !asset.ok) return false;
            await cache.put(dependency, asset.clone());
        }}
    }} catch (error) {{
        return false;
    }}
    await cache.put(shellUrl, response.clone());
    return driverShellClosureComplete(cache, response);
}}

async function validatedShellEntries(cache) {{
    const requests = await cache.keys();
    const entries = [];
    for (const request of requests) {{
        const url = new URL(request.url);
        if (!SHELL_URLS.includes(url.pathname)) continue;
        const response = await cache.match(request);
        if (await driverShellClosureComplete(cache, response)) entries.push([request, response]);
    }}
    return entries;
}}

async function migratePreviousAuthenticatedShell() {{
    const target = await caches.open(CACHE_NAME);
    const names = (await caches.keys())
        .filter((name) => name.startsWith(CACHE_PREFIX) && name !== CACHE_NAME)
        .reverse();
    for (const name of names) {{
        const source = await caches.open(name);
        const entries = await validatedShellEntries(source);
        if (!entries.length) continue;
        const requests = await source.keys();
        for (const request of requests) {{
            const url = new URL(request.url);
            if (url.origin !== self.location.origin) continue;
            const response = await source.match(request);
            if (response && response.ok) await target.put(request, response.clone());
        }}
        return hasValidatedCurrentShell();
    }}
    return false;
}}

async function hasValidatedCurrentShell() {{
    const cache = await caches.open(CACHE_NAME);
    return (await validatedShellEntries(cache)).length > 0;
}}

async function matchDriverShellAcrossCaches(request) {{
    const names = (await caches.keys())
        .filter((name) => name === CACHE_NAME || name.startsWith(CACHE_PREFIX))
        .reverse();
    if (names.includes(CACHE_NAME)) {{
        names.splice(names.indexOf(CACHE_NAME), 1);
        names.unshift(CACHE_NAME);
    }}
    for (const name of names) {{
        const cache = await caches.open(name);
        const candidates = [request, APP_SHELL_URL, LEGACY_SHELL_URL];
        for (const candidate of candidates) {{
            const response = await cache.match(candidate);
            if (await driverShellClosureComplete(cache, response)) return response;
        }}
    }}
    return null;
}}

async function networkFirstDriverShell(request) {{
    const cache = await caches.open(CACHE_NAME);
    try {{
        const freshRequest = new Request(request, {{ cache: "no-store" }});
        const response = await fetch(freshRequest);
        await cacheAuthenticatedDriverShell(cache, request, response);
        return response;
    }} catch (error) {{
        return (await matchDriverShellAcrossCaches(request)) || Response.error();
    }}
}}

async function networkFirstStatic(request) {{
    const cache = await caches.open(CACHE_NAME);
    try {{
        const response = await fetch(request, {{ cache: "no-store" }});
        if (response && response.ok) {{
            await cache.put(request, response.clone());
        }}
        return response;
    }} catch (error) {{
        return (await cache.match(request)) || new Response(
            "Ресурс недоступен без сети.",
            {{ status: 503, headers: {{ "Content-Type": "text/plain; charset=utf-8" }} }}
        );
    }}
}}

self.addEventListener("fetch", (event) => {{
    const request = event.request;
    if (request.method !== "GET") {{
        return;
    }}
    const url = new URL(request.url);
    if (url.origin !== self.location.origin) {{
        return;
    }}
    if (request.headers.get("x-requested-with") === "XMLHttpRequest") {{
        event.respondWith(fetch(request));
        return;
    }}
    if (url.pathname === PRIVACY_POLICY_PATH) {{
        event.respondWith(networkFirst(request, PRIVACY_POLICY_URL));
        return;
    }}
    if (request.mode === "navigate" || url.pathname === APP_SHELL_URL || url.pathname === LEGACY_SHELL_URL) {{
        event.respondWith(networkFirstDriverShell(request));
        return;
    }}
    if (url.pathname === MANIFEST_URL) {{
        event.respondWith(networkFirst(request, MANIFEST_URL));
        return;
    }}
    if (url.pathname.startsWith("/static/")) {{
        event.respondWith(networkFirstStatic(request));
    }}
}});

self.addEventListener("message", (event) => {{
    if (!event.data || !event.data.type) {{
        return;
    }}
    if (event.data.type === "SKIP_WAITING") {{
        self.skipWaiting();
    }}
    if (event.data.type === "CLEAR_AUTHENTICATED_SHELL") {{
        const work = caches.keys().then((keys) => Promise.all(
            keys.filter((key) => key.startsWith(CACHE_PREFIX)).map(async (key) => {{
                const cache = await caches.open(key);
                await Promise.all(SHELL_URLS.map((url) => cache.delete(url)));
            }})
        ));
        event.waitUntil(work);
        if (event.ports && event.ports[0]) {{
            work.finally(() => event.ports[0].postMessage({{ok: true}}));
        }}
        return;
    }}
    if (event.data.type === "GET_VERSION" && event.ports && event.ports[0]) {{
        event.ports[0].postMessage({{
            version: CACHE_NAME,
            appContractVersion: APP_CONTRACT_VERSION,
            shellVersion: CACHE_NAME,
            roleCode: ROLE_CODE
        }});
    }}
}});
""".strip()


def get_current_access(request):
    access_id = request.session.get('employee_access_id')
    if not access_id:
        return None
    expire_due_temporary_work_transfers()
    access_queryset = (
        EmployeeAccess.objects
        .select_related('employee', 'role')
        .filter(
            id=access_id,
            is_active=True,
            status=EmployeeAccess.Status.ACTIVATED,
            employee__is_active=True,
            employee__status=Employee.Status.ACTIVE,
            role__is_active=True,
        )
    )
    role_app = get_role_app_for_request(request)
    if role_app:
        access_queryset = access_queryset.filter(role__code=role_app.role_code)
    access = access_queryset.first()
    if access and not employee_has_effective_access_role(access.employee, access.role.code):
        return None
    return access


def require_admin_access(request):
    access = get_current_access(request)
    if not access:
        return None
    if access.role.code != 'admin':
        return None
    return access


def generate_unique_access_code():
    while True:
        code = ''.join(str(secrets.randbelow(10)) for _ in range(6))
        if not EmployeeAccess.objects.filter(access_code=code).exists():
            return code


def log_admin_action(actor, action, obj=None, old_value='', new_value='', comment=''):
    AdminActionLog.objects.create(
        actor=actor,
        action=action,
        object_type=obj.__class__.__name__ if obj else '',
        object_id=str(obj.pk) if obj and obj.pk else '',
        object_repr=str(obj) if obj else '',
        old_value=old_value,
        new_value=new_value,
        comment=comment,
    )


def redirect_after_admin_action(request, fallback_view, **kwargs):
    next_url = request.POST.get('next', '')
    if next_url and url_has_allowed_host_and_scheme(
        next_url,
        allowed_hosts={request.get_host()},
        require_https=request.is_secure(),
    ):
        return redirect(next_url)
    return redirect(fallback_view, **kwargs)


def _validated_next_url(request, value):
    value = (value or '').strip()
    if value and url_has_allowed_host_and_scheme(
        value,
        allowed_hosts={request.get_host()},
        require_https=request.is_secure(),
    ):
        return value
    return ''


def _role_landing_url(access):
    """Return the role's real workplace instead of the redirect-only /home/."""
    app = get_role_app(access.role.code) if access else None
    return app.start_url if app else reverse('role_home')


def _login_redirect_response(request, target_url):
    """Let the fetch-driven login perform exactly one final navigation."""
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({'ok': True, 'redirect_url': target_url})
    return redirect(target_url)


def _active_role_session_matches_access(request, access):
    state = role_session_state(request, access)
    active_access = state.get('active_access')
    return bool(
        state['authenticated']
        and state['is_active']
        and active_access is not None
        and active_access.id == access.id
        and active_access.last_login_at is not None
        and request.session.get(ACTIVE_ROLE_SESSION_KEY) == access.id
        and request.session.get(ACTIVE_ROLE_GENERATION_SESSION_KEY)
        and request.session.get(ACTIVE_ROLE_CODE_SESSION_KEY)
        == access.role.code
    )

def build_workbook_response(workbook, filename):
    output = BytesIO()
    workbook.save(output)
    response = HttpResponse(
        output.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    )
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    return response


def excel_value(value):
    if isinstance(value, datetime) and timezone.is_aware(value):
        return timezone.localtime(value).replace(tzinfo=None)
    return value


def driver_manifest_view(request):
    return role_app_manifest_response(request, 'driver')


def driver_service_worker_view(request):
    return role_app_service_worker_response(request, 'driver', DRIVER_SERVICE_WORKER_JS)


def interface_map_view(request):
    return render(
        request,
        'users/interface_map.html',
        {
            'interface_sections': INTERFACE_MAP,
            'demo_access_codes': DEMO_ACCESS_CODES,
        },
    )


def _phone_accesses_have_duplicate_role(candidates):
    """Настоящий конфликт записей — две записи доступа на одну и ту же роль.
    Несколько ролей у одного номера — это просто сотрудник с несколькими ролями."""
    seen_roles = set()
    for candidate in candidates:
        if candidate.role_id in seen_roles:
            return True
        seen_roles.add(candidate.role_id)
    return False


def _phone_access_conflict_response(request, candidates, *, role_app, allowed_role_codes, login_role_app, phone):
    """Номер с несколькими записями доступа.

    Дубли одной роли — «нужна помощь администратора». Разные роли на общем
    входе driverform.ru — не ошибка, а сотрудник с несколькими ролями: вход
    продолжается как обычно (номер → PIN), а после PIN он выбирает приложение
    на экране /apps/choose/. Возвращает None, когда конфликта нет."""
    if not _phone_accesses_have_duplicate_role(candidates) and role_app is None and not allowed_role_codes:
        return None
    return render(
        request,
        'users/login_phone_not_found.html',
        {
            'login_role_app': login_role_app,
            'submitted_phone': format_phone_for_display(phone),
            'support_chat_url': getattr(settings, 'SUPPORT_CHAT_URL', ''),
            'support_chat_label': getattr(settings, 'SUPPORT_CHAT_LABEL', ''),
            'access_conflict': True,
        },
    )


def _own_catalog_apps(employee):
    """Активированные роли сотрудника, у которых есть приложение в каталоге,
    в порядке каталога: [(app, access), ...]."""
    accesses = {
        access.role.code: access
        for access in EmployeeAccess.objects
        .select_related('role', 'employee')
        .filter(
            employee=employee,
            is_active=True,
            status=EmployeeAccess.Status.ACTIVATED,
            role__is_active=True,
            role__code__in=APP_CATALOG_ROLE_CODES,
        )
        if employee_has_effective_access_role(access.employee, access.role.code)
    }
    result = []
    for role_code in APP_CATALOG_ROLE_CODES:
        app = get_role_app(role_code)
        if app is not None and role_code in accesses:
            result.append((app, accesses[role_code]))
    return result


def app_choose_view(request):
    """Выбор приложения после единого входа для сотрудника с несколькими ролями.

    Одно нажатие на плитку делает роль активной в этой же сессии и открывает её
    рабочий экран на этом же хосте — без повторного ввода номера и PIN. Сюда же
    можно вернуться, чтобы переключиться на другое приложение."""
    if get_role_app_for_request(request):
        return redirect(app_catalog_public_url(request))
    access = get_current_access(request)
    if not access:
        return redirect(f"{reverse('login')}?form=1&next={reverse('app_choose')}")
    own_apps = _own_catalog_apps(access.employee)
    if request.method == 'POST':
        role_code = (request.POST.get('role_code') or '').strip()
        target = next((item_access for app, item_access in own_apps if app.role_code == role_code), None)
        if target is None:
            messages.error(request, 'Это приложение вам не назначено.')
            return redirect('app_choose')
        try:
            with transaction.atomic():
                activate_role_session(request, target)
        except ValidationError as error:
            messages.error(request, '; '.join(error.messages))
            return redirect('app_choose')
        request.session.cycle_key()
        return redirect(_role_landing_url(target))
    if not own_apps:
        return redirect(_role_landing_url(access))
    response = render(
        request,
        'users/app_choose.html',
        {
            'employee': access.employee,
            'current_role_code': access.role.code,
            'own_apps': [
                {
                    'role_code': app.role_code,
                    'label': dict(APP_CATALOG_ROLES).get(app.role_code, app.short_name),
                    'description': app.description,
                    'icon_url': app.icon_192_url,
                    'theme_color': app.theme_color,
                }
                for app, _item_access in own_apps
            ],
        },
    )
    response['Cache-Control'] = 'no-store'
    return response


@require_GET
def app_catalog_view(request):
    if get_role_app_for_request(request):
        return redirect(app_catalog_public_url(request))
    current_access = get_current_access(request)
    catalog_apps = app_catalog_items(request)
    selected_role_code = (request.GET.get('app') or '').strip()
    selected_app = next(
        (item for item in catalog_apps if item['role_code'] == selected_role_code),
        None,
    )
    response = render(
        request,
        'users/app_catalog.html',
        {
            'catalog_apps': catalog_apps,
            'selected_app': selected_app,
            # Вошедшему сотруднику — прямой путь в свои приложения без QR.
            'own_apps_url': reverse('app_choose') if current_access else '',
        },
    )
    response['Cache-Control'] = 'no-cache'
    return response


@require_GET
def app_catalog_qr_view(request, role_code):
    if role_code not in APP_CATALOG_ROLE_CODES:
        raise Http404
    response = redirect(static(role_app_qr_asset_path(role_code)))
    response['Cache-Control'] = 'public, max-age=86400'
    response['X-Content-Type-Options'] = 'nosniff'
    return response


def _masked_activation_phone(value):
    digits = normalize_phone(value)
    if len(digits) == 11 and digits.startswith('7'):
        return f'+7 ••• •••-{digits[-4:-2]}-{digits[-2:]}'
    return 'Телефон подтвержден'


PENDING_ACTIVATION_SESSION_KEYS = (
    'pending_activation_access_id',
    'pending_activation_role_code',
    'pending_activation_target_app_code',
    'post_activation_next',
)


def _clear_pending_activation_session(request):
    for key in PENDING_ACTIVATION_SESSION_KEYS:
        request.session.pop(key, None)


def _mobile_privacy_consent_matches(request, access):
    """Restore a current, access-bound consent into a fresh login session."""
    if privacy_consent_matches_access(request.session, access):
        return True
    if privacy_consent_cookie_matches_access(request, access):
        accept_current_privacy_policy(
            request,
            PRIVACY_POLICY_VERSION,
            access=access,
        )
        return True
    return False


def _mobile_privacy_consent_gate(request, access, submitted_version):
    """Return whether login may continue and whether a cookie must be issued."""
    if _mobile_privacy_consent_matches(request, access):
        return True, False
    if privacy_consent_submission_is_current(submitted_version):
        accept_current_privacy_policy(
            request,
            submitted_version,
            access=access,
        )
        return True, True
    return False, False


def _render_mobile_privacy_consent_step(
    request,
    *,
    selected_device_kind,
    next_url,
    login_role_app,
    submitted_phone,
    invalid=False,
):
    if invalid:
        messages.error(request, PRIVACY_CONSENT_REQUIRED_MESSAGE)
    return render(
        request,
        'users/login.html',
        {
            'selected_device_kind': selected_device_kind,
            'next_url': next_url,
            'login_role_app': login_role_app,
            'combined_mobile_login': True,
            'submitted_phone': submitted_phone,
            'login_step': 'consent',
            'privacy_consent_error': invalid,
        },
    )


def _attach_mobile_privacy_consent_cookie(
    response,
    request,
    access,
    *,
    accepted_now,
):
    if accepted_now:
        set_current_privacy_consent_cookie(response, request, access)
    return response


def login_view(
    request,
    *,
    allowed_role_codes=None,
    target_role_app=None,
    forced_next_url='',
):
    role_app = get_role_app_for_request(request)
    login_role_app = target_role_app or role_app
    combined_mobile_login = bool(
        role_app
        and role_app.role_code in {'driver', 'excavator_operator'}
        and target_role_app is None
    )
    if (
        request.method == 'GET'
        and combined_mobile_login
        and request.GET.get('reset') == '1'
    ):
        # «Ввести другой номер» начинает новую предавторизационную попытку.
        # Согласие и выбранный доступ прошлого сотрудника нельзя переносить на
        # следующий номер, особенно на общем телефоне.
        _clear_pending_activation_session(request)
        request.session.pop(PRIVACY_CONSENT_SESSION_KEY, None)
        request.session.cycle_key()
    allowed_role_codes = tuple(allowed_role_codes or ())
    next_url = forced_next_url or _validated_next_url(
        request,
        (
            request.POST.get('next')
            if request.method == 'POST'
            else request.GET.get('next')
        ),
    )
    current_access = get_current_access(request) if request.method == 'GET' else None
    rating_tv_reauthentication_required = bool(
        current_access
        and next_url == reverse('driver_rating_tv')
        and not _active_role_session_matches_access(request, current_access)
    )
    targeted_role_reauthentication_required = bool(
        current_access
        and allowed_role_codes
        and (
            current_access.role.code not in allowed_role_codes
            or not _active_role_session_matches_access(request, current_access)
        )
    )
    if (
        request.method == 'GET'
        and current_access
        and not rating_tv_reauthentication_required
        and not targeted_role_reauthentication_required
    ):
        return redirect(next_url or _role_landing_url(current_access))
    if (
        request.method == 'GET'
        and role_app
        and target_role_app is None
        and request.session.get('employee_access_id')
    ):
        request.session.flush()
    selected_device_kind = request.POST.get('device_kind') if request.method == 'POST' else detect_session_device_kind(request)
    if selected_device_kind not in {'personal', 'shared'}:
        selected_device_kind = detect_session_device_kind(request)
    # Номер возвращаем в форму: при неверном пинкоде набирать его заново незачем.
    submitted_phone = (
        request.POST.get('phone', '').strip() if request.method == 'POST' else ''
    )
    # Со /start/ номер уже известен — ссылка на приложение несёт его в query.
    # Незачем набирать его снова: не путать с submitted_phone, который отвечает
    # ещё и за то, показывать ли поле пинкода (первый неудачный вход).
    prefilled_phone = (
        request.GET.get('phone', '').strip() if request.method == 'GET' else ''
    )
    submitted_action = request.POST.get('action', '') if request.method == 'POST' else ''
    login_action = (
        submitted_action
        if submitted_action in {'register', 'continue', 'consent'}
        else 'login'
    )
    submitted_privacy_consent = (
        request.POST.get(PRIVACY_CONSENT_FIELD, '')
        if request.method == 'POST'
        else ''
    )
    if request.method == 'POST' and login_action in {'register', 'continue', 'consent'}:
        # Первый вход. Раньше сюда пускал только выданный вручную временный код,
        # и раздавать его приходилось каждому — при текучке в двадцать человек за
        # вахту это неподъёмно. Теперь ключ — номер телефона из карточки, а ФИО
        # человек подтверждает глазами на следующем экране.
        phone = request.POST.get('phone', '').strip()
        matches = find_unactivated_accesses_by_phone(
            phone,
            role_codes=allowed_role_codes or ([role_app.role_code] if role_app else None),
        )
        matches = [
            candidate
            for candidate in matches
            if employee_has_effective_access_role(
                candidate.employee,
                candidate.role.code,
                allow_pending_access=True,
            )
        ]
        # У сотрудника может быть несколько записей доступа на один номер —
        # например, доступ переоформляли. Если хоть одна уже активирована, у
        # человека есть рабочий пинкод, и вести его на регистрацию нельзя:
        # заведёт второй и запутается, каким входить.
        activated = [
            candidate
            for candidate in matches
            if candidate.status == EmployeeAccess.Status.ACTIVATED
        ]
        if len(activated) > 1:
            conflict = _phone_access_conflict_response(
                request, activated,
                role_app=role_app, allowed_role_codes=allowed_role_codes,
                login_role_app=login_role_app, phone=phone,
            )
            if conflict is not None:
                return conflict
        already_registered = bool(activated)
        pending = [
            candidate
            for candidate in matches
            if candidate.status == EmployeeAccess.Status.NOT_ACTIVATED
        ]
        if len(pending) > 1 and not already_registered:
            conflict = _phone_access_conflict_response(
                request, pending,
                role_app=role_app, allowed_role_codes=allowed_role_codes,
                login_role_app=login_role_app, phone=phone,
            )
            if conflict is not None:
                return conflict
        privacy_consent_accepted_now = False
        consent_access = (
            pending[0]
            if pending and not already_registered
            else (activated[0] if activated else None)
        )
        if combined_mobile_login and consent_access:
            consent_ready, privacy_consent_accepted_now = (
                _mobile_privacy_consent_gate(
                    request,
                    consent_access,
                    submitted_privacy_consent,
                )
            )
            if not consent_ready:
                return _render_mobile_privacy_consent_step(
                    request,
                    selected_device_kind=selected_device_kind,
                    next_url=next_url,
                    login_role_app=login_role_app,
                    submitted_phone=phone,
                    invalid=(login_action == 'consent'),
                )
        if pending and not already_registered:
            access = pending[0]
            request.session.cycle_key()
            request.session['pending_activation_access_id'] = access.id
            request.session['pending_activation_role_code'] = access.role.code
            if target_role_app:
                request.session['pending_activation_target_app_code'] = target_role_app.role_code
            else:
                request.session.pop('pending_activation_target_app_code', None)
            if next_url:
                request.session['post_activation_next'] = next_url
            set_session_device_kind(request, selected_device_kind)
            response = _login_redirect_response(request, reverse('activate_access'))
            return _attach_mobile_privacy_consent_cookie(
                response,
                request,
                access,
                accepted_now=privacy_consent_accepted_now,
            )
        if activated:
            # Пинкод у человека уже есть — система сама открывает второй шаг.
            # Согласие принято на шаге телефона и привязано к конкретному
            # доступу, поэтому повторять чекбокс рядом с PIN не нужно.
            response = render(
                request,
                'users/login.html',
                {
                    'selected_device_kind': selected_device_kind,
                    'next_url': next_url,
                    'login_role_app': login_role_app,
                    'combined_mobile_login': combined_mobile_login,
                    'submitted_phone': phone,
                    'login_step': 'pin',
                },
            )
            return _attach_mobile_privacy_consent_cookie(
                response,
                request,
                activated[0],
                accepted_now=privacy_consent_accepted_now,
            )
        else:
            # Номер может быть в базе, но за другой должностью: человек открыл
            # чужое приложение. Писать ему «номер не найден» — врать и сбивать с
            # толку, он пойдёт менять номер, который менять не нужно.
            elsewhere = find_unactivated_accesses_by_phone(phone)
            elsewhere = [
                candidate
                for candidate in elsewhere
                if employee_has_effective_access_role(
                    candidate.employee,
                    candidate.role.code,
                    allow_pending_access=True,
                )
            ]
            if elsewhere:
                return render(
                    request,
                    'users/login_phone_not_found.html',
                    {
                        'login_role_app': login_role_app,
                        'submitted_phone': format_phone_for_display(phone),
                        'support_chat_url': getattr(settings, 'SUPPORT_CHAT_URL', ''),
                        'support_chat_label': getattr(settings, 'SUPPORT_CHAT_LABEL', ''),
                        'wrong_app': True,
                        'own_role_names': sorted({
                            candidate.role.name for candidate in elsewhere
                        }),
                    },
                )
            return render(
                request,
                'users/login_phone_not_found.html',
                {
                    'login_role_app': login_role_app,
                    'submitted_phone': format_phone_for_display(phone),
                    'support_chat_url': getattr(settings, 'SUPPORT_CHAT_URL', ''),
                    'support_chat_label': getattr(settings, 'SUPPORT_CHAT_LABEL', ''),
                },
            )

    if request.method == 'POST' and login_action == 'login':
        phone = request.POST.get('phone', '').strip()
        access_code = request.POST.get('access_code', '').strip()
        access = find_employee_access_by_credentials(
            phone,
            access_code,
            role_code=(
                role_app.role_code
                if role_app and not allowed_role_codes
                else None
            ),
            role_codes=allowed_role_codes,
        )
        if access and not employee_has_effective_access_role(
            access.employee,
            access.role.code,
            allow_pending_access=True,
        ):
            access = None
        # Мобильный двухшаговый вход никогда не авторизует NOT_ACTIVATED по
        # старому временному коду. Состояние такого доступа определяется ниже
        # только по телефону и ведёт на обязательное создание постоянного PIN.
        if (
            combined_mobile_login
            and access
            and access.status != EmployeeAccess.Status.ACTIVATED
        ):
            access = None
        if combined_mobile_login and access:
            activated_for_phone = [
                candidate
                for candidate in find_unactivated_accesses_by_phone(
                    phone,
                    role_codes=([role_app.role_code] if role_app else None),
                )
                if candidate.status == EmployeeAccess.Status.ACTIVATED
                and employee_has_effective_access_role(
                    candidate.employee,
                    candidate.role.code,
                    allow_pending_access=True,
                )
            ]
            if len(activated_for_phone) > 1:
                conflict = _phone_access_conflict_response(
                    request, activated_for_phone,
                    role_app=role_app, allowed_role_codes=allowed_role_codes,
                    login_role_app=login_role_app, phone=phone,
                )
                if conflict is not None:
                    return conflict
        privacy_consent_accepted_now = False
        if combined_mobile_login and access:
            consent_ready, privacy_consent_accepted_now = (
                _mobile_privacy_consent_gate(
                    request,
                    access,
                    submitted_privacy_consent,
                )
            )
            if not consent_ready:
                return _render_mobile_privacy_consent_step(
                    request,
                    selected_device_kind=selected_device_kind,
                    next_url=next_url,
                    login_role_app=login_role_app,
                    submitted_phone=phone,
                    invalid=False,
                )
        if access:
            if access.status == EmployeeAccess.Status.NOT_ACTIVATED:
                if access.primary_code_issued_at:
                    request.session.cycle_key()
                    accept_current_privacy_policy(
                        request,
                        submitted_privacy_consent,
                        access=access,
                    )
                    request.session['pending_activation_access_id'] = access.id
                    request.session['pending_activation_role_code'] = access.role.code
                    if target_role_app:
                        request.session['pending_activation_target_app_code'] = (
                            target_role_app.role_code
                        )
                    else:
                        request.session.pop(
                            'pending_activation_target_app_code',
                            None,
                        )
                    if next_url:
                        request.session['post_activation_next'] = next_url
                    set_session_device_kind(request, selected_device_kind)
                    return _login_redirect_response(request, reverse('activate_access'))
            try:
                with transaction.atomic():
                    locked_employee = Employee.objects.select_for_update().get(pk=access.employee_id)
                    locked_access = (
                        EmployeeAccess.objects
                        .select_for_update()
                        .select_related('employee', 'role')
                        .get(pk=access.pk)
                    )
                    if locked_access.status == EmployeeAccess.Status.NOT_ACTIVATED:
                        locked_access.status = EmployeeAccess.Status.ACTIVATED
                        locked_access.activated_at = timezone.now()
                        locked_access.save(update_fields=['status', 'activated_at'])
                        if locked_employee.status == Employee.Status.NOT_ACTIVATED:
                            locked_employee.status = Employee.Status.ACTIVE
                            locked_employee.is_active = True
                            locked_employee.save(update_fields=['status', 'is_active', 'updated_at'])
                    activate_role_session(request, locked_access)
            except ValidationError as error:
                messages.error(request, '; '.join(error.messages))
                return render(
                    request,
                    'users/login.html',
                    {
                        'selected_device_kind': selected_device_kind,
                        'next_url': next_url,
                        'login_role_app': login_role_app,
                        'combined_mobile_login': combined_mobile_login,
                        'submitted_phone': submitted_phone,
                        'login_step': 'pin' if submitted_phone else '',
                    },
                )
            request.session.cycle_key()
            set_session_device_kind(request, selected_device_kind)
            landing_url = next_url or _role_landing_url(access)
            # Единый вход, несколько ролей на одном номере и PIN: после PIN —
            # выбор приложения одним нажатием, а не первая попавшаяся роль.
            if (
                not next_url
                and role_app is None
                and not allowed_role_codes
                and len(_own_catalog_apps(locked_access.employee)) > 1
            ):
                landing_url = reverse('app_choose')
            response = _login_redirect_response(request, landing_url)
            return _attach_mobile_privacy_consent_cookie(
                response,
                request,
                locked_access,
                accepted_now=privacy_consent_accepted_now,
            )
        # Пинкода у номера ещё нет — человек первый раз в приложении. Отбивать
        # его «неверный пинкод» бессмысленно: вводить ему нечего. Ведём на экран,
        # где он увидит своё ФИО и придумает пинкод.
        phone_accesses = [
            candidate
            for candidate in find_unactivated_accesses_by_phone(
                phone,
                role_codes=allowed_role_codes or ([role_app.role_code] if role_app else None),
            )
            if employee_has_effective_access_role(
                candidate.employee,
                candidate.role.code,
                allow_pending_access=True,
            )
        ]
        # То же правило, что и на первом шаге: пинкод уже заведён — значит вход
        # обычный, а не повторная регистрация.
        first_time = [] if any(
            candidate.status == EmployeeAccess.Status.ACTIVATED
            for candidate in phone_accesses
        ) else [
            candidate
            for candidate in phone_accesses
            if candidate.status == EmployeeAccess.Status.NOT_ACTIVATED
        ]
        if combined_mobile_login and len(first_time) > 1:
            conflict = _phone_access_conflict_response(
                request, first_time,
                role_app=role_app, allowed_role_codes=allowed_role_codes,
                login_role_app=login_role_app, phone=phone,
            )
            if conflict is not None:
                return conflict
        if first_time:
            pending_access = first_time[0]
            privacy_consent_accepted_now = False
            if combined_mobile_login:
                consent_ready, privacy_consent_accepted_now = (
                    _mobile_privacy_consent_gate(
                        request,
                        pending_access,
                        submitted_privacy_consent,
                    )
                )
                if not consent_ready:
                    return _render_mobile_privacy_consent_step(
                        request,
                        selected_device_kind=selected_device_kind,
                        next_url=next_url,
                        login_role_app=login_role_app,
                        submitted_phone=phone,
                        invalid=False,
                    )
            request.session.cycle_key()
            request.session['pending_activation_access_id'] = pending_access.id
            request.session['pending_activation_role_code'] = pending_access.role.code
            if target_role_app:
                request.session['pending_activation_target_app_code'] = target_role_app.role_code
            else:
                request.session.pop('pending_activation_target_app_code', None)
            if next_url:
                request.session['post_activation_next'] = next_url
            set_session_device_kind(request, selected_device_kind)
            response = _login_redirect_response(request, reverse('activate_access'))
            return _attach_mobile_privacy_consent_cookie(
                response,
                request,
                pending_access,
                accepted_now=privacy_consent_accepted_now,
            )

        other_access = None
        if allowed_role_codes:
            other_access = find_employee_access_by_credentials(phone, access_code)
        if other_access:
            messages.error(
                request,
                f'У этой учетной записи нет доступа к приложению «{login_role_app.short_name}».',
            )
        elif login_role_app and combined_mobile_login and submitted_phone:
            messages.error(
                request,
                'PIN не подошёл. Проверьте 6 цифр и попробуйте ещё раз.',
            )
        elif login_role_app:
            messages.error(
                request,
                f'Телефон или пинкод указаны неверно для приложения «{login_role_app.short_name}».',
            )
        else:
            messages.error(request, 'Телефон или пинкод указаны неверно.')
    return render(
        request,
        'users/login.html',
        {
            'selected_device_kind': selected_device_kind,
            'next_url': next_url,
            'login_role_app': login_role_app,
            'combined_mobile_login': combined_mobile_login,
            'submitted_phone': submitted_phone or prefilled_phone,
            'login_step': (
                'pin'
                if request.method == 'POST'
                and login_action == 'login'
                and submitted_phone
                else 'phone'
            ),
            # Отличаем «номер пришёл в ссылке со /start/» от «человек уже
            # пробовал войти»: в первом случае экран установки должен
            # показаться как обычно, во втором — форма уже открыта на JS,
            # и это единственный случай, кроме постоянного GET, что доходит
            # досюда без реальной попытки входа.
            'phone_is_prefill_only': bool(prefilled_phone) and not submitted_phone,
        },
    )


@require_POST
def reclaim_role_session_view(request):
    """Return the active session to this device.

    Only one session per employee may act at a time, so logging in elsewhere
    leaves this screen read-only with no way back except retyping the PIN. This
    lets the person already authenticated here take the session back in one tap.
    It re-activates the very access this session is already signed in as, so it
    grants nothing new; switching between different roles still goes through
    activate_role_session's checks for open shifts, trips and downtimes.
    """
    access_id = request.session.get('employee_access_id')
    if not access_id:
        return JsonResponse(
            {'ok': False, 'error': 'Сессия не найдена. Войдите заново.'},
            status=401,
        )
    access = (
        EmployeeAccess.objects
        .select_related('employee', 'role')
        .filter(
            id=access_id,
            is_active=True,
            status=EmployeeAccess.Status.ACTIVATED,
            role__is_active=True,
            employee__is_active=True,
            employee__status=Employee.Status.ACTIVE,
        )
        .first()
    )
    if not access:
        return JsonResponse(
            {'ok': False, 'error': 'Доступ отключен. Обратитесь к администратору.'},
            status=403,
        )
    try:
        activate_role_session(request, access)
    except ValidationError as error:
        return JsonResponse(
            {'ok': False, 'error': '; '.join(error.messages)},
            status=409,
        )
    return JsonResponse({'ok': True})


def activate_access_view(request):
    access_id = request.session.get('pending_activation_access_id')
    if not access_id:
        return redirect('login')
    pending_role_code = request.session.get('pending_activation_role_code')
    target_app = get_role_app(
        request.session.get('pending_activation_target_app_code', '')
    )
    host_role_app = get_role_app_for_request(request)
    if (
        host_role_app
        and target_app is None
        and pending_role_code
        and pending_role_code != host_role_app.role_code
    ):
        # Предактивационная сессия одного приложения не переносится в другое.
        # Cookie сейчас host-only, но эта проверка оставляет изоляцию корректной
        # и при будущих изменениях домена cookie или прокси.
        _clear_pending_activation_session(request)
        return redirect('login')
    access_queryset = (
        EmployeeAccess.objects
        .select_related('employee', 'role')
        .filter(id=access_id, is_active=True, status=EmployeeAccess.Status.NOT_ACTIVATED)
    )
    if pending_role_code:
        access_queryset = access_queryset.filter(role__code=pending_role_code)
    elif host_role_app:
        access_queryset = access_queryset.filter(role__code=host_role_app.role_code)
    access = access_queryset.first()
    if access and not employee_has_effective_access_role(
        access.employee,
        access.role.code,
        allow_pending_access=True,
    ):
        access = None
    if not access:
        _clear_pending_activation_session(request)
        return redirect('login')

    activation_role_app = target_app or host_role_app
    if (
        activation_role_app
        and activation_role_app.role_code in {'driver', 'excavator_operator'}
        and not _mobile_privacy_consent_matches(request, access)
    ):
        _clear_pending_activation_session(request)
        messages.error(request, PRIVACY_CONSENT_REQUIRED_MESSAGE)
        return redirect('login')

    if request.method == 'POST':
        form = AccessActivationForm(request.POST, access=access)
        if form.is_valid():
            try:
                with transaction.atomic():
                    locked_employee = Employee.objects.select_for_update().get(pk=access.employee_id)
                    locked_access = (
                        EmployeeAccess.objects
                        .select_for_update()
                        .select_related('employee', 'role')
                        .get(
                            pk=access.pk,
                            is_active=True,
                            status=EmployeeAccess.Status.NOT_ACTIVATED,
                        )
                    )
                    locked_access.access_code = form.cleaned_data['new_access_code']
                    locked_access.status = EmployeeAccess.Status.ACTIVATED
                    locked_access.activated_at = timezone.now()
                    locked_access.save(update_fields=['access_code', 'status', 'activated_at'])
                    if locked_employee.status == Employee.Status.NOT_ACTIVATED:
                        locked_employee.status = Employee.Status.ACTIVE
                        locked_employee.is_active = True
                        locked_employee.save(update_fields=['status', 'is_active', 'updated_at'])
                    access = activate_role_session(request, locked_access)
            except (Employee.DoesNotExist, EmployeeAccess.DoesNotExist):
                _clear_pending_activation_session(request)
                messages.error(
                    request,
                    'Доступ уже изменился. Введите номер ещё раз.',
                )
                return redirect('login')
            except ValidationError as error:
                form.add_error(None, '; '.join(error.messages))
                return render(
                    request,
                    'users/activate_access.html',
                    {
                        'access': access,
                        'activation_phone': _masked_activation_phone(access.employee.phone),
                        'form': form,
                        'activation_role_app': activation_role_app,
                    },
                )
            for key in PENDING_ACTIVATION_SESSION_KEYS[:3]:
                request.session.pop(key, None)
            request.session.cycle_key()
            set_session_device_kind(request, get_session_device_kind(request))
            if access.role.code != 'oup':
                messages.success(
                    request,
                    'Постоянный пинкод создан. Первичный пинкод больше не действует.',
                )
            next_url = _validated_next_url(request, request.session.pop('post_activation_next', ''))
            return redirect(next_url or _role_landing_url(access))
    else:
        form = AccessActivationForm(access=access)

    return render(
        request,
        'users/activate_access.html',
        {
            'access': access,
            'activation_phone': _masked_activation_phone(access.employee.phone),
            'form': form,
            'activation_role_app': activation_role_app,
        },
    )


def logout_view(request):
    request.session.flush()
    return redirect('login')


def role_home_view(request):
    access = get_current_access(request)
    if not access:
        request.session.flush()
        return redirect('login')
    if access.role.code == 'driver':
        return redirect('driver_work')
    if access.role.code == 'mining_master':
        return redirect('mining_master_assignments')
    if access.role.code == 'deputy_mining_manager':
        return redirect('deputy_mining_manager_placement')
    if access.role.code == 'oup':
        return redirect('oup_home')
    if access.role.code == 'timekeeper':
        return redirect('rotation_timekeeper_dashboard')
    if access.role.code == 'site_manager':
        return redirect('rotation_site_manager_queue')
    if access.role.code == 'employee_portal':
        return redirect('rotation_employee_home')
    if access.role.code == 'excavator_operator':
        return redirect('excavator_work')
    if access.role.code == 'dispatcher':
        return redirect('dispatcher_control')
    if access.role.code == 'mechanic':
        return redirect('mechanic_dashboard')
    if access.role.code == 'manager':
        return redirect('management_dashboard')
    if access.role.code == 'settlement_clerk':
        return redirect('clerk_home')
    if access.role.code == 'admin':
        return redirect('system_admin_dashboard')
    interface_name = ROLE_INTERFACE_NAMES.get(access.role.code, f'Интерфейс роли: {access.role.name}')
    return render(
        request,
        'users/role_home.html',
        {
            'access': access,
            'interface_name': interface_name,
        },
    )


def system_admin_dashboard_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    employee_status_counts = {
        item['status']: item['total']
        for item in Employee.objects.values('status').annotate(total=Count('id'))
    }
    access_status_counts = {
        item['status']: item['total']
        for item in EmployeeAccess.objects.values('status').annotate(total=Count('id'))
    }
    reference_counts = [
        ('Подразделения', PersonnelDepartment.objects.count(), '/system-admin/references/personnel-departments/'),
        ('Графики работы', WorkSchedule.objects.count(), '/system-admin/references/work-schedules/'),
        ('Утверждённые составы вахт', WatchComposition.objects.count(), '/system-admin/references/watch-compositions/'),
        ('Периоды рейтинга', RatingPeriod.objects.count(), '/system-admin/references/rating-periods/'),
        ('Кадровые должности', PersonnelPosition.objects.count(), '/system-admin/references/personnel-positions/'),
        ('Производственные специализации', ProductionSpecialization.objects.count(), '/system-admin/references/production-specializations/'),
        ('Виды техники', EquipmentType.objects.count(), '/admin/references/equipmenttype/'),
        ('Модели техники', EquipmentModel.objects.count(), '/admin/references/equipmentmodel/'),
        ('Техника', Equipment.objects.count(), '/admin/references/equipment/'),
        ('Состояния техники', EquipmentState.objects.count(), '/admin/references/equipmentstate/'),
        ('Причины простоев', DowntimeReason.objects.count(), '/admin/downtimes/downtimereason/'),
        ('Породы', RockType.objects.count(), '/admin/references/rocktype/'),
        ('Точки разгрузки', DumpPoint.objects.count(), '/admin/references/dumppoint/'),
        ('Общежития', Dormitory.objects.count(), '/admin/references/dormitory/'),
        ('Секции общежитий', DormitorySection.objects.count(), '/admin/references/dormitorysection/'),
        ('Шаблоны отчетов', ReportTemplate.objects.count(), '/reports/templates/'),
    ]

    recent_employees = attach_application_presence(
        Employee.objects.order_by('-created_at')[:5]
    )
    return render(
        request,
        'users/system_admin_dashboard.html',
        {
            'access': access,
            'employee_total': Employee.objects.count(),
            'active_total': employee_status_counts.get(Employee.Status.ACTIVE, 0),
            'not_activated_total': access_status_counts.get(EmployeeAccess.Status.NOT_ACTIVATED, 0),
            'blocked_total': access_status_counts.get(EmployeeAccess.Status.BLOCKED, 0),
            'deactivated_total': access_status_counts.get(EmployeeAccess.Status.DEACTIVATED, 0),
            'recent_employees': recent_employees,
            'recent_accesses': EmployeeAccess.objects.select_related('employee', 'role').order_by('-last_login_at', '-created_at')[:5],
            'recent_logs': AdminActionLog.objects.select_related('actor')[:8],
            'open_conflicts': AdminConflict.objects.select_related('employee', 'role').filter(status=AdminConflict.Status.OPEN)[:8],
            'reference_counts': reference_counts,
            'shift_fact_total': Trip.objects.count() + DowntimeEvent.objects.count(),
            'shift_reading_corrections': recent_shift_reading_corrections(),
        },
    )


@require_GET
def system_admin_registration_dashboard_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    context = build_registration_dashboard(request.GET)
    context['access'] = access
    return render(request, 'users/system_admin_registration_dashboard.html', context)


@require_POST
def system_admin_reset_shift_test_data_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    deleted_counts = {
        'рейсы': Trip.objects.count(),
        'простои': DowntimeEvent.objects.count(),
        'оперативные события': OperationalStateEvent.objects.count(),
        'клиентские действия рейсов': TripClientAction.objects.count(),
        'диспетчерские журналы действий': DispatcherActionLog.objects.count(),
    }

    with transaction.atomic():
        TripClientAction.objects.all().delete()
        DispatcherActionLog.objects.all().delete()
        Trip.objects.all().delete()
        DowntimeEvent.objects.all().delete()
        OperationalStateEvent.objects.all().delete()
        rotate_operational_journal_epoch()
        bump_operational_state(
            'SystemAdmin:test_shift_data_reset',
            event_type='test_shift_data_reset',
            object_type='SystemAdmin',
            payload={'action': 'test_shift_data_reset', 'deleted_counts': deleted_counts},
        )
        log_admin_action(
            access.employee,
            'Сброшены тестовые показатели смены',
            new_value=json.dumps(deleted_counts, ensure_ascii=False),
            comment='Удалены только рейсы, простои, оперативные события и журналы действий. Справочники, сотрудники, техника и планы сохранены.',
        )

    deleted_total = sum(deleted_counts.values())
    messages.success(request, f'Тестовые показатели смены сброшены. Удалено записей: {deleted_total}.')
    return redirect('system_admin_dashboard')


def system_admin_references_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    reference_configs = get_system_admin_reference_configs()
    reference_sections = [
        {
            'title': 'Сотрудники и доступы',
            'items': [
                {'name': 'Сотрудники', 'count': Employee.objects.count(), 'url': 'system_admin_employees', 'external_url': ''},
                {'name': 'Организации подрядчиков', 'count': ContractorOrganization.objects.count(), 'url': '', 'external_url': '/admin/users/contractororganization/', 'detail_code': 'contractor-organizations'},
                {'name': 'Подразделения', 'count': PersonnelDepartment.objects.count(), 'url': '', 'external_url': '/admin/users/personneldepartment/', 'detail_code': 'personnel-departments'},
                {'name': 'Графики работы', 'count': WorkSchedule.objects.count(), 'url': '', 'external_url': '/admin/users/workschedule/', 'detail_code': 'work-schedules'},
                {'name': 'Утверждённые составы вахт', 'count': WatchComposition.objects.count(), 'url': '', 'external_url': '/admin/users/watchcomposition/', 'detail_code': 'watch-compositions'},
                {'name': 'Кадровые должности', 'count': PersonnelPosition.objects.count(), 'url': '', 'external_url': '/admin/users/personnelposition/', 'detail_code': 'personnel-positions'},
                {'name': 'Производственные специализации', 'count': ProductionSpecialization.objects.count(), 'url': '', 'external_url': '/admin/users/productionspecialization/', 'detail_code': 'production-specializations'},
                {'name': 'Роли', 'count': Role.objects.count(), 'url': '', 'external_url': '/admin/users/role/'},
                {'name': 'Доступы', 'count': EmployeeAccess.objects.count(), 'url': '', 'external_url': '/admin/users/employeeaccess/'},
            ],
        },
        {
            'title': 'Техника',
            'items': [
                {'name': 'Виды техники', 'count': EquipmentType.objects.count(), 'url': '', 'external_url': '/admin/references/equipmenttype/', 'detail_code': 'equipment-types'},
                {'name': 'Модели техники', 'count': EquipmentModel.objects.count(), 'url': '', 'external_url': '/admin/references/equipmentmodel/', 'detail_code': 'equipment-models'},
                {'name': 'Техника', 'count': Equipment.objects.count(), 'url': '', 'external_url': '/admin/references/equipment/', 'detail_code': 'equipment'},
                {'name': 'Состояния техники', 'count': EquipmentState.objects.count(), 'url': '', 'external_url': '/admin/references/equipmentstate/', 'detail_code': 'equipment-states'},
            ],
        },
        {
            'title': 'Производственные справочники',
            'items': [
                {'name': 'Породы', 'count': RockType.objects.count(), 'url': '', 'external_url': '/admin/references/rocktype/', 'detail_code': 'rocks'},
                {'name': 'Точки разгрузки', 'count': DumpPoint.objects.count(), 'url': '', 'external_url': '/admin/references/dumppoint/', 'detail_code': 'dump-points'},
                {'name': 'Шаблоны отчетов', 'count': ReportTemplate.objects.count(), 'url': '', 'external_url': '/reports/templates/'},
                {'name': 'Ежесменные планы техники', 'count': EquipmentPlanGroup.objects.count(), 'url': '', 'external_url': '/admin/shifts/equipmentplangroup/', 'detail_code': 'equipment-plan-groups'},
                {'name': 'Приз за 100% плана', 'count': AchievementPrize.objects.count(), 'url': '', 'external_url': '/admin/shifts/achievementprize/', 'detail_code': 'achievement-prizes'},
                {'name': 'Сменные планы (история)', 'count': ShiftPlan.objects.count(), 'url': '', 'external_url': '/admin/shifts/shiftplan/', 'detail_code': 'shift-plans'},
                {'name': 'Планы техники (история)', 'count': EquipmentShiftPlan.objects.count(), 'url': '', 'external_url': '/admin/shifts/equipmentshiftplan/', 'detail_code': 'equipment-shift-plans'},
            ],
        },
        {
            'title': 'Рейтинг',
            'items': [
                {
                    'name': 'Периоды рейтинга',
                    'count': RatingPeriod.objects.count(),
                    'url': '',
                    'external_url': '/admin/reports/ratingperiod/',
                    'detail_code': 'rating-periods',
                },
            ],
        },
        {
            'title': 'Простои',
            'items': [
                {'name': 'Общий список простоев', 'count': DowntimeReason.objects.count(), 'url': '', 'external_url': '/admin/downtimes/downtimereason/', 'detail_code': 'downtime-reasons'},
                {'name': 'Простои водителя самосвала', 'count': DowntimeReason.objects.filter(show_for_truck_driver=True).count(), 'url': '', 'external_url': '/admin/downtimes/downtimereason/', 'detail_code': 'truck-driver-downtimes'},
                {'name': 'Простои машиниста экскаватора', 'count': DowntimeReason.objects.filter(show_for_excavator_operator=True).count(), 'url': '', 'external_url': '/admin/downtimes/downtimereason/', 'detail_code': 'excavator-operator-downtimes'},
                {'name': 'Детальные простои механика', 'count': DowntimeReason.objects.filter(show_for_mechanic=True).count(), 'url': '', 'external_url': '/admin/downtimes/downtimereason/', 'detail_code': 'mechanic-downtimes'},
            ],
        },
        {
            'title': 'Проживание',
            'items': [
                {'name': 'Общежития', 'count': Dormitory.objects.count(), 'url': '', 'external_url': '/admin/references/dormitory/', 'detail_code': 'dormitories'},
                {'name': 'Секции общежитий', 'count': DormitorySection.objects.count(), 'url': '', 'external_url': '/admin/references/dormitorysection/', 'detail_code': 'dormitory-sections'},
            ],
        },
    ]
    reference_total = 0
    empty_total = 0
    for section in reference_sections:
        section_count = 0
        empty_count = 0
        for item in section['items']:
            count = item['count']
            section_count += count
            reference_total += count
            if count:
                item['status_label'] = 'Заполнен'
                item['status_class'] = 'ok'
            else:
                empty_count += 1
                empty_total += 1
                item['status_label'] = 'Пусто'
                item['status_class'] = 'warning'
            if item.get('detail_code') in reference_configs:
                item['target_label'] = 'Рабочий экран'
            else:
                item['target_label'] = 'Админка' if item['external_url'].startswith('/admin/') else 'Рабочий экран'
        section['count'] = section_count
        section['empty_count'] = empty_count
        section['status_label'] = 'Требует заполнения' if empty_count else 'Готов'
        section['status_class'] = 'warning' if empty_count else 'ok'

    return render(
        request,
        'users/system_admin_references.html',
        {
            'access': access,
            'reference_sections': reference_sections,
            'reference_total': reference_total,
            'empty_total': empty_total,
        },
    )


def get_system_admin_reference_configs():
    return {
        'contractor-organizations': {
            'title': 'Организации подрядчиков',
            'section': 'Сотрудники и доступы',
            'model': ContractorOrganization,
            'description': 'Юридические лица подрядчиков, сроки договоров и общий допуск к производственным работам.',
            'fields': [
                'name',
                'short_name',
                'contract_number',
                'contract_valid_from',
                'contract_valid_until',
                'contact_person',
                'contact_phone',
                'comment',
                'is_active',
            ],
            'search_fields': ['name', 'short_name', 'contract_number', 'contact_person', 'contact_phone'],
            'preview_fields': ['short_name', 'contract_number', 'contract_valid_from', 'contract_valid_until', 'is_active'],
            'initial': {'is_active': True},
            'admin_url': '/admin/users/contractororganization/',
        },
        'personnel-departments': {
            'title': 'Подразделения',
            'section': 'Сотрудники и доступы',
            'model': PersonnelDepartment,
            'description': 'Официальные подразделения компании из 1С. В карточке сотрудника выбирается готовое значение без ручного ввода.',
            'fields': ['name', 'code', 'is_active'],
            'search_fields': ['name', 'code'],
            'preview_fields': ['code', 'is_active'],
            'initial': {'is_active': True},
            'admin_url': '/admin/users/personneldepartment/',
        },
        'work-schedules': {
            'title': 'Графики работы',
            'section': 'Сотрудники и доступы',
            'model': WorkSchedule,
            'description': 'Стандартные кадровые графики из 1С. Номер бригады выбирается отдельно и ограничивается количеством бригад в графике.',
            'fields': ['name', 'code', 'brigade_count', 'is_active'],
            'search_fields': ['name', 'code'],
            'preview_fields': ['code', 'brigade_count', 'is_active'],
            'initial': {'is_active': True, 'brigade_count': 2},
            'admin_url': '/admin/users/workschedule/',
        },
        'watch-compositions': {
            'title': 'Утверждённые составы вахт',
            'section': 'Сотрудники и доступы',
            'model': WatchComposition,
            'description': 'Уже утверждённые составы вахт. ОУП выбирает состав в карточке сотрудника; график и бригада не подставляют его автоматически.',
            'fields': ['name', 'code', 'is_active'],
            'search_fields': ['name', 'code'],
            'preview_fields': ['code', 'is_active'],
            'initial': {'is_active': True},
            'admin_url': '/admin/users/watchcomposition/',
        },
        'rating-periods': {
            'title': 'Периоды рейтинга',
            'section': 'Рейтинг',
            'model': RatingPeriod,
            'form_class': RatingPeriodReferenceForm,
            'description': (
                'Обычные периоды создаются автоматически по правилу '
                '14-е → 14-е: текущий и 12 следующих. Существующие записи '
                'система не изменяет. Вручную корректируйте только исключения '
                'и обязательно указывайте причину изменения дат.'
            ),
            'fields': [
                'name',
                'starts_on',
                'ends_before',
                'comment',
                'is_active',
            ],
            'search_fields': ['name', 'comment'],
            'preview_fields': [
                'starts_on',
                'ends_before',
                'generation_source_label',
                'manual_override_label',
                'is_active',
            ],
            'preview_labels': {
                'generation_source_label': 'Создание',
                'manual_override_label': 'Режим дат',
            },
            'initial': {'is_active': True},
            'admin_url': '/admin/reports/ratingperiod/',
        },
        'personnel-positions': {
            'title': 'Кадровые должности',
            'section': 'Сотрудники и доступы',
            'model': PersonnelPosition,
            'form_class': PersonnelPositionReferenceForm,
            'description': 'Официальные должности из 1С. Одна должность действует у сотрудника одновременно; она определяет допустимые базовые специализации.',
            'fields': ['name', 'code', 'requires_specialization', 'allowed_specializations', 'default_specialization', 'is_active'],
            'search_fields': ['name', 'code', 'allowed_specializations__name', 'default_specialization__name'],
            'preview_fields': ['code', 'requires_specialization', 'allowed_specializations', 'default_specialization', 'is_active'],
            'prefetch_related': ['allowed_specializations'],
            'select_related': ['default_specialization'],
            'initial': {'is_active': True},
            'admin_url': '/admin/users/personnelposition/',
        },
        'production-specializations': {
            'title': 'Производственные специализации',
            'section': 'Сотрудники и доступы',
            'model': ProductionSpecialization,
            'description': 'Определяют доступность сотрудника для расстановки и соответствующее приложение. Базовая специализация может быть временно заменена переводом до конца вахты.',
            'fields': ['name', 'code', 'equipment_type', 'access_role', 'is_active'],
            'search_fields': ['name', 'code', 'equipment_type__name', 'access_role__name'],
            'preview_fields': ['code', 'equipment_type', 'access_role', 'is_active'],
            'select_related': ['equipment_type', 'access_role'],
            'initial': {'is_active': True},
            'admin_url': '/admin/users/productionspecialization/',
        },
        'equipment-types': {
            'title': 'Виды техники',
            'section': 'Техника',
            'model': EquipmentType,
            'search_fields': ['name'],
            'preview_fields': ['name', 'is_active'],
            'admin_url': '/admin/references/equipmenttype/',
        },
        'equipment-models': {
            'title': 'Модели техники',
            'section': 'Техника',
            'model': EquipmentModel,
            'description': 'Марки и модели техники с их рабочими характеристиками. Для экскаватора укажите фактический объем ковша.',
            'fields': ['equipment_type', 'name', 'body_volume_m3', 'payload_tons', 'fuel_capacity_limit_l', 'is_active'],
            'search_fields': ['name', 'equipment_type__name'],
            'preview_fields': ['equipment_type', 'body_volume_m3', 'payload_tons', 'fuel_capacity_limit_l', 'is_active'],
            'select_related': ['equipment_type'],
            'initial': {'is_active': True},
            'help_texts': {
                'body_volume_m3': 'Для экскаватора укажите фактический объем ковша в м3.',
                'payload_tons': 'Для экскаватора это поле можно оставить пустым.',
            },
            'admin_url': '/admin/references/equipmentmodel/',
        },
        'equipment': {
            'title': 'Техника',
            'section': 'Техника',
            'model': Equipment,
            'description': 'Отдельные единицы техники. Для подрядной техники снимите флажок «Собственная техника» и выберите организацию-владельца.',
            'fields': ['equipment_type', 'model', 'garage_number', 'vin', 'is_own', 'contractor_organization', 'is_active'],
            'labels': {'is_own': 'Собственная техника'},
            'help_texts': {
                'is_own': 'Снимите флажок, если техника принадлежит подрядчику.',
                'contractor_organization': 'Для подрядной техники организация обязательна.',
            },
            'search_fields': ['garage_number', 'vin', 'equipment_type__name', 'model__name', 'contractor_organization__name'],
            'preview_fields': ['equipment_type', 'garage_number', 'model', 'contractor_organization', 'vin'],
            'select_related': ['equipment_type', 'model', 'contractor_organization'],
            'admin_url': '/admin/references/equipment/',
        },
        'equipment-states': {
            'title': 'Состояния техники',
            'section': 'Техника',
            'model': EquipmentState,
            'search_fields': ['code', 'name', 'short_label', 'description'],
            'preview_fields': ['code', 'name', 'short_label', 'color_group', 'semantic_group'],
            'admin_url': '/admin/references/equipmentstate/',
        },
        'downtime-reasons': {
            'title': 'Общий список простоев',
            'section': 'Простои',
            'model': DowntimeReason,
            'fields': [
                'name',
                'short_label',
                'equipment_type',
                'equipment_state',
                'is_critical',
                'show_for_truck_driver',
                'show_for_excavator_operator',
                'show_for_mechanic',
                'sort_order',
                'is_active',
            ],
            'search_fields': ['name', 'short_label', 'equipment_type__name', 'equipment_state__name'],
            'preview_fields': ['short_label', 'equipment_type', 'equipment_state', 'show_for_truck_driver', 'show_for_excavator_operator', 'show_for_mechanic'],
            'select_related': ['equipment_type', 'equipment_state'],
            'admin_url': '/admin/downtimes/downtimereason/',
        },
        'truck-driver-downtimes': {
            'title': 'Простои водителя самосвала',
            'section': 'Простои',
            'model': DowntimeReason,
            'fields': ['name', 'short_label', 'equipment_type', 'equipment_state', 'is_critical', 'show_for_truck_driver', 'sort_order', 'is_active'],
            'search_fields': ['name', 'short_label', 'equipment_type__name', 'equipment_state__name'],
            'preview_fields': ['short_label', 'equipment_type', 'equipment_state', 'is_critical', 'show_for_truck_driver'],
            'select_related': ['equipment_type', 'equipment_state'],
            'base_filter': {'show_for_truck_driver': True},
            'initial': {'show_for_truck_driver': True},
            'admin_url': '/admin/downtimes/downtimereason/',
        },
        'excavator-operator-downtimes': {
            'title': 'Простои машиниста экскаватора',
            'section': 'Простои',
            'model': DowntimeReason,
            'fields': ['name', 'short_label', 'equipment_type', 'equipment_state', 'is_critical', 'show_for_excavator_operator', 'sort_order', 'is_active'],
            'search_fields': ['name', 'short_label', 'equipment_type__name', 'equipment_state__name'],
            'preview_fields': ['short_label', 'equipment_type', 'equipment_state', 'is_critical', 'show_for_excavator_operator'],
            'select_related': ['equipment_type', 'equipment_state'],
            'base_filter': {'show_for_excavator_operator': True},
            'initial': {'show_for_excavator_operator': True},
            'admin_url': '/admin/downtimes/downtimereason/',
        },
        'mechanic-downtimes': {
            'title': 'Детальные простои механика',
            'section': 'Простои',
            'model': DowntimeReason,
            'fields': ['name', 'short_label', 'equipment_type', 'equipment_state', 'is_critical', 'show_for_mechanic', 'sort_order', 'is_active'],
            'search_fields': ['name', 'short_label', 'equipment_type__name', 'equipment_state__name'],
            'preview_fields': ['short_label', 'equipment_type', 'equipment_state', 'is_critical', 'show_for_mechanic'],
            'select_related': ['equipment_type', 'equipment_state'],
            'base_filter': {'show_for_mechanic': True},
            'initial': {'show_for_mechanic': True},
            'admin_url': '/admin/downtimes/downtimereason/',
        },
        'rocks': {
            'title': 'Породы',
            'section': 'Производство',
            'model': RockType,
            'description': 'Породы, плотности и кубатура рейса для каждой модели самосвала.',
            'search_fields': ['name'],
            'preview_fields': ['name', 'density', 'loosening_factor'],
            'admin_url': '/admin/references/rocktype/',
        },
        'dump-points': {
            'title': 'Точки разгрузки',
            'section': 'Производство',
            'model': DumpPoint,
            'search_fields': ['name'],
            'preview_fields': ['name', 'is_active'],
            'admin_url': '/admin/references/dumppoint/',
        },
        'equipment-plan-groups': {
            'title': 'Ежесменные планы техники',
            'section': 'Производство',
            'model': EquipmentPlanGroup,
            'form_class': EquipmentPlanGroupForm,
            'description': 'Один активный план задается на группу техники и автоматически фиксируется snapshot при открытии смены.',
            'fields': ['name', 'code', 'calculation_mode', 'plan_value', 'equipment', 'is_active', 'active_from', 'comment'],
            'search_fields': ['name', 'code', 'comment', 'equipment__garage_number', 'equipment__equipment_type__name', 'equipment__model__name'],
            'preview_fields': ['calculation_mode', 'plan_value', 'equipment', 'is_active', 'active_from', 'updated_by', 'updated_at'],
            'select_related': ['updated_by'],
            'prefetch_related': ['equipment', 'equipment__equipment_type', 'equipment__model'],
            'initial': {'is_active': True},
            'field_choices': {
                'calculation_mode': [
                    (PlanCalculationMode.TRIPS, 'По рейсам'),
                    (PlanCalculationMode.VOLUME, 'По объему, м3'),
                ],
            },
            'admin_url': '/admin/shifts/equipmentplangroup/',
        },
        'achievement-prizes': {
            'title': 'Приз за 100% плана',
            'section': 'Производство',
            'model': AchievementPrize,
            'description': 'Одна активная призовая картинка для водителей самосвалов и машинистов экскаваторов. Активная картинка выдается только после выполнения 100% сменного плана.',
            'fields': ['title', 'image', 'is_active'],
            'search_fields': ['title'],
            'preview_fields': ['title', 'image', 'is_active', 'updated_at'],
            'initial': {'title': 'План выполнен', 'is_active': True},
            'admin_url': '/admin/shifts/achievementprize/',
        },
        'shift-plans': {
            'title': 'Сменные планы (история)',
            'section': 'Производство',
            'model': ShiftPlan,
            'description': 'Старая схема планов по дате и смене сохранена для истории и совместимости. Основной способ - ежесменные планы техники.',
            'fields': ['plan_scope', 'name', 'plan_volume_m3', 'is_active', 'comment'],
            'search_fields': ['name', 'comment'],
            'preview_fields': ['plan_scope', 'plan_volume_m3'],
            'select_related': ['created_by'],
            'initial': {'plan_scope': ShiftPlanScope.DAY_SHIFT, 'name': 'Дневной сменный план', 'is_active': True},
            'hide_actions_card': True,
            'admin_url': '/admin/shifts/shiftplan/',
        },
        'equipment-shift-plans': {
            'title': 'Планы техники (история)',
            'section': 'Производство',
            'model': EquipmentShiftPlan,
            'description': 'Старая схема планов по конкретной технике на дату/смену. Для новых смен используйте ежесменные планы техники.',
            'fields': ['shift_plan', 'equipment', 'employee', 'calculation_mode', 'plan_trips', 'plan_volume_m3', 'is_active', 'comment'],
            'search_fields': ['shift_plan__name', 'equipment__garage_number', 'equipment__equipment_type__name', 'employee__full_name', 'comment'],
            'preview_fields': ['shift_plan', 'equipment', 'employee', 'calculation_mode', 'plan_trips', 'plan_volume_m3'],
            'select_related': ['shift_plan', 'equipment', 'equipment__equipment_type', 'employee'],
            'initial': {'is_active': True},
            'field_choices': {
                'calculation_mode': [
                    (PlanCalculationMode.TRIPS, 'По рейсам'),
                    (PlanCalculationMode.VOLUME, 'По объему, м3'),
                ],
            },
            'admin_url': '/admin/shifts/equipmentshiftplan/',
        },
        'dormitories': {
            'title': 'Общежития',
            'section': 'Проживание',
            'model': Dormitory,
            'search_fields': ['number'],
            'preview_fields': ['number', 'is_active'],
            'admin_url': '/admin/references/dormitory/',
        },
        'dormitory-sections': {
            'title': 'Секции общежитий',
            'section': 'Проживание',
            'model': DormitorySection,
            'search_fields': ['name', 'block__name', 'block__dormitory__number'],
            'preview_fields': ['block', 'name', 'day_capacity', 'night_capacity'],
            'select_related': ['block', 'block__dormitory'],
            'admin_url': '/admin/references/dormitorysection/',
        },
    }


def build_reference_form(model, config=None):
    config = config or {}
    if config.get('form_class'):
        form_class = config['form_class']
        field_choices = config.get('field_choices') or {}
        if not field_choices:
            return form_class

        class ReferenceForm(form_class):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                for field_name, choices in field_choices.items():
                    if field_name in self.fields:
                        self.fields[field_name].choices = choices

        return ReferenceForm

    editable_fields = config.get('fields') or [
        field.name
        for field in model._meta.fields
        if field.name != 'id' and getattr(field, 'editable', True)
    ]
    form_class = modelform_factory(
        model,
        fields=editable_fields,
        labels=config.get('labels'),
        help_texts=config.get('help_texts'),
    )
    field_choices = config.get('field_choices') or {}
    if not field_choices:
        return form_class

    class ReferenceForm(form_class):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            for field_name, choices in field_choices.items():
                if field_name in self.fields:
                    self.fields[field_name].choices = choices

    return ReferenceForm


def prepare_reference_record_for_save(reference_code, record, access):
    if reference_code == 'shift-plans':
        if not record.date:
            record.date = timezone.localdate()
        record.plan_trips = None
        record.plan_tonnage = None
        if not record.created_by_id:
            record.created_by = access.employee
    elif reference_code == 'equipment-shift-plans':
        record.plan_tonnage = None
    elif reference_code == 'equipment-plan-groups':
        record.updated_by = access.employee
    return record


def build_reference_queryset(config):
    queryset = config['model'].objects.all()
    base_filter = config.get('base_filter') or {}
    if base_filter:
        queryset = queryset.filter(**base_filter)
    select_related = config.get('select_related') or []
    if select_related:
        queryset = queryset.select_related(*select_related)
    prefetch_related = config.get('prefetch_related') or []
    if prefetch_related:
        queryset = queryset.prefetch_related(*prefetch_related)
    return queryset


def build_reference_search_filter(search_fields, query):
    search_filter = Q()
    for field_name in search_fields:
        search_filter |= Q(**{f'{field_name}__icontains': query})
    return search_filter


def get_reference_status(record):
    if hasattr(record, 'is_active') and not record.is_active:
        return 'Отключен', 'neutral'
    return 'Активен', 'ok'


def get_reference_record_preview(record, config):
    preview = []
    for field_name in config.get('preview_fields', []):
        try:
            field = record._meta.get_field(field_name)
            label = config.get('preview_labels', {}).get(
                field_name,
                field.verbose_name,
            )
            value = getattr(record, field_name)
            if getattr(field, 'many_to_many', False):
                value = ', '.join(str(item) for item in value.all()) or 'Не указано'
            elif field.get_internal_type() == 'BooleanField':
                value = 'Да' if value else 'Нет'
            elif getattr(field, 'choices', None):
                value = getattr(record, f'get_{field_name}_display')()
            elif value in (None, ''):
                value = 'Не указано'
        except FieldDoesNotExist:
            label = config.get('preview_labels', {}).get(
                field_name,
                field_name.replace('_', ' '),
            )
            value = getattr(record, field_name, '')
            if callable(value):
                value = value()
            if value in (None, ''):
                value = 'Не указано'
        preview.append({'label': label, 'value': value})
    return preview


class CapacityDecimalField(forms.DecimalField):
    def to_python(self, value):
        if isinstance(value, str):
            value = value.strip().replace(',', '.')
        return super().to_python(value)


def build_rock_capacity_rules_form(rock_type=None, data=None):
    existing_rules = {}
    if rock_type and rock_type.pk:
        existing_rules = {
            rule.equipment_model_id: rule
            for rule in TruckCapacityRule.objects.filter(rock_type=rock_type).select_related('equipment_model')
        }

    truck_models = (
        EquipmentModel.objects
        .filter(equipment_type__name__icontains='Самосвал')
        .filter(Q(is_active=True) | Q(id__in=existing_rules))
        .select_related('equipment_type')
        .order_by('name', 'id')
        .distinct()
    )

    capacity_form = forms.Form(data=data)
    capacity_form.capacity_models = {}
    capacity_form.capacity_rows = []
    for equipment_model in truck_models:
        field_name = f'capacity_model_{equipment_model.id}'
        current_rule = existing_rules.get(equipment_model.id)
        capacity_form.fields[field_name] = CapacityDecimalField(
            label=f'Кубатура для {equipment_model.name}, м³',
            required=False,
            min_value=Decimal('0.01'),
            max_digits=10,
            decimal_places=2,
            initial=current_rule.volume_m3 if current_rule else None,
            widget=forms.TextInput(attrs={
                'class': 'rock-capacity-input',
                'inputmode': 'decimal',
                'placeholder': 'Например, 52',
                'autocomplete': 'off',
            }),
        )
        capacity_form.capacity_models[field_name] = equipment_model

    for field_name, equipment_model in capacity_form.capacity_models.items():
        current_rule = existing_rules.get(equipment_model.id)
        capacity_form.capacity_rows.append({
            'model': equipment_model,
            'field': capacity_form[field_name],
            'has_explicit_rule': current_rule is not None,
            'fallback_volume': equipment_model.body_volume_m3,
        })
    return capacity_form


def save_rock_capacity_rules(rock_type, capacity_form):
    changes = []
    existing_rules = {
        rule.equipment_model_id: rule
        for rule in TruckCapacityRule.objects.filter(rock_type=rock_type)
    }
    for field_name, equipment_model in capacity_form.capacity_models.items():
        new_volume = capacity_form.cleaned_data.get(field_name)
        current_rule = existing_rules.get(equipment_model.id)
        old_volume = current_rule.volume_m3 if current_rule else None
        if new_volume is None:
            if current_rule:
                current_rule.delete()
            else:
                continue
        elif current_rule:
            if current_rule.volume_m3 == new_volume:
                continue
            current_rule.volume_m3 = new_volume
            current_rule.save(update_fields=['volume_m3'])
        else:
            TruckCapacityRule.objects.create(
                equipment_model=equipment_model,
                rock_type=rock_type,
                volume_m3=new_volume,
            )
        changes.append({
            'model': equipment_model.name,
            'old': old_volume,
            'new': new_volume,
        })
    return changes


def format_capacity_change_value(value):
    return f'{value} м³' if value is not None else 'общий объем модели'


def _add_validation_error_to_form(form, error):
    if hasattr(error, 'message_dict'):
        for field_name, field_messages in error.message_dict.items():
            target_field = field_name if field_name in form.fields else None
            for field_message in field_messages:
                form.add_error(target_field, field_message)
        return
    for message in error.messages:
        form.add_error(None, message)


def _rating_period_automation_context():
    inspection = inspect_rating_period_calendar()
    prepared = inspection.prepared_through
    current_start = inspection.current_nominal_start
    return {
        'rule_label': '14-е → 14-е',
        'horizon_label': (
            f'{current_start:%d.%m.%Y}–'
            f'{inspection.horizon_end - timedelta(days=1):%d.%m.%Y}'
        ),
        'prepared_through_label': (
            f'{prepared - timedelta(days=1):%d.%m.%Y}'
            if prepared > current_start
            else 'не сформирован'
        ),
        'automatic_count': inspection.automatic_count,
        'manual_count': inspection.manual_count,
        'override_count': inspection.override_count,
        'gap_count': len(inspection.gap_ranges),
        'overlap_count': len(inspection.overlap_pairs),
        'is_ready': inspection.is_ready,
        'gaps': [
            (
                f'{starts_on:%d.%m.%Y}–'
                f'{ends_before - timedelta(days=1):%d.%m.%Y}'
            )
            for starts_on, ends_before in inspection.gap_ranges[:3]
        ],
    }


def system_admin_reference_detail_view(request, reference_code):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    configs = get_system_admin_reference_configs()
    config = configs.get(reference_code)
    if not config:
        messages.error(request, 'Справочник не найден.')
        return redirect('system_admin_references')

    model = config['model']
    form_class = build_reference_form(model, config)
    query = request.GET.get('q', '').strip()
    status_filter = request.GET.get('status', '').strip()
    edit_id = request.GET.get('edit', '').strip()
    selected_record = None
    rock_capacity_form = None
    if edit_id.isdigit():
        selected_record = get_object_or_404(build_reference_queryset(config), id=edit_id)

    def reference_detail_redirect_url(record_id=None):
        params = []
        if query:
            params.append(('q', query))
        if status_filter:
            params.append(('status', status_filter))
        if record_id:
            params.append(('edit', record_id))
        query_string = urlencode(params)
        url = reverse('system_admin_reference_detail', kwargs={'reference_code': reference_code})
        return f'{url}?{query_string}' if query_string else url

    if request.method == 'POST':
        action = request.POST.get('action', 'save')
        record_id = request.POST.get('record_id', '').strip()
        record = None
        if record_id.isdigit():
            record = get_object_or_404(model, id=record_id)
            selected_record = record

        if action in {'disable', 'enable'} and record and hasattr(record, 'is_active'):
            try:
                if reference_code == 'rating-periods':
                    with transaction.atomic():
                        RatingPeriod.lock_catalog()
                        record = (
                            RatingPeriod._base_manager
                            .select_for_update()
                            .get(pk=record.pk)
                        )
                        old_value = record.audit_value()
                        record.is_active = action == 'enable'
                        record.save(update_fields=['is_active'])
                        new_value = record.audit_value()
                        action_label = (
                            'Период рейтинга включён'
                            if record.is_active
                            else 'Период рейтинга отключён'
                        )
                        log_admin_action(
                            access.employee,
                            action_label,
                            record,
                            old_value,
                            new_value,
                        )
                else:
                    with transaction.atomic():
                        # The reference row, any Equipment disable side
                        # effects, and their operational journal events must
                        # either all commit or all roll back.
                        record = (
                            model._base_manager
                            .select_for_update()
                            .get(pk=record.pk)
                        )
                        old_value = (
                            'Активен' if record.is_active else 'Отключен'
                        )
                        record.is_active = action == 'enable'
                        record.save(update_fields=['is_active'])
                        new_value = (
                            'Активен' if record.is_active else 'Отключен'
                        )
                        log_admin_action(
                            access.employee,
                            f'Справочник: {config["title"]}',
                            record,
                            old_value,
                            new_value,
                        )
            except ValidationError as error:
                error_messages = []
                if hasattr(error, 'message_dict'):
                    for field_messages in error.message_dict.values():
                        error_messages.extend(field_messages)
                else:
                    error_messages.extend(error.messages)
                messages.error(
                    request,
                    'Состояние записи не изменено. '
                    + ' '.join(str(message) for message in error_messages),
                )
                return redirect(reference_detail_redirect_url(record.id))
            messages.success(request, 'Состояние записи обновлено.')
            return redirect(reference_detail_redirect_url(record.id))

        form = form_class(request.POST, request.FILES, instance=record)
        if reference_code == 'rocks':
            rock_capacity_form = build_rock_capacity_rules_form(record, data=request.POST)
        form_is_valid = form.is_valid()
        capacity_form_is_valid = rock_capacity_form.is_valid() if rock_capacity_form else True
        if form_is_valid and capacity_form_is_valid:
            saved_record = form.save(commit=False)
            saved_record = prepare_reference_record_for_save(reference_code, saved_record, access)
            try:
                if reference_code == 'rating-periods':
                    with transaction.atomic():
                        RatingPeriod.lock_catalog()
                        old_audit_value = ''
                        if saved_record.pk:
                            stored_record = (
                                RatingPeriod._base_manager
                                .select_for_update()
                                .get(pk=saved_record.pk)
                            )
                            old_audit_value = stored_record.audit_value()
                        saved_record.save()
                        form.save_m2m()
                        log_admin_action(
                            access.employee,
                            (
                                'Период рейтинга изменён'
                                if record is not None
                                else 'Период рейтинга создан вручную'
                            ),
                            saved_record,
                            old_audit_value,
                            saved_record.audit_value(),
                        )
                elif reference_code == 'rocks':
                    with transaction.atomic():
                        saved_record.save()
                        form.save_m2m()
                        capacity_changes = save_rock_capacity_rules(
                            saved_record,
                            rock_capacity_form,
                        )
                        log_admin_action(
                            access.employee,
                            f'Справочник: {config["title"]}',
                            saved_record,
                            '',
                            'Сохранено',
                        )
                        if capacity_changes:
                            log_admin_action(
                                access.employee,
                                'Справочник: кубатура самосвалов по породе',
                                saved_record,
                                old_value='; '.join(
                                    f'{item["model"]}: {format_capacity_change_value(item["old"])}'
                                    for item in capacity_changes
                                ),
                                new_value='; '.join(
                                    f'{item["model"]}: {format_capacity_change_value(item["new"])}'
                                    for item in capacity_changes
                                ),
                            )
                elif reference_code == 'equipment-plan-groups':
                    with transaction.atomic():
                        saved_record.save()
                        form.save_m2m()
                        refreshed_open_shifts = refresh_open_shift_plan_snapshots_for_group(saved_record)
                        log_admin_action(
                            access.employee,
                            f'Справочник: {config["title"]}',
                            saved_record,
                            '',
                            f'Сохранено; открытых смен пересчитано: {refreshed_open_shifts}',
                        )
                else:
                    with transaction.atomic():
                        if saved_record.pk:
                            (
                                model._base_manager
                                .select_for_update()
                                .get(pk=saved_record.pk)
                            )
                        saved_record.save()
                        form.save_m2m()
                        log_admin_action(
                            access.employee,
                            f'Справочник: {config["title"]}',
                            saved_record,
                            '',
                            'Сохранено',
                        )
            except ValidationError as error:
                _add_validation_error_to_form(form, error)
            else:
                messages.success(request, 'Запись справочника сохранена.')
                return redirect(reference_detail_redirect_url(saved_record.id))
    else:
        form_initial = None if selected_record else config.get('initial')
        form = form_class(instance=selected_record, initial=form_initial)
        if reference_code == 'rocks':
            rock_capacity_form = build_rock_capacity_rules_form(selected_record)

    records_queryset = build_reference_queryset(config)
    if query:
        records_queryset = records_queryset.filter(build_reference_search_filter(config.get('search_fields', []), query)).distinct()
    if status_filter and hasattr(model, 'is_active'):
        records_queryset = records_queryset.filter(is_active=status_filter == 'active')

    records = []
    for record in records_queryset[:300]:
        status_label, status_class = get_reference_status(record)
        records.append({
            'object': record,
            'title': str(record),
            'status_label': status_label,
            'status_class': status_class,
            'preview': get_reference_record_preview(record, config),
        })

    count_queryset = build_reference_queryset(config)
    active_total = count_queryset.filter(is_active=True).count() if hasattr(model, 'is_active') else count_queryset.count()
    inactive_total = count_queryset.filter(is_active=False).count() if hasattr(model, 'is_active') else 0

    return render(
        request,
        'users/system_admin_reference_detail.html',
        {
            'access': access,
            'reference_code': reference_code,
            'reference_config': config,
            'form': form,
            'selected_record': selected_record,
            'records': records,
            'records_total': count_queryset.count(),
            'active_total': active_total,
            'inactive_total': inactive_total,
            'query': query,
            'status_filter': status_filter,
            'has_active_status': hasattr(model, 'is_active'),
            'show_rock_capacity_settings': reference_code == 'rocks',
            'rock_capacity_form': rock_capacity_form,
            'rock_capacity_rows': rock_capacity_form.capacity_rows if rock_capacity_form else [],
            'rating_period_automation': (
                _rating_period_automation_context()
                if reference_code == 'rating-periods'
                else None
            ),
        },
    )


def system_admin_conflicts_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    status = request.GET.get('status', '').strip()
    query = request.GET.get('q', '').strip()
    conflicts = AdminConflict.objects.select_related('employee', 'role').order_by('-created_at')
    if status:
        conflicts = conflicts.filter(status=status)
    if query:
        conflicts = conflicts.filter(
            Q(conflict_type__icontains=query)
            | Q(process__icontains=query)
            | Q(description__icontains=query)
            | Q(comment__icontains=query)
            | Q(employee__full_name__icontains=query)
            | Q(role__name__icontains=query)
        )

    conflict_status_counts = {
        item['status']: item['total']
        for item in AdminConflict.objects.values('status').annotate(total=Count('id'))
    }
    conflicts = list(conflicts[:200])
    conflict_employees = attach_application_presence(
        conflict.employee for conflict in conflicts if conflict.employee_id
    )
    conflict_presence_by_employee_id = {
        employee.pk: employee.application_presence
        for employee in conflict_employees
    }
    for conflict in conflicts:
        conflict.application_presence = conflict_presence_by_employee_id.get(
            conflict.employee_id
        )
        if conflict.status == AdminConflict.Status.OPEN:
            conflict.status_class = 'danger'
        elif conflict.status == AdminConflict.Status.IN_PROGRESS:
            conflict.status_class = 'warning'
        elif conflict.status == AdminConflict.Status.RESOLVED:
            conflict.status_class = 'ok'
        else:
            conflict.status_class = 'neutral'

    return render(
        request,
        'users/system_admin_conflicts.html',
        {
            'access': access,
            'conflicts': conflicts,
            'statuses': AdminConflict.Status.choices,
            'selected_status': status,
            'query': query,
            'open_total': conflict_status_counts.get(AdminConflict.Status.OPEN, 0),
            'in_progress_total': conflict_status_counts.get(AdminConflict.Status.IN_PROGRESS, 0),
            'resolved_total': conflict_status_counts.get(AdminConflict.Status.RESOLVED, 0),
            'rejected_total': conflict_status_counts.get(AdminConflict.Status.REJECTED, 0),
            'conflict_total': sum(conflict_status_counts.values()),
        },
    )


def system_admin_conflict_action_view(request, conflict_id, action):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    conflict = get_object_or_404(AdminConflict, id=conflict_id)
    if request.method == 'POST':
        status_by_action = {
            'in-progress': AdminConflict.Status.IN_PROGRESS,
            'resolved': AdminConflict.Status.RESOLVED,
            'rejected': AdminConflict.Status.REJECTED,
        }
        new_status = status_by_action.get(action)
        if new_status:
            old_status = conflict.get_status_display()
            conflict.status = new_status
            conflict.resolved_by = access.employee
            conflict.resolved_at = timezone.now()
            conflict.save(update_fields=['status', 'resolved_by', 'resolved_at'])
            log_admin_action(
                access.employee,
                'Изменен статус административного конфликта',
                conflict,
                old_value=old_status,
                new_value=conflict.get_status_display(),
            )
            messages.success(request, 'Статус конфликта обновлен.')

    redirect_url = request.POST.get('next') or 'system_admin_conflicts'
    if redirect_url == 'dashboard':
        return redirect('system_admin_dashboard')
    return redirect('system_admin_conflicts')


def system_admin_logs_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    query = request.GET.get('q', '').strip()
    log_type = request.GET.get('type', '').strip()
    logs = AdminActionLog.objects.select_related('actor', 'reversal_of').order_by('-created_at')
    if query:
        logs = logs.filter(
            Q(action__icontains=query)
            | Q(object_type__icontains=query)
            | Q(object_repr__icontains=query)
            | Q(comment__icontains=query)
            | Q(actor__full_name__icontains=query)
        )
    if log_type:
        if log_type == 'access':
            logs = logs.filter(Q(action__icontains='доступ') | Q(action__icontains='пинкод') | Q(object_type__icontains='Access'))
        elif log_type == 'employee':
            logs = logs.filter(Q(action__icontains='сотрудник') | Q(object_type__icontains='Employee'))
        elif log_type == 'conflict':
            logs = logs.filter(Q(action__icontains='конфликт') | Q(object_type__icontains='AdminConflict'))
        elif log_type == 'reference':
            logs = logs.filter(Q(action__icontains='Справочник') | Q(object_type__icontains='references'))
        elif log_type == 'oup':
            logs = logs.filter(Q(action__startswith='ОУП:') | Q(action_code='admin_oup_action_reversed'))

    total_logs = AdminActionLog.objects.count()
    access_total = AdminActionLog.objects.filter(Q(action__icontains='доступ') | Q(action__icontains='пинкод') | Q(object_type__icontains='Access')).count()
    employee_total = AdminActionLog.objects.filter(Q(action__icontains='сотрудник') | Q(object_type__icontains='Employee')).count()
    conflict_total = AdminActionLog.objects.filter(Q(action__icontains='конфликт') | Q(object_type__icontains='AdminConflict')).count()
    oup_total = AdminActionLog.objects.filter(action__startswith='ОУП:').count()
    logs = list(logs[:200])
    for log in logs:
        action_text = f'{log.action} {log.object_type}'.lower()
        if log.action.startswith('ОУП:'):
            log.type_label = 'ОУП'
            log.type_class = 'info'
            log.undo_state = get_oup_action_undo_state(log)
        elif log.action_code == 'admin_oup_action_reversed':
            log.type_label = 'Отмена ОУП'
            log.type_class = 'ok'
            log.undo_state = None
        elif 'конфликт' in action_text or 'adminconflict' in action_text:
            log.type_label = 'Конфликт'
            log.type_class = 'danger'
        elif 'доступ' in action_text or 'пинкод' in action_text or 'access' in action_text:
            log.type_label = 'Доступ'
            log.type_class = 'warning'
        elif 'сотрудник' in action_text or 'employee' in action_text:
            log.type_label = 'Сотрудник'
            log.type_class = 'ok'
        elif 'справочник' in action_text:
            log.type_label = 'Справочник'
            log.type_class = 'neutral'
        else:
            log.type_label = 'Действие'
            log.type_class = 'neutral'
            log.undo_state = None

    return render(
        request,
        'users/system_admin_logs.html',
        {
            'access': access,
            'logs': logs,
            'query': query,
            'selected_log_type': log_type,
            'total_logs': total_logs,
            'access_log_total': access_total,
            'employee_log_total': employee_total,
            'conflict_log_total': conflict_total,
            'oup_log_total': oup_total,
            'return_url': request.get_full_path(),
        },
    )


@require_POST
def system_admin_undo_oup_action_view(request, log_id):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')
    try:
        result, _reversal = undo_oup_action(
            log_id=log_id,
            actor_access_id=access.pk,
            comment=request.POST.get('comment', '').strip(),
        )
    except ValidationError as error:
        messages.error(request, '; '.join(error.messages))
    else:
        messages.success(request, result)
    return redirect_after_admin_action(request, 'system_admin_logs')


def system_admin_exports_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    export_groups = [
        {
            'title': 'Администрирование',
            'items': [
                {
                    'title': 'Сотрудники',
                    'description': 'Кадровая карточка, статус, телефон, вахта и проживание.',
                    'url_name': 'system_admin_employee_export',
                    'count': Employee.objects.count(),
                    'status_label': 'готово',
                    'status_class': 'ok',
                },
                {
                    'title': 'Доступы',
                    'description': 'Роли, статусы входа, даты выдачи, активации и последнего входа.',
                    'url_name': 'system_admin_access_export',
                    'count': EmployeeAccess.objects.count(),
                    'status_label': 'готово',
                    'status_class': 'ok',
                },
                {
                    'title': 'Журнал действий',
                    'description': 'История административных действий для сверки и аудита.',
                    'url_name': 'system_admin_log_export',
                    'count': AdminActionLog.objects.count(),
                    'status_label': 'готово',
                    'status_class': 'ok',
                },
                {
                    'title': 'Конфликты',
                    'description': 'Заблокированные рискованные действия и статусы разбора.',
                    'url_name': 'system_admin_conflict_export',
                    'count': AdminConflict.objects.count(),
                    'status_label': 'готово',
                    'status_class': 'warning' if AdminConflict.objects.filter(status=AdminConflict.Status.OPEN).exists() else 'ok',
                },
            ],
        },
        {
            'title': 'Рабочие отчеты MVP',
            'items': [
                {
                    'title': 'Объемы',
                    'description': 'Производственный отчет по рейсам, группировкам и шаблонам.',
                    'external_url': '/reports/volume/export/',
                    'count': Trip.objects.count(),
                    'status_label': 'отчет',
                    'status_class': 'neutral',
                },
                {
                    'title': 'Суточный отчет заказчику',
                    'description': 'Суточная форма по дате отчета для внешней сверки.',
                    'external_url': '/reports/customer-daily/export/',
                    'count': Trip.objects.count(),
                    'status_label': 'отчет',
                    'status_class': 'neutral',
                },
                {
                    'title': 'Витрина руководства',
                    'description': 'Excel-срез руководителя: сводка, динамика и сравнение смен.',
                    'external_url': '/reports/management/export/',
                    'count': Trip.objects.count(),
                    'status_label': 'отчет',
                    'status_class': 'neutral',
                },
                {
                    'title': 'Механические простои',
                    'description': 'Отчет по простоям техники с фильтрами механической службы.',
                    'external_url': '/reports/downtimes/export/',
                    'count': 0,
                    'status_label': 'отчет',
                    'status_class': 'neutral',
                },
            ],
        },
    ]
    export_total = sum(len(group['items']) for group in export_groups)
    ready_total = sum(1 for group in export_groups for item in group['items'] if item['status_class'] == 'ok')
    warning_total = sum(1 for group in export_groups for item in group['items'] if item['status_class'] == 'warning')

    return render(
        request,
        'users/system_admin_exports.html',
        {
            'access': access,
            'export_groups': export_groups,
            'export_total': export_total,
            'ready_total': ready_total,
            'warning_total': warning_total,
        },
    )


EMPLOYEES_WITHOUT_POSITION = 'none'


def system_admin_employees_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    employees = (
        Employee.objects
        .select_related('personnel_position', 'contractor_organization')
        .prefetch_related('accesses__role')
        .order_by('full_name')
    )
    status = request.GET.get('status', '').strip()
    access_status = request.GET.get('access_status', '').strip()
    role_id = request.GET.get('role', '').strip()
    personnel_position = request.GET.get('personnel_position', '').strip()
    employment_type = request.GET.get('employment_type', '').strip()
    contractor_organization = request.GET.get('contractor_organization', '').strip()
    query = request.GET.get('q', '').strip()
    if status:
        employees = employees.filter(status=status)
    if access_status:
        employees = employees.filter(accesses__status=access_status).distinct()
    if role_id.isdigit():
        employees = employees.filter(accesses__role_id=int(role_id)).distinct()
    if employment_type in Employee.EmploymentType.values:
        employees = employees.filter(employment_type=employment_type)
    if contractor_organization.isdigit():
        employees = employees.filter(contractor_organization_id=int(contractor_organization))
    # Разметка фильтра по должности была на месте, а данные в неё не приходили:
    # список открывался пустым, и выбор в нём ничего не менял.
    if personnel_position == EMPLOYEES_WITHOUT_POSITION:
        employees = employees.filter(personnel_position__isnull=True)
    elif personnel_position.isdigit():
        employees = employees.filter(personnel_position_id=int(personnel_position))
    if query:
        employees = employees.filter(full_name__icontains=query)
    employees = attach_application_presence(employees)

    return render(
        request,
        'users/system_admin_employees.html',
        {
            'access': access,
            'employees': employees,
            'statuses': Employee.Status.choices,
            'access_statuses': EmployeeAccess.Status.choices,
            'roles': Role.objects.filter(is_active=True).order_by('name'),
            'personnel_positions': (
                PersonnelPosition.objects.filter(is_active=True).order_by('name')
            ),
            'employment_types': Employee.EmploymentType.choices,
            'contractor_organizations': ContractorOrganization.objects.filter(is_active=True).order_by('name'),
            # Отдельной строкой — те, у кого должность не проставлена: при разборе
            # выгрузки из отдела кадров их надо находить в первую очередь.
            'personnel_position_groups': [
                (EMPLOYEES_WITHOUT_POSITION, 'Без кадровой должности'),
            ],
            'selected_status': status,
            'selected_access_status': access_status,
            'selected_role': role_id,
            'selected_personnel_position': personnel_position,
            'selected_employment_type': employment_type,
            'selected_contractor_organization': contractor_organization,
            'query': query,
        },
    )


def system_admin_employee_create_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    if request.method == 'POST':
        form = AdminEmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                with transaction.atomic():
                    role = form.cleaned_data.get('role')
                    employee = form.save(commit=False)
                    employee.status = Employee.Status.ACTIVE
                    employee.is_active = True
                    employee.dismissed_at = None
                    employee.save()
                    code = ''
                    if role and form.cleaned_data['generate_access']:
                        code = generate_unique_access_code()
                        EmployeeAccess.objects.create(
                            employee=employee,
                            role=role,
                            access_code=code,
                            status=EmployeeAccess.Status.NOT_ACTIVATED,
                            primary_code_issued_at=timezone.now(),
                        )
                    elif role:
                        EmployeeAccess.objects.create(
                            employee=employee,
                            role=role,
                            access_code='',
                            status=EmployeeAccess.Status.NOT_ACTIVATED,
                        )
                    work_assignment = form.save_work_assignment(
                        employee=employee,
                        assigned_by=access.employee,
                    )
            except ValidationError as error:
                form.add_error('assignment_equipment', error)
            else:
                assignment_label = (
                    f'{work_assignment.work_shift_label}; {work_assignment.equipment}'
                    if work_assignment else 'не задано'
                )
                if code:
                    log_admin_action(
                        access.employee,
                        'Создан сотрудник и выдан первичный пинкод',
                        employee,
                        new_value=(
                            f'Доступ: {role or "не требуется"}; '
                            f'назначение: {assignment_label}; пинкод: {code}'
                        ),
                    )
                    messages.success(
                        request,
                        f'Сотрудник создан. Первичный пинкод: {code}',
                        extra_tags='employee-card-silent',
                    )
                else:
                    log_admin_action(
                        access.employee,
                        'Создан сотрудник без пинкода',
                        employee,
                        new_value=f'Доступ: {role or "не требуется"}; назначение: {assignment_label}',
                    )
                    messages.success(request, 'Сотрудник создан.', extra_tags='employee-card-silent')
                return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
    else:
        form = AdminEmployeeForm(initial={
            'hired_at': timezone.localdate(),
            'status': Employee.Status.ACTIVE,
        })

    return render(
        request,
        'users/employee_card.html',
        {
            'access': access,
            'form': form,
            'title': 'Создать сотрудника',
            'page_mode': 'create',
            'employee_card_context': 'admin',
            'can_submit_employee_card': True,
        },
    )


def editing_own_protected_card(access, employee):
    """Защищённую карточку правит только её владелец — и только свою.

    Остальным путь закрыт на уровне модели, здесь мы лишь решаем, открывать ли
    дверь: администратор, вошедший под собой, редактирует сам себя.
    """
    if employee.is_protected and access.employee_id == employee.id:
        return allow_protected_card_write()
    return nullcontext()


def system_admin_employee_detail_view(request, employee_id):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')

    employee = get_object_or_404(Employee, id=employee_id)
    if request.method == 'POST':
        initial_status = employee.status
        old_photo_name = employee.photo.name if employee.photo else ''
        if request.POST.get('remove_photo') == '1':
            if old_photo_name:
                employee.photo.storage.delete(old_photo_name)
                employee.photo = ''
                with editing_own_protected_card(access, employee):
                    employee.save(update_fields=['photo', 'updated_at'])
                log_admin_action(access.employee, 'Удалено фото сотрудника', employee)
                messages.success(request, 'Фото сотрудника удалено.')
            return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
        form = AdminEmployeeEditForm(request.POST, request.FILES, instance=employee)
        if form.is_valid():
            try:
                with transaction.atomic(), editing_own_protected_card(access, employee):
                    locked_employee = Employee.objects.select_for_update().get(pk=employee.pk)
                    if locked_employee.status != initial_status:
                        raise ValidationError(
                            'Статус сотрудника уже изменился. Обновите страницу.',
                            code='stale_employee_status',
                        )
                    form.validate_protected_profile(locked_employee)
                    excluded_fields = set(form._meta.exclude or ())
                    excluded_fields.update(AdminEmployeeEditForm.PROTECTED_EXISTING_PROFILE_FIELDS)
                    form.instance = construct_instance(
                        form,
                        locked_employee,
                        form._meta.fields,
                        tuple(excluded_fields),
                    )
                    previous_specialization_id = locked_employee.base_specialization_id
                    saved_employee = form.save()
                    if (
                        previous_specialization_id != saved_employee.base_specialization_id
                        or production_access_is_out_of_sync(saved_employee)
                    ):
                        sync_employee_production_access(employee=saved_employee)
                    work_assignment = form.save_work_assignment(assigned_by=access.employee)
            except ValidationError as error:
                error_code = getattr(error, 'code', '')
                form.add_error(
                    None
                    if error_code in {'stale_employee_status', 'admin_watch_profile_forbidden', PROTECTED_WRITE_CODE}
                    else 'assignment_equipment',
                    error,
                )
            else:
                if request.FILES.get('photo') and old_photo_name and old_photo_name != saved_employee.photo.name:
                    saved_employee.photo.storage.delete(old_photo_name)
                assignment_label = (
                    f'{work_assignment.work_shift_label}; {work_assignment.equipment}'
                    if work_assignment else 'назначение снято'
                )
                log_admin_action(
                    access.employee,
                    'Изменена карточка сотрудника',
                    saved_employee,
                    new_value=f'Рабочее назначение: {assignment_label}',
                )
                messages.success(
                    request,
                    'Карточка сотрудника и рабочее назначение сохранены.',
                    extra_tags='employee-card-silent',
                )
                return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
    else:
        form = AdminEmployeeEditForm(instance=employee)

    employee_accesses = employee.accesses.select_related('role').order_by('role__name')
    current_role_access = (
        employee_accesses
        .filter(is_active=True)
        .exclude(status=EmployeeAccess.Status.DEACTIVATED)
        .order_by('status', 'role__name')
        .first()
        or employee_accesses.first()
    )
    role_form_initial = {'role': current_role_access.role_id} if current_role_access else None
    active_equipment_assignment = get_active_equipment_assignment(employee)
    effective_employee_specialization = effective_specialization(employee)
    work_assignment_role = active_equipment_assignment.role if active_equipment_assignment else None
    if not work_assignment_role and effective_employee_specialization:
        work_assignment_role = effective_employee_specialization.access_role
    if not work_assignment_role and current_role_access:
        work_assignment_role = current_role_access.role

    return render(
        request,
        'users/employee_card.html',
        {
            'access': access,
            'employee': employee,
            'form': form,
            'title': employee.full_name,
            'page_mode': 'detail',
            'employee_card_context': 'admin',
            'can_submit_employee_card': True,
            'role_form': AdminAccessRoleForm(initial=role_form_initial),
            'block_form': AdminAccessBlockForm(),
            'employee_accesses': employee_accesses,
            'current_role_access': current_role_access,
            'employee_presence': application_presence_by_employee_ids([employee.pk]).get(employee.pk),
            'active_equipment_assignment': active_equipment_assignment,
            'work_assignment_role': work_assignment_role,
            'work_assignment_supports_equipment': bool(
                work_assignment_role
                and work_assignment_role.code in WORK_ASSIGNMENT_ROLE_EQUIPMENT_TYPES
            ),
            'effective_specialization': effective_employee_specialization,
            'employee_start_url': request.build_absolute_uri(reverse('universal_start')),
            'temporary_work_transfers': (
                employee.temporary_work_transfers
                .select_related(
                    'source_specialization',
                    'target_specialization',
                    'watch_period',
                    'requested_by',
                    'reviewed_by',
                )
                .order_by('-requested_at')[:8]
            ),
            'can_restore_employee': (
                employee.status in ADMIN_RESTORABLE_EMPLOYEE_STATUSES
                or not employee.is_active
            ),
            'logs': AdminActionLog.objects.filter(
                Q(object_type='Employee', object_id=str(employee.id))
                | Q(object_id='', object_repr=str(employee))
            )[:10],
        },
    )


def system_admin_generate_access_view(request, employee_id):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')
    employee = get_object_or_404(Employee, id=employee_id)
    if request.method == 'POST':
        form = AdminAccessRoleForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                employee = Employee.objects.select_for_update().get(pk=employee.pk)
                if EmployeeShift.objects.filter(employee=employee, closed_at__isnull=True).exists():
                    messages.error(request, 'Сначала закройте текущую смену сотрудника, затем сбросьте PIN.')
                    return redirect_after_admin_action(
                        request,
                        'system_admin_employee_detail',
                        employee_id=employee.id,
                    )
                role = form.cleaned_data['role']
                if (
                    employee.personnel_position_id
                    and role.code in {'driver', 'excavator_operator'}
                    and not employee_has_effective_access_role(employee, role.code)
                ):
                    messages.error(
                        request,
                        'Сначала назначьте сотруднику подходящую производственную специализацию.',
                    )
                    return redirect_after_admin_action(
                        request,
                        'system_admin_employee_detail',
                        employee_id=employee.id,
                    )
                code = generate_unique_access_code()
                employee_access, _created = EmployeeAccess.objects.update_or_create(
                    employee=employee,
                    role=role,
                    defaults={
                        'access_code': code,
                        'status': EmployeeAccess.Status.NOT_ACTIVATED,
                        'is_active': True,
                        'primary_code_issued_at': timezone.now(),
                        'activated_at': None,
                        'deactivated_at': None,
                        'blocked_at': None,
                        'block_reason': '',
                    },
                )
                log_admin_action(access.employee, 'Выдан новый первичный пинкод', employee_access, new_value=code)
            messages.success(request, f'Новый первичный пинкод: {code}')
    return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)


@require_POST
def system_admin_change_access_role_view(request, access_id):
    admin_access = require_admin_access(request)
    if not admin_access:
        return redirect('role_home')

    form = AdminAccessRoleForm(request.POST)
    employee_access = get_object_or_404(
        EmployeeAccess.objects.select_related('employee', 'role'),
        id=access_id,
    )
    employee_id = employee_access.employee_id
    if not form.is_valid():
        messages.error(request, 'Выберите новую роль сотрудника.')
        return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee_id)

    new_role = form.cleaned_data['role']
    if employee_access.role_id == new_role.id:
        messages.info(request, 'У сотрудника уже назначена эта роль.')
        return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee_id)
    if employee_access.id == admin_access.id:
        messages.error(request, 'Нельзя изменить собственную роль администратора.')
        return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee_id)

    with transaction.atomic():
        locked_employee = Employee.objects.select_for_update().get(id=employee_id)
        employee_access = (
            EmployeeAccess.objects
            .select_for_update()
            .select_related('role')
            .get(id=access_id, employee_id=employee_id)
        )
        if EmployeeShift.objects.filter(employee_id=employee_id, closed_at__isnull=True).exists():
            messages.error(request, 'Сначала закройте текущую смену сотрудника, затем измените его роль.')
            return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee_id)
        if (
            locked_employee.personnel_position_id
            and (
                employee_access.role.code in {'driver', 'excavator_operator'}
                or new_role.code in {'driver', 'excavator_operator'}
            )
        ):
            expected_specialization = effective_specialization(locked_employee)
            expected_role_id = getattr(expected_specialization, 'access_role_id', None)
            if expected_role_id != new_role.id:
                messages.error(
                    request,
                    'Производственное приложение меняется через кадровую должность и специализацию, а не вручную.',
                )
                return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee_id)
        if (
            EmployeeAccess.objects
            .filter(employee_id=employee_id, role=new_role)
            .exclude(id=employee_access.id)
            .exists()
        ):
            messages.error(request, 'У сотрудника уже есть отдельный доступ с выбранной ролью.')
            return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee_id)

        old_role = employee_access.role
        cleared_assignments = clear_active_equipment_assignment(
            employee=locked_employee,
            assigned_by=admin_access.employee,
            role_code=old_role.code,
        )
        employee_access.role = new_role
        employee_access.save(update_fields=['role'])

    log_admin_action(
        admin_access.employee,
        'Изменена роль доступа сотрудника',
        employee_access,
        old_value=old_role.name,
        new_value=new_role.name,
        comment='PIN, пароль и статус доступа сохранены.',
    )
    assignment_note = ' Старое назначение на технику снято.' if cleared_assignments else ''
    messages.success(
        request,
        f'Роль изменена: {old_role.name} → {new_role.name}. PIN и пароль сохранены.{assignment_note}',
    )
    return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee_id)


@require_POST
def system_admin_cancel_temporary_work_transfer_view(request, transfer_id):
    admin_access = require_admin_access(request)
    if not admin_access:
        return redirect('role_home')

    transfer = get_object_or_404(
        TemporaryWorkTransfer.objects.select_related(
            'employee',
            'source_specialization',
            'target_specialization',
        ),
        id=transfer_id,
    )
    employee_id = transfer.employee_id
    try:
        with transaction.atomic():
            previous_specialization = transfer.target_specialization
            transfer, restored_access = cancel_temporary_work_transfer(
                transfer=transfer,
                cancelled_by=admin_access.employee,
                comment=request.POST.get('comment', ''),
            )
            AdminActionLog.objects.create(
                actor=admin_access.employee,
                action='Администратор: отменен временный производственный перевод',
                action_code='admin_temporary_transfer_cancelled',
                object_type='TemporaryWorkTransfer',
                object_id=str(transfer.id),
                object_repr=f'{transfer.employee.full_name} — {previous_specialization}',
                old_value=f'Специализация: {previous_specialization}; статус: Одобрен',
                new_value=(
                    f'Специализация: {transfer.source_specialization or "не выбрана"}; '
                    'статус: Отменен'
                ),
                comment=transfer.review_comment,
            )
            bump_operational_state(
                'Employee:admin_temporary_transfer_cancelled',
                event_type='personnel_changed',
                object_type='Employee',
                object_id=employee_id,
                payload={
                    'action': 'admin_temporary_transfer_cancelled',
                    'employee_ids': [employee_id],
                    'access_id': restored_access.id if restored_access else None,
                },
            )
    except ValidationError as error:
        messages.error(request, '; '.join(error.messages))
    else:
        messages.success(request, 'Временный перевод отменен. Сотрудник возвращен на базовую специализацию.')
    return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee_id)


def system_admin_access_action_view(request, access_id, action):
    admin_access = require_admin_access(request)
    if not admin_access:
        return redirect('role_home')
    employee_access = get_object_or_404(EmployeeAccess.objects.select_related('employee'), id=access_id)
    if request.method == 'POST':
        with transaction.atomic():
            employee = Employee.objects.select_for_update().get(pk=employee_access.employee_id)
            employee_access = (
                EmployeeAccess.objects.select_for_update()
                .select_related('role')
                .get(pk=employee_access.pk, employee=employee)
            )
            if employee_access.id == admin_access.id and action in {'block', 'deactivate'}:
                messages.error(request, 'Нельзя заблокировать или деактивировать собственный доступ администратора.')
                return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
            if action in {'block', 'deactivate'} and EmployeeShift.objects.filter(
                employee=employee,
                closed_at__isnull=True,
            ).exists():
                messages.error(request, 'Сначала закройте текущую смену сотрудника, затем измените его доступ.')
                return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
            if action == 'block':
                form = AdminAccessBlockForm(request.POST)
                if form.is_valid():
                    employee_access.status = EmployeeAccess.Status.BLOCKED
                    employee_access.is_active = False
                    employee_access.blocked_at = timezone.now()
                    employee_access.block_reason = form.cleaned_data['reason']
                    employee_access.save(update_fields=['status', 'is_active', 'blocked_at', 'block_reason'])
                    log_admin_action(admin_access.employee, 'Заблокирован доступ', employee_access, comment=employee_access.block_reason)
                    messages.success(request, 'Доступ заблокирован.')
            elif action == 'unblock':
                if employee.status in {
                    Employee.Status.ARCHIVED,
                    Employee.Status.DISMISSED,
                    Employee.Status.DELETED,
                }:
                    messages.error(
                        request,
                        'Сначала восстановите сотрудника отдельным действием, затем разблокируйте доступ.',
                    )
                    return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
                employee_access.status = EmployeeAccess.Status.ACTIVATED
                employee_access.is_active = True
                employee_access.blocked_at = None
                employee_access.block_reason = ''
                employee_access.deactivated_at = None
                employee_access.save(update_fields=['status', 'is_active', 'blocked_at', 'block_reason', 'deactivated_at'])
                if employee.status in {
                    Employee.Status.NOT_ACTIVATED,
                    Employee.Status.DEACTIVATED,
                }:
                    employee.status = Employee.Status.ACTIVE
                    employee.is_active = True
                    employee.save(update_fields=['status', 'is_active'])
                log_admin_action(admin_access.employee, 'Разблокирован доступ', employee_access)
                messages.success(request, 'Доступ разблокирован.')
            elif action == 'deactivate':
                employee_access.status = EmployeeAccess.Status.DEACTIVATED
                employee_access.is_active = False
                employee_access.deactivated_at = timezone.now()
                employee_access.save(update_fields=['status', 'is_active', 'deactivated_at'])
                clear_active_equipment_assignment(
                    employee=employee,
                    assigned_by=admin_access.employee,
                    role_code=employee_access.role.code,
                )
                log_admin_action(admin_access.employee, 'Доступ деактивирован', employee_access)
                messages.success(request, 'Доступ деактивирован.')
    return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee_access.employee.id)


def restore_employee_access(employee, requested_access_id=None):
    accesses = (
        EmployeeAccess.objects.select_for_update()
        .select_related('role')
        .filter(employee=employee)
    )
    employee_access = None
    if requested_access_id and str(requested_access_id).isdigit():
        employee_access = accesses.filter(id=int(requested_access_id)).first()
    if not employee_access:
        employee_access = (
            accesses.filter(status=EmployeeAccess.Status.DEACTIVATED)
            .order_by('-created_at', '-id')
            .first()
            or accesses.order_by('-is_active', '-created_at', '-id').first()
        )
    if not employee_access:
        return None, 'missing'

    if (
        employee_access.status == EmployeeAccess.Status.BLOCKED
        or employee_access.blocked_at
        or employee_access.block_reason
    ):
        if (
            employee_access.status != EmployeeAccess.Status.BLOCKED
            or employee_access.is_active
            or employee_access.deactivated_at
        ):
            employee_access.status = EmployeeAccess.Status.BLOCKED
            employee_access.is_active = False
            employee_access.deactivated_at = None
            employee_access.save(
                update_fields=['status', 'is_active', 'deactivated_at']
            )
        return employee_access, 'blocked'

    if employee_access.is_active and employee_access.status != EmployeeAccess.Status.DEACTIVATED:
        return employee_access, 'already_active'

    if employee_access.activated_at:
        employee_access.status = EmployeeAccess.Status.ACTIVATED
    elif employee_access.primary_code_issued_at:
        employee_access.status = EmployeeAccess.Status.NOT_ACTIVATED
    elif employee_access.access_code and employee_access.last_login_at:
        employee_access.status = EmployeeAccess.Status.ACTIVATED
    else:
        employee_access.status = EmployeeAccess.Status.NOT_ACTIVATED
    employee_access.is_active = True
    employee_access.deactivated_at = None
    employee_access.blocked_at = None
    employee_access.block_reason = ''
    employee_access.save(
        update_fields=[
            'status',
            'is_active',
            'deactivated_at',
            'blocked_at',
            'block_reason',
        ]
    )
    return employee_access, 'restored'


def system_admin_employee_status_action_view(request, employee_id, action):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')
    employee = get_object_or_404(Employee, id=employee_id)
    # Деактивация и удаление защищённой карточки запрещены моделью. Без этой
    # проверки администратор получил бы вместо объяснения страницу с ошибкой.
    if (
        request.method == 'POST'
        and employee.is_protected
        and action != 'restore'
        and access.employee_id != employee.id
    ):
        messages.error(
            request,
            'Карточка защищена: изменить или закрыть её может только её владелец.',
        )
        return redirect_after_admin_action(
            request, 'system_admin_employee_detail', employee_id=employee.id,
        )
    if request.method == 'POST':
        with transaction.atomic(), editing_own_protected_card(access, employee):
            employee = Employee.objects.select_for_update().get(pk=employee.pk)
            if action == 'restore':
                if (
                    employee.status not in ADMIN_RESTORABLE_EMPLOYEE_STATUSES
                    and employee.is_active
                ):
                    messages.info(request, 'Сотрудник уже находится в рабочем состоянии.')
                    return redirect_after_admin_action(
                        request,
                        'system_admin_employee_detail',
                        employee_id=employee.id,
                    )

                old_status = employee.get_status_display()
                employee.status = Employee.Status.ACTIVE
                employee.is_active = True
                employee.dismissed_at = None
                employee.save(
                    update_fields=['status', 'is_active', 'dismissed_at', 'updated_at']
                )
                employee_access, access_result = restore_employee_access(
                    employee,
                    request.POST.get('access_id'),
                )

                if access_result == 'restored':
                    if employee_access.status == EmployeeAccess.Status.ACTIVATED:
                        access_note = (
                            f' Доступ «{employee_access.role.name}» включен; '
                            'действующий PIN/пароль сохранен.'
                        )
                    elif employee_access.access_code:
                        access_note = (
                            f' Доступ «{employee_access.role.name}» возвращен в ожидание '
                            'первого входа; первичный PIN сохранен.'
                        )
                    else:
                        access_note = (
                            f' Доступ «{employee_access.role.name}» включен, но PIN еще '
                            'не выдан.'
                        )
                elif access_result == 'blocked':
                    access_note = (
                        f' Доступ «{employee_access.role.name}» остался заблокированным; '
                        'разблокируйте его отдельно.'
                    )
                elif access_result == 'already_active':
                    access_note = (
                        f' Доступ «{employee_access.role.name}» уже был активен; '
                        'PIN/пароль не изменялся.'
                    )
                else:
                    access_note = ' Доступ не найден; назначьте роль и выдайте PIN отдельно.'

                log_admin_action(
                    access.employee,
                    'Сотрудник восстановлен администратором',
                    employee,
                    old_value=old_status,
                    new_value=employee.get_status_display(),
                    comment=(
                        access_note.strip()
                        + ' Смена и техника автоматически не восстанавливались.'
                    ),
                )
                bump_operational_state(
                    'Employee:admin_restored',
                    event_type='personnel_changed',
                    object_type='Employee',
                    object_id=employee.id,
                    payload={
                        'action': 'admin_restored',
                        'employee_ids': [employee.id],
                        'status': employee.status,
                        'is_active': employee.is_active,
                        'access_id': employee_access.id if employee_access else None,
                        'access_result': access_result,
                    },
                )
                messages.success(
                    request,
                    'Сотрудник восстановлен.' + access_note
                    + ' Смена и техника не назначались автоматически.',
                )
                return redirect_after_admin_action(
                    request,
                    'system_admin_employee_detail',
                    employee_id=employee.id,
                )

            if employee.id == access.employee.id and action in {'deactivate', 'archive', 'delete'}:
                messages.error(request, 'Нельзя деактивировать, архивировать или удалить собственную учетную запись администратора.')
                return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
            if action in {'deactivate', 'archive', 'delete'} and EmployeeShift.objects.filter(
                employee=employee,
                closed_at__isnull=True,
            ).exists():
                messages.error(request, 'Сначала закройте текущую смену сотрудника, затем измените его статус.')
                return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
            if action == 'deactivate':
                employee.status = Employee.Status.DEACTIVATED
                employee.is_active = False
                employee.accesses.update(status=EmployeeAccess.Status.DEACTIVATED, is_active=False, deactivated_at=timezone.now())
                clear_active_equipment_assignment(employee=employee, assigned_by=access.employee)
                messages.success(request, 'Сотрудник деактивирован.')
                log_admin_action(access.employee, 'Сотрудник деактивирован', employee)
            elif action == 'archive':
                employee.status = Employee.Status.ARCHIVED
                employee.is_active = False
                employee.accesses.update(status=EmployeeAccess.Status.DEACTIVATED, is_active=False, deactivated_at=timezone.now())
                clear_active_equipment_assignment(employee=employee, assigned_by=access.employee)
                messages.success(request, 'Сотрудник отправлен в архив.')
                log_admin_action(access.employee, 'Сотрудник отправлен в архив', employee)
            elif action == 'delete':
                if employee.has_production_history():
                    AdminConflict.objects.create(
                        employee=employee,
                        role=employee.accesses.select_related('role').first().role if employee.accesses.exists() else None,
                        conflict_type='Попытка удаления сотрудника с историей',
                        process='Админка MVP',
                        description='Полное удаление заблокировано: у сотрудника есть смены, рейсы, простои, назначения, перевахта или другие учетные действия.',
                    )
                    messages.error(request, 'Удаление запрещено: у сотрудника есть учетная история. Используйте архив.')
                    log_admin_action(access.employee, 'Удаление сотрудника заблокировано', employee)
                    return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
                employee_name = employee.full_name
                log_admin_action(access.employee, 'Сотрудник полностью удален', employee, old_value=employee_name)
                employee.delete()
                messages.success(request, f'Сотрудник {employee_name} удален.')
                return redirect('system_admin_employees')
            else:
                return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)
            employee.save(update_fields=['status', 'is_active', 'updated_at'])
    return redirect_after_admin_action(request, 'system_admin_employee_detail', employee_id=employee.id)


def system_admin_employee_export_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = 'Сотрудники'
    sheet.append([
        'ФИО', 'Табельный номер', 'Телефон', 'Пол', 'Статус', 'Подразделение',
        'Дата приема', 'Дата увольнения', 'График работы', 'Бригада',
        'Утверждённый состав вахты', 'Место проживания',
    ])
    for employee in Employee.objects.select_related(
        'personnel_department',
        'work_schedule',
        'watch_composition',
    ).order_by('full_name'):
        sheet.append([
            employee.full_name,
            employee.personnel_number,
            employee.phone,
            employee.get_sex_display(),
            employee.get_status_display(),
            employee.department_label,
            excel_value(employee.hired_at),
            excel_value(employee.dismissed_at),
            employee.work_schedule_label,
            employee.get_brigade_number_display() if employee.brigade_number else '',
            str(employee.watch_composition or ''),
            employee.residence_text,
        ])
    return build_workbook_response(workbook, 'admin_employees.xlsx')


def system_admin_access_export_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = 'Доступы'
    sheet.append(['Сотрудник', 'Роль', 'Статус доступа', 'Дата выдачи', 'Дата активации', 'Последний вход'])
    for employee_access in EmployeeAccess.objects.select_related('employee', 'role').order_by('employee__full_name'):
        sheet.append([
            employee_access.employee.full_name,
            employee_access.role.name,
            employee_access.get_status_display(),
            excel_value(employee_access.primary_code_issued_at),
            excel_value(employee_access.activated_at),
            excel_value(employee_access.last_login_at),
        ])
    return build_workbook_response(workbook, 'admin_accesses.xlsx')


def system_admin_log_export_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = 'Журнал действий'
    sheet.append([
        'Дата', 'Кто', 'Действие', 'Код действия', 'Тип объекта', 'Объект',
        'Комментарий', 'Отменяет запись', 'Дата отмены', 'Кто отменил',
    ])
    logs = AdminActionLog.objects.select_related('actor', 'reversal_of').order_by('-created_at')
    reversals = {
        item.reversal_of_id: item
        for item in logs
        if item.reversal_of_id
    }
    for log in logs:
        reversal = reversals.get(log.id)
        sheet.append([
            excel_value(log.created_at),
            log.actor.full_name if log.actor else '',
            log.action,
            log.action_code,
            log.object_type,
            log.object_repr,
            log.comment,
            log.reversal_of_id or '',
            excel_value(reversal.created_at) if reversal else '',
            reversal.actor.full_name if reversal and reversal.actor else '',
        ])
    return build_workbook_response(workbook, 'admin_action_log.xlsx')


def system_admin_conflict_export_view(request):
    access = require_admin_access(request)
    if not access:
        return redirect('role_home')
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = 'Конфликты'
    sheet.append(['Дата', 'Сотрудник', 'Роль', 'Тип', 'Процесс', 'Статус', 'Описание'])
    for conflict in AdminConflict.objects.select_related('employee', 'role').order_by('-created_at'):
        sheet.append([
            excel_value(conflict.created_at),
            conflict.employee.full_name if conflict.employee else '',
            conflict.role.name if conflict.role else '',
            conflict.conflict_type,
            conflict.process,
            conflict.get_status_display(),
            conflict.description,
        ])
    return build_workbook_response(workbook, 'admin_conflicts.xlsx')


def driver_registration_view(request):
    access_id = request.session.get('employee_access_id')
    if not access_id:
        return redirect('login')
    access = EmployeeAccess.objects.select_related('employee', 'role').filter(id=access_id, is_active=True).first()
    if not access or access.role.code != 'driver':
        return redirect('role_home')

    registration = getattr(access.employee, 'driver_registration', None)
    if registration:
        return redirect('role_home')

    if request.method == 'POST':
        form = DriverPrimaryRegistrationForm(request.POST, employee=access.employee)
        if form.is_valid():
            DriverPrimaryRegistration.objects.create(employee=access.employee, **form.cleaned_data)
            messages.success(request, 'Первичная регистрация сохранена.')
            return redirect('role_home')
    else:
        form = DriverPrimaryRegistrationForm(employee=access.employee)

    return render(request, 'users/driver_registration.html', {'form': form, 'access': access})


def driver_format_duration_label(seconds):
    seconds = max(0, int(seconds or 0))
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    return f'{hours:02d}:{minutes:02d}:{seconds % 60:02d}'


def driver_report_duration_label(seconds, *, total=False):
    rounded_minutes = max(0, int((max(0, int(seconds or 0)) + 30) // 60))
    hours, minutes = divmod(rounded_minutes, 60)
    if total and hours:
        return f'{hours}:{minutes:02d} мин.'
    if hours and minutes:
        return f'{hours} ч. {minutes} мин.'
    if hours:
        hour_word = 'час' if hours % 10 == 1 and hours % 100 != 11 else ('часа' if hours % 10 in {2, 3, 4} and hours % 100 not in {12, 13, 14} else 'часов')
        return f'{hours} {hour_word}.'
    return f'{rounded_minutes} мин.'


def driver_shift_downtime_seconds_by_reason(equipment, shift, *, until=None):
    if not equipment or not shift or not shift.opened_at:
        return {}
    calculation_end = until or timezone.now()
    source_period_end = shift.closed_at or calculation_end
    events = DowntimeEvent.objects.filter(
        equipment=equipment,
        started_at__gte=shift.opened_at,
        started_at__lt=source_period_end,
    )
    totals = {}
    for event in events.only('reason_id', 'started_at', 'ended_at'):
        if not event.reason_id:
            continue
        event_end = min(event.ended_at or calculation_end, calculation_end)
        totals.setdefault(event.reason_id, 0)
        totals[event.reason_id] += max(0, int((event_end - event.started_at).total_seconds()))
    return totals


def driver_shift_downtime_seconds(equipment, shift, *, until=None):
    return sum(
        driver_shift_downtime_seconds_by_reason(equipment, shift, until=until).values()
    )


def driver_downtime_totals_payload(equipment, shift, *, calculated_at=None):
    calculated_at = calculated_at or timezone.now()
    reason_totals = driver_shift_downtime_seconds_by_reason(
        equipment,
        shift,
        until=calculated_at,
    )
    shift_total_seconds = sum(reason_totals.values())
    return {
        'calculated_at': calculated_at.isoformat(),
        'shift_total_seconds': shift_total_seconds,
        'shift_total_label': driver_format_duration_label(shift_total_seconds),
        'reason_totals': reason_totals,
    }


def driver_downtime_reason_status_key(reason):
    if reason:
        return reason.effective_color_group
    return 'yellow'


def driver_downtime_event_payload(event, *, action='', closed=False, shift=None):
    now = timezone.now()
    started_at = event.started_at or now
    ended_at = event.ended_at
    elapsed_until = ended_at or now
    elapsed_seconds = max(0, int((elapsed_until - started_at).total_seconds()))
    reason = event.reason if event.reason_id else None
    workflow = driver_downtime_flow(reason)
    payload = {
        'ok': True,
        'action': action,
        'active': not bool(ended_at),
        'closed': bool(closed),
        'event_id': event.id,
        'reason_id': event.reason_id,
        'reason': str(reason) if reason else '',
        'reason_label': reason.button_label if reason else '',
        'workflow': workflow,
        'requires_loaded_trip': workflow == DRIVER_DOWNTIME_FLOW_WAITING_UNLOAD,
        'requires_empty_truck': driver_downtime_requires_empty_truck(reason),
        'started_at': started_at.isoformat(),
        'ended_at': ended_at.isoformat() if ended_at else '',
        'elapsed_seconds': elapsed_seconds,
        'elapsed_label': driver_format_duration_label(elapsed_seconds),
        'status_key': driver_downtime_reason_status_key(reason),
    }
    payload.update(driver_downtime_totals_payload(event.equipment, shift))
    return payload


def driver_json_payload(request):
    if 'application/json' not in (request.headers.get('Content-Type') or ''):
        return request.POST
    try:
        return json.loads(request.body.decode('utf-8') or '{}')
    except (TypeError, ValueError, UnicodeDecodeError):
        return {}


def driver_wants_json(request):
    return (
        request.headers.get('X-Requested-With') == 'XMLHttpRequest'
        or 'application/json' in (request.headers.get('Accept') or '')
    )


def driver_employee_short_name(employee):
    parts = [part for part in (getattr(employee, 'full_name', '') or '').split() if part]
    if not parts:
        return 'Водитель'
    if len(parts) == 1:
        return parts[0]
    initials = ''.join(f'{part[0]}.' for part in parts[1:3] if part)
    return f'{parts[0]} {initials}'.strip()


def driver_equipment_number(equipment):
    return str(getattr(equipment, 'garage_number', '') or equipment or '').strip()


def driver_excavator_short_label(equipment):
    number = driver_equipment_number(equipment)
    if not number:
        return '—'
    upper_number = number.upper()
    if upper_number.startswith(('ЭКС', 'ЭКГ', 'EX')):
        return number
    return f'ЭКС-{number}'


def driver_complex_label_for_excavator(equipment):
    number = driver_equipment_number(equipment)
    if not number:
        return 'К-—'
    upper_number = number.upper()
    if upper_number.startswith('К-'):
        return number
    return f'К-{number}'


def driver_prefixed_context_value(prefix, value):
    value = str(value or '').strip()
    if not value:
        return f'{prefix} —'
    if value.lower().startswith(prefix.lower()):
        return value
    return f'{prefix} {value}'


def driver_free_bucket_payload(*, current_truck, current_assignment, version, open_shift=None):
    """Build the real, cacheable driver-side free-bucket directory and state."""
    from trips.models import FreeBucketAcceptance

    generated_at = timezone.now().isoformat()
    primary_excavator_id = current_assignment.excavator_id if current_assignment else None
    placements = list(
        ExcavatorPlacement.objects
        .filter(
            zone=ExcavatorPlacement.Zone.ACTIVE,
            excavator__is_active=True,
            excavator__equipment_type__name='Экскаватор',
        )
        .select_related(
            'excavator',
            'excavator__equipment_type',
            'work_rock_type',
            'work_dump_point',
        )
        .prefetch_related('dump_point_settings__dump_point')
        .order_by('excavator__garage_number', 'excavator_id')
    )
    excavators = []
    catalog_missing_fields = set()
    for placement in placements:
        dump_points = [
            {
                'id': setting.dump_point_id,
                'name': str(setting.dump_point),
                'transport_distance_km': (
                    str(setting.transport_distance_km)
                    if setting.transport_distance_km is not None else ''
                ),
            }
            for setting in placement.dump_point_settings.all()
            if setting.dump_point.is_active
        ]
        if (
            not dump_points
            and placement.work_dump_point_id
            and placement.work_dump_point.is_active
        ):
            dump_points.append({
                'id': placement.work_dump_point_id,
                'name': str(placement.work_dump_point),
                'transport_distance_km': (
                    str(placement.transport_distance_km)
                    if placement.transport_distance_km is not None else ''
                ),
            })
        missing_fields = []
        if not placement.loading_horizon:
            missing_fields.append('loading_horizon')
        if not placement.loading_block:
            missing_fields.append('loading_block')
        if not placement.work_rock_type_id or not placement.work_rock_type.is_active:
            missing_fields.append('rock_type')
        if not dump_points:
            missing_fields.append('dump_points')
        catalog_missing_fields.update(missing_fields)
        excavators.append({
            'id': placement.excavator_id,
            'label': driver_excavator_short_label(placement.excavator),
            'complex_label': driver_complex_label_for_excavator(placement.excavator),
            'is_primary': placement.excavator_id == primary_excavator_id,
            'available': not missing_fields,
            'loading_horizon': str(placement.loading_horizon or ''),
            'loading_block': str(placement.loading_block or ''),
            'rock_type_id': (
                placement.work_rock_type_id
                if placement.work_rock_type and placement.work_rock_type.is_active
                else None
            ),
            'rock_type': (
                str(placement.work_rock_type)
                if placement.work_rock_type and placement.work_rock_type.is_active
                else ''
            ),
            'dump_point_id': dump_points[0]['id'] if dump_points else None,
            'dump_point': dump_points[0]['name'] if dump_points else '',
            'dump_points': dump_points,
            'transport_distance_km': (
                str(placement.transport_distance_km)
                if placement.transport_distance_km is not None else ''
            ),
            'placement_updated_at': (
                placement.work_context_updated_at.isoformat()
                if placement.work_context_updated_at else ''
            ),
            'missing_fields': missing_fields,
        })

    active_acceptance = None
    if current_truck and open_shift:
        # Право на свободный ковш живёт внутри смены, в которой его запросили:
        # при закрытии смены незакрытые заявки гасит
        # cancel_free_bucket_acceptances_for_shift(). Без привязки к смене здесь
        # заявка из прошлой (или просто другой) смены протекала на экран новой
        # и подменяла собой настоящее назначение — водитель видел старый
        # экскаватор, не мог ни выбрать другой, ни отменить этот.
        # Тот же общий признак «право активно», что у пульта и экскаваторщика
        # (жива смена, не старше срока с момента включения), плюс погруженный
        # рейс этой смены — его экран показывает до закрытия карточки.
        from trips.free_bucket import active_free_bucket_acceptance_filter
        active_acceptance = (
            FreeBucketAcceptance.objects
            .filter(
                Q(status='used') | active_free_bucket_acceptance_filter(),
                truck=current_truck,
                requesting_shift=open_shift,
            )
            .select_related('excavator', 'excavator__equipment_type')
            .order_by('-occurred_at', '-id')
            .first()
        )
    active_item = next(
        (item for item in excavators if active_acceptance and item['id'] == active_acceptance.excavator_id),
        None,
    )
    if active_acceptance:
        immutable_snapshot = dict(getattr(active_acceptance, 'work_context_snapshot', {}) or {})
        immutable_display = immutable_snapshot.get('display')
        if isinstance(immutable_display, dict):
            immutable_snapshot = immutable_display
        immutable_dump_points = list(immutable_snapshot.get('dump_points') or [])
        immutable_primary_dump_point = (
            immutable_dump_points[0]
            if immutable_dump_points and isinstance(immutable_dump_points[0], dict)
            else {}
        )
        immutable_missing_fields = []
        if not immutable_snapshot.get('loading_horizon'):
            immutable_missing_fields.append('loading_horizon')
        if not immutable_snapshot.get('loading_block'):
            immutable_missing_fields.append('loading_block')
        if not (
            immutable_snapshot.get('rock_type_name')
            or immutable_snapshot.get('rock_type')
        ):
            immutable_missing_fields.append('rock_type')
        if not immutable_dump_points:
            immutable_missing_fields.append('dump_points')
        immutable_missing_fields = list(
            immutable_snapshot.get('missing_fields')
            or immutable_missing_fields
        )
        active_item = {
            'id': active_acceptance.excavator_id,
            'label': str(immutable_snapshot.get('excavator_label') or driver_excavator_short_label(active_acceptance.excavator)),
            'complex_label': str(immutable_snapshot.get('complex_label') or driver_complex_label_for_excavator(active_acceptance.excavator)),
            'is_primary': bool(immutable_snapshot.get('is_primary')),
            'available': not immutable_missing_fields,
            'loading_horizon': str(immutable_snapshot.get('loading_horizon') or ''),
            'loading_block': str(immutable_snapshot.get('loading_block') or ''),
            'rock_type_id': immutable_snapshot.get('rock_type_id'),
            'rock_type': str(
                immutable_snapshot.get('rock_type_name')
                or immutable_snapshot.get('rock_type')
                or ''
            ),
            'dump_point_id': (
                immutable_snapshot.get('dump_point_id')
                or immutable_primary_dump_point.get('id')
            ),
            'dump_point': str(
                immutable_snapshot.get('dump_point')
                or immutable_primary_dump_point.get('name')
                or ''
            ),
            'dump_points': immutable_dump_points,
            'transport_distance_km': str(
                immutable_snapshot.get('transport_distance_km')
                or immutable_primary_dump_point.get('transport_distance_km')
                or ''
            ),
            'placement_updated_at': str(immutable_snapshot.get('placement_updated_at') or ''),
            'missing_fields': immutable_missing_fields,
        }

    catalog = {
        'schema': 'driver-free-bucket-catalog-v1',
        'generated_at': generated_at,
        'version': int(version or 0),
        'complete': True,
        'stale': False,
        'missing_fields': sorted(catalog_missing_fields),
        'primary_assignment_label': driver_excavator_short_label(
            current_assignment.excavator if current_assignment else None
        ),
        'excavators': excavators,
    }
    state = {
        'schema': 'driver-free-bucket-state-v1',
        'generated_at': generated_at,
        'version': int(version or 0),
        'active': bool(active_acceptance),
        'acceptance_id': active_acceptance.id if active_acceptance else None,
        'acceptance_local_id': active_acceptance.client_acceptance_id if active_acceptance else '',
        'status': active_acceptance.status if active_acceptance else '',
        'can_cancel': bool(active_acceptance and active_acceptance.status in {'requested', 'accepted'}),
        'selection': active_item,
    }
    return catalog, state, active_acceptance


def driver_assignment_countdown_label(assignment):
    if not assignment:
        return '05:00'
    if assignment.effective_at:
        remaining_seconds = max(0, int((assignment.effective_at - timezone.now()).total_seconds()))
    elif assignment.assigned_at:
        elapsed_seconds = max(0, int((timezone.now() - assignment.assigned_at).total_seconds()))
        remaining_seconds = max(0, (5 * 60) - elapsed_seconds)
    else:
        remaining_seconds = 5 * 60
    minutes, seconds = divmod(remaining_seconds, 60)
    return f'{minutes:02d}:{seconds:02d}'


def shift_plan_display_context(progress):
    status = progress.get('plan_status') if progress else ''
    percent_value = progress.get('progress_percent') if progress else None
    has_plan = percent_value is not None
    visual = progress_cycle_visual_context(percent_value if has_plan else 0)
    plan_value = progress.get('plan_value') if progress else None
    calculation_mode = progress.get('calculation_mode') if progress else ''
    return {
        'percent': visual['percent'] if has_plan else 0,
        'status': status or PlanAssignmentStatus.NO_PLAN_GROUP,
        'status_label': plan_status_label(status),
        'short_label': 'Нет группы' if status == PlanAssignmentStatus.NO_PLAN_GROUP else 'Нет плана' if status == PlanAssignmentStatus.NO_ACTIVE_PLAN else plan_status_label(status),
        'has_plan': has_plan,
        'value': plan_value,
        'unit': plan_unit_label(calculation_mode),
        'group_name': progress.get('plan_group_name') if progress else '',
        'visual': visual,
    }


def driver_shift_view(request):
    requested_fragment = request.GET.get('_operational_fragment', '').strip()
    access_id = request.session.get('employee_access_id')
    if not access_id:
        if requested_fragment == 'driver':
            return JsonResponse({'authenticated': False}, status=401)
        return redirect('login')
    access = EmployeeAccess.objects.select_related('employee', 'role').filter(id=access_id, is_active=True).first()
    if not access or access.role.code != 'driver':
        return redirect('role_home')
    registration = getattr(access.employee, 'driver_registration', None)

    posted_client_action_id = request.POST.get('client_action_id', '').strip() if request.method == 'POST' else ''
    if posted_client_action_id and ShiftClientAction.objects.filter(
        action_type='driver_shift_opened',
        client_action_id=posted_client_action_id,
        employee=access.employee,
    ).exists():
        messages.success(request, 'Смена открыта.')
        return redirect('driver_work')

    open_shift = driver_open_shift_queryset(access.employee).order_by('-opened_at').first()
    last_closed_shift = (
        EmployeeShift.objects
        .select_related('equipment', 'equipment__equipment_type')
        .filter(employee=access.employee, closed_at__isnull=False)
        .filter(
            Q(workplace_code='driver')
            | Q(workplace_code='', equipment__equipment_type__name='Самосвал')
        )
        .order_by('-closed_at')
        .first()
    )
    report_shift = open_shift or last_closed_shift
    report_truck = report_shift.equipment if report_shift else None
    work_assignment = get_active_equipment_assignment(access.employee, 'driver')
    assignment_state = work_assignment_state(access.employee, work_assignment)
    shift_start_conflict_message = ''
    if work_assignment and assignment_state == 'assignment_conflict':
        busy_shift = (
            EmployeeShift.objects
            .select_related('employee', 'equipment', 'equipment__equipment_type')
            .filter(
                equipment=work_assignment.equipment,
                closed_at__isnull=True,
            )
            .exclude(employee=access.employee)
            .order_by('id')
            .first()
        )
        shift_start_conflict_message = open_shift_conflict_message(
            busy_shift,
            equipment=work_assignment.equipment,
        )
    current_truck = open_shift.equipment if open_shift else None
    assignment_truck = (
        work_assignment.equipment
        if work_assignment and assignment_state in {'assigned', 'assignment_conflict'}
        else None
    )
    header_truck = current_truck or assignment_truck
    if current_truck:
        reconcile_due_haul_assignments(truck_id=current_truck.id)
    current_assignment = None
    pending_assignment_action = None
    active_trip = None
    driver_active_trip_origin = ''
    driver_manual_trip_event = None
    active_downtime = None
    shift_trips = []
    if current_truck:
        open_assignments = list(
            HaulAssignment.objects
            .filter(
                truck=current_truck,
                ended_at__isnull=True,
            )
            .exclude(status=AssignmentStatus.CANCELLED)
            .select_related('truck', 'excavator')
            .order_by('-assigned_at')
        )
        accepted_assignment = next(
            (assignment for assignment in open_assignments if assignment.status == AssignmentStatus.ACCEPTED),
            None,
        )
        pending_assignment = next(
            (assignment for assignment in open_assignments if assignment.status == AssignmentStatus.PENDING),
            None,
        )
        current_assignment = accepted_assignment
        pending_assignment_action = pending_assignment
        active_trip = Trip.objects.filter(trip_driver_control_filter(open_shift)).filter(
            truck=current_truck,
            status__in=OPEN_TRIP_STATUSES,
        ).select_related(
            'truck',
            'excavator',
            'rock_type',
            'dump_point',
            'assigned_dump_point',
            'actual_dump_point',
            'free_bucket_acceptance',
        ).order_by('-created_at').first()
        if active_trip:
            active_trip_action_types = set(
                TripClientAction.objects.filter(trip=active_trip).values_list('action_type', flat=True)
            )
            if active_trip_action_types & {'truck_loaded', 'free_bucket_loaded'}:
                driver_active_trip_origin = 'excavator'
            elif 'driver_manual_loaded' in active_trip_action_types:
                driver_active_trip_origin = 'driver_manual'
                driver_manual_trip_event = (
                    OfflineFieldEvent.objects
                    .filter(
                        trip=active_trip,
                        event_type='driver.trip.loaded',
                        status='accepted',
                    )
                    .order_by('sequence', 'id')
                    .first()
                )
            else:
                driver_active_trip_origin = 'excavator'
        active_downtime = (
            DowntimeEvent.objects
            .select_related('reason', 'reason__equipment_state')
            .filter(equipment=current_truck, ended_at__isnull=True)
            .order_by('-started_at')
            .first()
        )

    if report_shift and report_truck:
        legacy_driver_trip_filter = Q(
            driver=access.employee,
            completed_at__gte=report_shift.opened_at,
        )
        if report_shift.closed_at:
            legacy_driver_trip_filter &= Q(completed_at__lte=report_shift.closed_at)
        shift_trips = list(
            Trip.objects
            .select_related('excavator', 'rock_type', 'dump_point', 'assigned_dump_point', 'actual_dump_point')
            .filter(
                Q(unloading_shift=report_shift)
                | Q(loading_shift=report_shift)
                | Q(driver_control_shift=report_shift)
                | legacy_driver_trip_filter
            )
            .distinct()
            .order_by('created_at')[:30]
        )

    for trip in shift_trips:
        started_at = timezone.localtime(trip.created_at) if trip.created_at else None
        completed_at = timezone.localtime(trip.completed_at) if trip.completed_at else None
        duration_end = report_shift.closed_at if report_shift and report_shift.closed_at else timezone.now()
        finish_for_duration = completed_at or timezone.localtime(duration_end)
        duration_seconds = 0
        if started_at:
            duration_seconds = max(0, int((finish_for_duration - started_at).total_seconds()))
        duration_minutes = max(1, round(duration_seconds / 60)) if duration_seconds else 0
        trip.driver_excavator_label = trip.excavator.garage_number if trip.excavator_id else '—'
        driver_dump_point = trip.actual_dump_point or trip.dump_point or trip.assigned_dump_point
        trip.driver_dump_point_label = str(driver_dump_point) if driver_dump_point else '—'
        started_label = started_at.strftime('%H:%M') if started_at else '—'
        completed_label = completed_at.strftime('%H:%M') if completed_at else '...'
        trip.driver_time_range_label = f'{started_label}–{completed_label}'
        trip.driver_duration_label = f'{duration_minutes}м' if completed_at else 'в рейсе'

    completed_shift_trips = [trip for trip in shift_trips if trip.status == TripStatus.COMPLETED]
    shift_trip_count = len(completed_shift_trips)
    report_trip_map = {}
    for trip in completed_shift_trips:
        report_key = (trip.driver_excavator_label, trip.driver_dump_point_label)
        report_trip_map.setdefault(report_key, 0)
        report_trip_map[report_key] += 1
    driver_shift_report_trip_rows = [
        {'excavator': key[0], 'dump_point': key[1], 'count': count}
        for key, count in report_trip_map.items()
    ]

    driver_shift_downtime_events = []
    driver_shift_downtime_rows = []
    driver_shift_timeline = []
    if report_truck and report_shift:
        shift_period_end = report_shift.closed_at or timezone.now()
        driver_shift_downtime_events = list(
            DowntimeEvent.objects
            .select_related('reason')
            .filter(
                equipment=report_truck,
                employee=access.employee,
                started_at__lt=shift_period_end,
            )
            .filter(Q(ended_at__isnull=True) | Q(ended_at__gt=report_shift.opened_at))
            .order_by('started_at')
        )
        downtime_totals = {}
        for event in driver_shift_downtime_events:
            overlap_start = max(event.started_at, report_shift.opened_at)
            overlap_end = min(event.ended_at or shift_period_end, shift_period_end)
            duration_seconds = max(0, int((overlap_end - overlap_start).total_seconds()))
            reason_label = event.reason.button_label
            downtime_totals.setdefault(reason_label, 0)
            downtime_totals[reason_label] += duration_seconds
            driver_shift_timeline.append({
                'at': overlap_start,
                'time': timezone.localtime(overlap_start).strftime('%H:%M'),
                'kind': 'downtime-start',
                'title': f'Начат простой: {reason_label}',
                'meta': '',
            })
            if event.ended_at:
                driver_shift_timeline.append({
                    'at': overlap_end,
                    'time': timezone.localtime(overlap_end).strftime('%H:%M'),
                    'kind': 'downtime-end',
                    'title': f'Завершён простой: {reason_label}',
                    'meta': driver_format_duration_label(duration_seconds),
                })
        driver_shift_downtime_rows = [
            {
                'reason': reason,
                'seconds': seconds,
                'duration': driver_report_duration_label(seconds),
            }
            for reason, seconds in downtime_totals.items()
        ]

    for index, trip in enumerate(shift_trips, start=1):
        driver_shift_timeline.append({
            'at': trip.created_at,
            'time': timezone.localtime(trip.created_at).strftime('%H:%M'),
            'kind': 'trip',
            'title': f'Рейс {index:02d} · {trip.driver_excavator_label} → {trip.driver_dump_point_label}',
            'meta': trip.driver_time_range_label,
        })
    driver_shift_timeline.sort(key=lambda item: item['at'])
    shift_progress = calculate_truck_shift_progress(current_truck, reference_shift=open_shift)
    shift_plan = shift_plan_display_context(shift_progress)
    shift_plan_percent = shift_plan['percent']
    active_tab = request.GET.get('tab', 'work' if open_shift else 'shift')
    if active_tab not in {'work', 'shift', 'downtimes', 'manifest'}:
        active_tab = 'work'
    operational_state_version = (
        OperationalStateVersion.objects
        .filter(key='production')
        .values_list('version', flat=True)
        .first()
        or 0
    )
    # Ручная «точковка» ведёт собственный цикл погрузка→погрузка. Она не должна
    # превращать обычный круг Водителя в кнопку разгрузки: круг принадлежит
    # только фактической погрузке, пришедшей от Машиниста экскаватора.
    driver_standard_active_trip = (
        active_trip if driver_active_trip_origin != 'driver_manual' else None
    )
    driver_status = 'ПУСТОЙ'
    driver_status_class = 'is-empty'
    driver_target_label = '—'
    driver_trip_context_source = driver_standard_active_trip
    if driver_standard_active_trip:
        driver_status = 'ЗАГРУЖЕН'
        driver_status_class = 'is-loaded'
        driver_target_label = (
            driver_standard_active_trip.actual_dump_point
            or driver_standard_active_trip.dump_point
        )
    elif active_downtime:
        driver_status = active_downtime.reason.button_label
        driver_status_class = 'is-downtime'

    driver_has_open_trip = bool(active_trip)
    driver_has_loaded_trip = bool(
        driver_standard_active_trip
        and driver_standard_active_trip.status == TripStatus.LOADED_WAITING_UNLOAD
    )
    active_downtime_flow = driver_downtime_flow(
        active_downtime.reason if active_downtime else None
    )
    driver_waiting_operation_active = driver_downtime_opens_work(
        active_downtime.reason if active_downtime else None
    )
    driver_loading_wait_active = bool(
        not driver_has_open_trip
        and active_downtime_flow == DRIVER_DOWNTIME_FLOW_WAITING_LOADING
    )
    # Ожидание разгрузки идёт и у ручного рейса: круг водителя (driver-point-drum-v1.js)
    # тогда тоже завершает рейс одним касанием.
    driver_unloading_wait_active = bool(
        (
            driver_has_loaded_trip
            or (active_trip and active_trip.status == TripStatus.LOADED_WAITING_UNLOAD)
        )
        and active_downtime_flow == DRIVER_DOWNTIME_FLOW_WAITING_UNLOAD
    )

    (
        driver_free_bucket_catalog,
        driver_free_bucket_state,
        driver_free_bucket_acceptance,
    ) = driver_free_bucket_payload(
        current_truck=current_truck,
        current_assignment=current_assignment,
        version=operational_state_version,
        open_shift=open_shift,
    )
    driver_free_bucket_can_open = bool(open_shift and current_truck and not active_trip)
    driver_free_bucket_primary_label = driver_excavator_short_label(
        current_assignment.excavator if current_assignment else None
    )
    driver_work_excavator = (
        driver_standard_active_trip.excavator
        if driver_standard_active_trip
        else driver_free_bucket_acceptance.excavator
        if driver_free_bucket_acceptance
        else current_assignment.excavator
        if current_assignment
        else None
    )
    driver_work_context_placement = None
    if driver_work_excavator and not driver_free_bucket_acceptance:
        driver_work_context_placement = (
            ExcavatorPlacement.objects
            .select_related('work_rock_type', 'work_dump_point')
            .filter(excavator=driver_work_excavator)
            .first()
        )
    if not driver_trip_context_source and driver_work_context_placement:
        has_work_context = any([
            driver_work_context_placement.loading_horizon,
            driver_work_context_placement.loading_block,
            driver_work_context_placement.work_rock_type_id,
        ])
        if has_work_context:
            driver_trip_context_source = driver_work_context_placement
    if not driver_trip_context_source and current_assignment:
        driver_trip_context_source = (
            Trip.objects
            .filter(excavator=current_assignment.excavator)
            .select_related('rock_type', 'dump_point', 'actual_dump_point', 'assigned_dump_point')
            .order_by('-created_at')
            .first()
        )
    driver_header_truck_label = (
        f'Самосвал {driver_equipment_number(header_truck)}'
        if header_truck
        else 'Самосвал'
    )
    driver_header_person_label = driver_employee_short_name(access.employee)
    driver_header_label = (
        f'{driver_header_truck_label} · {driver_header_person_label}'
    )
    driver_context_rock = (
        getattr(driver_trip_context_source, 'rock_type', None)
        or getattr(driver_trip_context_source, 'work_rock_type', None)
    )
    driver_excavator_label = driver_excavator_short_label(driver_work_excavator)
    driver_complex_label = driver_complex_label_for_excavator(driver_work_excavator)
    driver_geology_parts = [
        driver_prefixed_context_value('Горизонт', getattr(driver_trip_context_source, 'loading_horizon', '')),
        driver_prefixed_context_value('Блок', getattr(driver_trip_context_source, 'loading_block', '')),
        str(driver_context_rock or '—'),
    ]

    # Ручной экран водителя использует тот же рабочий компонент, что и экран
    # машиниста экскаватора. Основное назначение не меняется: если водитель
    # выбрал свободный ковш, рабочая карточка и точки берутся из неизменяемого
    # снимка этого временного выбора только на одну будущую погрузку.
    driver_manual_event_context = (
        dict(driver_manual_trip_event.context_snapshot or {})
        if driver_manual_trip_event else {}
    )
    driver_manual_selection = (
        driver_free_bucket_state['selection']
        if driver_free_bucket_state['active'] and driver_free_bucket_state['selection']
        else None
    )
    # The temporary free-bucket context must never replace the primary assignment
    # snapshot.  The browser needs both contexts at the same time so a durable
    # local cancellation can return the manual workspace immediately, without
    # waiting for the next realtime fragment.
    driver_manual_primary_placement = None
    driver_manual_primary_dump_points = []
    if current_assignment:
        driver_manual_primary_placement = (
            ExcavatorPlacement.objects
            .select_related('work_rock_type', 'work_dump_point')
            .filter(excavator=current_assignment.excavator)
            .first()
        )
        if driver_manual_primary_placement:
            driver_manual_primary_dump_points = list(
                ExcavatorDumpPointSetting.objects
                .filter(
                    placement=driver_manual_primary_placement,
                    dump_point__is_active=True,
                )
                .select_related('dump_point')
                .order_by('position', 'id')
            )
            if (
                not driver_manual_primary_dump_points
                and driver_manual_primary_placement.work_dump_point_id
                and driver_manual_primary_placement.work_dump_point.is_active
            ):
                driver_manual_primary_dump_points = [
                    SimpleNamespace(
                        dump_point=driver_manual_primary_placement.work_dump_point,
                        transport_distance_km=driver_manual_primary_placement.transport_distance_km,
                    )
                ]
    driver_manual_excavator = (
        active_trip.excavator
        if driver_active_trip_origin == 'driver_manual' and active_trip else
        driver_free_bucket_acceptance.excavator
        if driver_manual_selection and driver_free_bucket_acceptance
        else current_assignment.excavator
        if current_assignment else None
    )
    driver_manual_card_assignment = current_assignment
    if driver_manual_trip_event:
        manual_assignment_id = (driver_manual_trip_event.payload or {}).get('assignment_id')
        driver_manual_card_assignment = (
            HaulAssignment.objects.filter(pk=manual_assignment_id).first()
            if manual_assignment_id else None
        ) or SimpleNamespace(id='', truck=current_truck)
    driver_manual_placement = None
    driver_manual_dump_points = []
    if driver_manual_trip_event and isinstance(driver_manual_event_context.get('dump_points'), list):
        driver_manual_dump_points = [
            {
                'point': SimpleNamespace(id=point.get('id')),
                'name': str(point.get('name') or ''),
                'transport_distance_km': str(point.get('transport_distance_km') or ''),
            }
            for point in driver_manual_event_context['dump_points']
            if isinstance(point, dict) and point.get('id') and point.get('name')
        ]
    elif driver_manual_selection:
        driver_manual_dump_points = [
            {
                'point': SimpleNamespace(id=point.get('id')),
                'name': str(point.get('name') or ''),
                'transport_distance_km': str(point.get('transport_distance_km') or ''),
            }
            for point in driver_manual_selection.get('dump_points', [])
            if point.get('id') and point.get('name')
        ]
    elif current_assignment:
        driver_manual_placement = driver_manual_primary_placement
        driver_manual_dump_points = list(driver_manual_primary_dump_points)

    driver_manual_plan_visual = {
        'loop_progress': 0,
        'completed_loops': 0,
        'phase': 'empty',
        'has_completed_loops': False,
        'is_overrun': False,
    }
    driver_manual_excavator_label = (
        str(driver_manual_event_context.get('excavator_label') or '')
        or (driver_manual_selection['label'] if driver_manual_selection else '')
        or driver_excavator_short_label(driver_manual_excavator)
    )
    driver_manual_complex_label = (
        str(driver_manual_event_context.get('complex_label') or '')
        or (driver_manual_selection['complex_label'] if driver_manual_selection else '')
        or driver_complex_label_for_excavator(driver_manual_excavator)
    )
    driver_manual_rock_label = (
        str(driver_manual_event_context.get('rock_type_name') or '')
        or (driver_manual_selection['rock_type'] if driver_manual_selection else '')
        or (
            str(driver_manual_placement.work_rock_type)
            if driver_manual_placement and driver_manual_placement.work_rock_type_id else ''
        )
        or (str(active_trip.rock_type) if driver_active_trip_origin == 'driver_manual' and active_trip else '')
    )
    driver_manual_cards = []
    if driver_manual_card_assignment and driver_manual_excavator:
        driver_manual_cards.append({
            'assignment': driver_manual_card_assignment,
            'equipment_id': driver_manual_excavator.id,
            'manual_available': False,
            'driver_presence_code': 'online',
            'driver_presence_label': 'Назначен водителю',
            'open_trip_id': '',
            'number': driver_manual_excavator_label,
            'equipment_state_code': '',
            'status_key': 'yellow',
            'status_label': driver_manual_complex_label,
            'target_label': driver_manual_rock_label,
            'is_selected': True,
            'is_locked': False,
            'is_inactive': False,
            'is_load_blocked': False,
            'can_drag': True,
            'can_load': True,
            'is_handoff_completion': False,
            'transfer': None,
            'foreign_free_bucket': None,
            'load_block_reason_code': '',
            'load_block_reason_label': '',
            'icon': 'img/equipment/excavator-yellow.png',
            'plan_has_plan': False,
            'plan_percent': 0,
            'plan_visual': driver_manual_plan_visual,
            'plan_status': 'no_plan_group',
            'plan_status_key': 'empty',
            'plan_short_label': (
                'Свободный ковш'
                if driver_manual_selection or driver_manual_event_context.get('authority_type') == 'free_bucket'
                else 'Ручной режим'
            ),
        })
    driver_manual_trip_counts = {}
    driver_manual_last_dump_point_id = None
    if driver_manual_excavator:
        for trip in shift_trips:
            if trip.status == TripStatus.CANCELLED or trip.excavator_id != driver_manual_excavator.id:
                continue
            point_id = trip.assigned_dump_point_id or trip.dump_point_id
            if not point_id:
                continue
            driver_manual_trip_counts[point_id] = driver_manual_trip_counts.get(point_id, 0) + 1
            driver_manual_last_dump_point_id = point_id

    driver_manual_dump_cards = [
        {
            'point': setting['point'] if isinstance(setting, dict) else setting.dump_point,
            'name': setting['name'] if isinstance(setting, dict) else str(setting.dump_point),
            'name_size_class': (
                'is-name-long'
                if len(setting['name'] if isinstance(setting, dict) else str(setting.dump_point)) > 18 else
                'is-name-medium'
                if len(setting['name'] if isinstance(setting, dict) else str(setting.dump_point)) > 10 else
                'is-name-short'
            ),
            'status_key': 'green',
            'transport_distance_km': (
                setting['transport_distance_km']
                if isinstance(setting, dict) else setting.transport_distance_km or ''
            ),
            'completed_count': driver_manual_trip_counts.get(
                (setting['point'] if isinstance(setting, dict) else setting.dump_point).id,
                0,
            ),
            'pending_trucks': [],
            'is_last_sent': (
                (setting['point'] if isinstance(setting, dict) else setting.dump_point).id
                == driver_manual_last_dump_point_id
            ),
        }
        for setting in driver_manual_dump_points
    ]
    if not driver_manual_event_context:
        driver_manual_event_context = {
            'source': 'driver_manual',
            'authority_type': 'free_bucket' if driver_manual_selection else 'assignment',
            'truck_id': current_truck.id if current_truck else None,
            'excavator_id': driver_manual_excavator.id if driver_manual_excavator else None,
            'excavator_label': driver_manual_excavator_label,
            'complex_label': driver_manual_complex_label,
            'assignment_id': current_assignment.id if current_assignment and not driver_manual_selection else None,
            'free_bucket_acceptance_id': (
                driver_free_bucket_acceptance.id if driver_manual_selection and driver_free_bucket_acceptance else None
            ),
            'free_bucket_acceptance_local_id': (
                driver_free_bucket_state.get('acceptance_local_id') if driver_manual_selection else ''
            ),
            'placement_id': driver_manual_placement.id if driver_manual_placement else None,
            'placement_updated_at': (
                driver_manual_selection.get('placement_updated_at')
                if driver_manual_selection else
                driver_manual_placement.work_context_updated_at.isoformat()
                if driver_manual_placement and driver_manual_placement.work_context_updated_at else None
            ),
            'rock_type_id': (
                driver_manual_selection.get('rock_type_id')
                if driver_manual_selection else
                driver_manual_placement.work_rock_type_id if driver_manual_placement else None
            ),
            'rock_type_name': driver_manual_rock_label,
            'loading_horizon': (
                driver_manual_selection.get('loading_horizon')
                if driver_manual_selection else
                driver_manual_placement.loading_horizon if driver_manual_placement else ''
            ),
            'loading_block': (
                driver_manual_selection.get('loading_block')
                if driver_manual_selection else
                driver_manual_placement.loading_block if driver_manual_placement else ''
            ),
            'dump_points': [
                {
                    'id': card['point'].id,
                    'name': card['name'],
                    'transport_distance_km': card['transport_distance_km'] or None,
                }
                for card in driver_manual_dump_cards
            ],
        }
    if active_trip and driver_active_trip_origin == 'driver_manual':
        driver_manual_event_context.update({
            'event_id': driver_manual_trip_event.event_id if driver_manual_trip_event else '',
            'local_trip_id': driver_manual_trip_event.local_trip_id if driver_manual_trip_event else '',
            'active_trip_id': active_trip.id,
            'active_trip_loaded_at': (
                active_trip.loaded_at.isoformat() if active_trip.loaded_at else active_trip.created_at.isoformat()
            ),
            'selected_dump_point_id': active_trip.dump_point_id,
            'selected_dump_point_name': str(active_trip.dump_point),
        })
    driver_manual_primary_trip_counts = {}
    driver_manual_primary_last_dump_point_id = None
    if current_assignment:
        for trip in shift_trips:
            if trip.status == TripStatus.CANCELLED or trip.excavator_id != current_assignment.excavator_id:
                continue
            point_id = trip.assigned_dump_point_id or trip.dump_point_id
            if not point_id:
                continue
            driver_manual_primary_trip_counts[point_id] = (
                driver_manual_primary_trip_counts.get(point_id, 0) + 1
            )
            driver_manual_primary_last_dump_point_id = point_id
    driver_manual_primary_context = {
        'source': 'driver_manual',
        'authority_type': 'assignment',
        'truck_id': current_truck.id if current_truck else None,
        'excavator_id': current_assignment.excavator_id if current_assignment else None,
        'excavator_label': driver_excavator_short_label(
            current_assignment.excavator if current_assignment else None
        ),
        'complex_label': driver_complex_label_for_excavator(
            current_assignment.excavator if current_assignment else None
        ),
        'assignment_id': current_assignment.id if current_assignment else None,
        'free_bucket_acceptance_id': None,
        'free_bucket_acceptance_local_id': '',
        'placement_id': (
            driver_manual_primary_placement.id
            if driver_manual_primary_placement else None
        ),
        'placement_updated_at': (
            driver_manual_primary_placement.work_context_updated_at.isoformat()
            if driver_manual_primary_placement
            and driver_manual_primary_placement.work_context_updated_at else None
        ),
        'rock_type_id': (
            driver_manual_primary_placement.work_rock_type_id
            if driver_manual_primary_placement else None
        ),
        'rock_type_name': (
            str(driver_manual_primary_placement.work_rock_type)
            if driver_manual_primary_placement
            and driver_manual_primary_placement.work_rock_type_id else ''
        ),
        'loading_horizon': (
            driver_manual_primary_placement.loading_horizon
            if driver_manual_primary_placement else ''
        ),
        'loading_block': (
            driver_manual_primary_placement.loading_block
            if driver_manual_primary_placement else ''
        ),
        'dump_points': [
            {
                'id': setting.dump_point.id,
                'name': str(setting.dump_point),
                'transport_distance_km': (
                    str(setting.transport_distance_km)
                    if setting.transport_distance_km is not None else ''
                ),
                'completed_count': driver_manual_primary_trip_counts.get(
                    setting.dump_point.id,
                    0,
                ),
                'is_last_sent': (
                    setting.dump_point.id == driver_manual_primary_last_dump_point_id
                ),
                'one_off': False,
            }
            for setting in driver_manual_primary_dump_points
        ],
    }
    driver_manual_can_open = bool(
        open_shift
        and current_truck
        and (not active_trip or driver_active_trip_origin == 'driver_manual')
    )
    driver_manual_blocked_reason = (
        'Ручной режим недоступен во время активного рейса'
        if active_trip and driver_active_trip_origin != 'driver_manual' else
        'Откройте смену, чтобы использовать ручной режим'
        if not open_shift else
        'Сначала выберите самосвал для текущей смены'
        if not current_truck else
        ''
    )
    driver_manual_workspace = {
        'can_open': driver_manual_can_open,
        'blocked_reason': driver_manual_blocked_reason,
        'excavator_label': driver_manual_excavator_label or 'Ручной режим',
        'horizon': (
            driver_manual_event_context.get('loading_horizon')
            if driver_manual_event_context else
            driver_manual_selection['loading_horizon']
            if driver_manual_selection else
            driver_manual_placement.loading_horizon if driver_manual_placement else ''
        ),
        'block': (
            driver_manual_event_context.get('loading_block')
            if driver_manual_event_context else
            driver_manual_selection['loading_block']
            if driver_manual_selection else
            driver_manual_placement.loading_block if driver_manual_placement else ''
        ),
        'rock_label': driver_manual_rock_label,
        'cards': driver_manual_cards,
        'dump_cards': driver_manual_dump_cards,
        'event_context': driver_manual_event_context,
        'base_event_context': driver_manual_primary_context,
        'active_trip_origin': driver_active_trip_origin,
        'active_trip_id': active_trip.id if active_trip else None,
        'active_trip_loaded_at': (
            active_trip.loaded_at.isoformat() if active_trip and active_trip.loaded_at else ''
        ),
    }
    if driver_free_bucket_acceptance and driver_free_bucket_state['selection']:
        free_bucket_selection = driver_free_bucket_state['selection']
        driver_excavator_label = free_bucket_selection['label']
        driver_complex_label = free_bucket_selection['complex_label']
        driver_geology_parts = [
            driver_prefixed_context_value(
                'Горизонт', free_bucket_selection['loading_horizon'],
            ),
            driver_prefixed_context_value(
                'Блок', free_bucket_selection['loading_block'],
            ),
            free_bucket_selection['rock_type'] or '—',
        ]
    driver_context_parts = [driver_complex_label, *driver_geology_parts]
    driver_context_label = ' · '.join(driver_context_parts)
    if active_trip:
        driver_dial_label = str(driver_target_label)
        driver_dial_note = (
            active_downtime.reason.button_label.upper()
            if driver_unloading_wait_active
            else 'ТОЧКА РАЗГРУЗКИ'
        )
    elif driver_free_bucket_acceptance:
        # The mode is shown by the compact context chip. Keeping only the
        # excavator here prevents long labels from overflowing the main dial.
        driver_dial_label = driver_excavator_label
        driver_dial_note = (
            'ПОГРУЖЕН'
            if driver_free_bucket_acceptance.status == 'used'
            else 'ПРИНЯТ МАШИНИСТОМ'
            if driver_free_bucket_acceptance.status == 'accepted'
            else 'ОЖИДАНИЕ ПРИЁМА'
        )
    elif driver_loading_wait_active:
        # Во время ожидания сохраняем полезный ориентир погрузки в крупной
        # строке, а само состояние показываем в подписи. Так server render и
        # мгновенное AJAX-состояние выглядят одинаково.
        driver_dial_label = driver_excavator_short_label(driver_work_excavator)
        driver_dial_note = active_downtime.reason.button_label.upper()
    elif active_downtime:
        driver_dial_label = active_downtime.reason.button_label
        driver_dial_note = 'ПРИЧИНА ПРОСТОЯ'
    else:
        driver_dial_label = driver_excavator_short_label(driver_work_excavator)
        driver_dial_note = 'НА ЗАГРУЗКУ'
    driver_new_assignment_label = ''
    driver_assignment_action_label = ''
    driver_assignment_effective_at = ''
    driver_assignment_countdown = '05:00'
    if pending_assignment_action:
        if pending_assignment_action.action == HaulAssignmentAction.RELEASE:
            action_label = 'НАЗНАЧЕНИЕ СНЯТО'
        else:
            action_label = f'ВЫ НАЗНАЧЕНЫ НА {driver_excavator_short_label(pending_assignment_action.excavator)}'
        driver_assignment_action_label = action_label
        driver_assignment_countdown = driver_assignment_countdown_label(pending_assignment_action)
        driver_new_assignment_label = (
            f'{action_label} · ПРИНЯТЬ · {driver_assignment_countdown}'
        )
        if pending_assignment_action.effective_at:
            driver_assignment_effective_at = pending_assignment_action.effective_at.isoformat()

    downtime_equipment_type = current_truck.equipment_type if current_truck else None
    downtime_reasons = list(
        DowntimeReason.for_workplace('truck_driver', downtime_equipment_type)
    )
    driver_quick_reason_ids = driver_quick_reason_ids_for(access, downtime_reasons)
    downtime_calculated_at = timezone.now()
    downtime_reason_totals = driver_shift_downtime_seconds_by_reason(
        open_shift.equipment if open_shift else current_truck,
        open_shift,
        until=downtime_calculated_at,
    )
    driver_downtime_truck_loaded = bool(
        active_trip and active_trip.status == TripStatus.LOADED_WAITING_UNLOAD
    )
    driver_downtime_dump_point = (
        (active_trip.actual_dump_point or active_trip.dump_point) if active_trip else None
    )
    for reason in downtime_reasons:
        reason.driver_in_drum = (not driver_quick_reason_ids) or reason.id in driver_quick_reason_ids
        reason.driver_workflow = driver_downtime_flow(reason)
        reason.driver_requires_loaded_trip = driver_downtime_requires_loaded_trip(reason)
        reason.driver_requires_empty_truck = driver_downtime_requires_empty_truck(reason)
        reason.driver_total_seconds = downtime_reason_totals.get(reason.id, 0)
        reason.driver_total_label = driver_format_duration_label(reason.driver_total_seconds)
        reason.driver_is_used = bool(
            reason.driver_total_seconds
            or (active_downtime and active_downtime.reason_id == reason.id)
        )
        # Доступность по правилам driver_workflow. Гружёный — по любому открытому
        # рейсу, включая ручной (у него active_trip есть, а обычного круга нет).
        reason.driver_unavailable_message = driver_downtime_unavailable_message(
            reason,
            truck_loaded=driver_downtime_truck_loaded,
            dump_point=driver_downtime_dump_point,
        )
        if reason.driver_requires_empty_truck and driver_has_open_trip:
            reason.driver_unavailable_message = 'Самосвал уже загружен'
        reason.driver_dump_point_key = driver_downtime_required_dump_point_key(reason)
    # Полный серверный справочник активных точек должен остаться доступен и
    # после offline-перезапуска; срез первых десяти скрывал допустимые точки.
    unload_points = [
        {'id': point.id, 'name': str(point)}
        for point in DumpPoint.objects.filter(is_active=True).order_by('name')
    ]
    # Ручная смена точки относится только к уже созданному ручному рейсу.
    # Полный активный справочник сохраняем отдельно: обычное окно текущего
    # рейса может быть ограничено неизменяемым снимком свободного ковша.
    driver_manual_primary_context['reroute_points'] = list(unload_points)
    active_trip_assigned_dump_point = None
    active_trip_current_dump_point = None
    active_trip_actual_dump_point_id = None
    if active_trip:
        from trips.free_bucket import free_bucket_snapshot_dump_points_for_trip

        free_bucket_unload_points = free_bucket_snapshot_dump_points_for_trip(active_trip)
        if free_bucket_unload_points is not None:
            unload_points = free_bucket_unload_points
        active_trip_assigned_dump_point = active_trip.assigned_dump_point or active_trip.dump_point
        active_trip_current_dump_point = active_trip.actual_dump_point or active_trip.dump_point
        active_trip_actual_dump_point_id = active_trip_current_dump_point.id
    active_downtime_elapsed_seconds = 0
    active_downtime_elapsed_label = '00:00:00'
    shift_downtime_total_seconds = sum(downtime_reason_totals.values())
    shift_downtime_total_label = driver_format_duration_label(shift_downtime_total_seconds)
    shift_downtime_report_total_seconds = sum(
        row['seconds'] for row in driver_shift_downtime_rows
    )
    shift_downtime_report_total_label = driver_report_duration_label(
        shift_downtime_report_total_seconds,
        total=True,
    )
    active_downtime_started_at = ''
    active_downtime_status_key = 'yellow'
    if active_downtime and active_downtime.started_at:
        active_downtime_elapsed_seconds = max(0, int((timezone.now() - active_downtime.started_at).total_seconds()))
        active_downtime_elapsed_label = driver_format_duration_label(active_downtime_elapsed_seconds)
        active_downtime_started_at = active_downtime.started_at.isoformat()
        active_downtime_status_key = driver_downtime_reason_status_key(active_downtime.reason)

    if request.method == 'POST' and not open_shift:
        form = DriverOpenShiftForm(request.POST, employee=access.employee, work_assignment=work_assignment) if assignment_state == 'assigned' else None
        if form and form.is_valid():
            current_work_assignment = get_active_equipment_assignment(access.employee, 'driver')
            if work_assignment_state(access.employee, current_work_assignment) != 'assigned':
                form.add_error(None, 'Назначение изменилось. Обновите экран перед началом смены.')
            else:
                try:
                    with transaction.atomic():
                        Employee.objects.select_for_update().get(pk=access.employee_id)
                        if not role_session_state(request, access)['is_active']:
                            raise ValidationError('Роль неактивна — доступен только просмотр.')
                        open_driver_shift(
                            employee=access.employee,
                            work_assignment=current_work_assignment,
                            readings={
                                'start_fuel': form.cleaned_data['start_fuel'],
                                'start_mileage': form.cleaned_data['start_mileage'],
                                'start_engine_hours': form.cleaned_data['start_engine_hours'],
                            },
                            client_action_id=form.cleaned_data.get('client_action_id') or secrets.token_urlsafe(24),
                            close_other_role_shift=other_role_shift_flag(request.POST),
                        )
                except ValidationError as error:
                    form.add_error(None, error)
                else:
                    messages.success(request, 'Смена открыта.')
                    return redirect('driver_work')
    else:
        form_initial = {}
        if last_closed_shift:
            form_initial = {
                'start_fuel': last_closed_shift.end_fuel,
                'start_mileage': last_closed_shift.end_mileage,
                'start_engine_hours': last_closed_shift.end_engine_hours,
            }
        form_initial['client_action_id'] = secrets.token_urlsafe(24)
        form = (
            DriverOpenShiftForm(initial=form_initial, employee=access.employee, work_assignment=work_assignment)
            if not open_shift and assignment_state == 'assigned'
            else None
        )

    other_role_shift_prompt_context = None
    if form is not None and not open_shift:
        other_role_shift = find_other_role_open_shift(access.employee, workplace_code='driver', for_update=False)
        if other_role_shift:
            other_role_shift_prompt_context = other_role_shift_prompt(
                other_role_shift,
                target_workplace_code='driver',
            )

    close_form = getattr(request, '_driver_close_form', None)
    if close_form is None and open_shift:
        close_form = DriverCloseShiftForm(
            instance=open_shift,
            initial={'client_action_id': secrets.token_urlsafe(24)},
        )

    response = render(
        request,
        'users/driver_shift.html',
        {
            'access': access,
            'registration': registration,
            'current_truck': current_truck,
            'header_truck': header_truck,
            'open_shift': open_shift,
            'work_assignment': work_assignment,
            'work_assignment_state': assignment_state,
            'shift_start_conflict_message': shift_start_conflict_message,
            'other_role_shift_prompt': other_role_shift_prompt_context,
            'work_assignment_shift_label': work_assignment.work_shift_label if work_assignment else '',
            'work_assignment_equipment': assignment_truck,
            'current_assignment': current_assignment,
            'active_trip': driver_standard_active_trip,
            'form': form,
            'close_form': close_form,
            'close_review': getattr(request, '_driver_close_confirmation', None),
            'last_closed_shift': last_closed_shift,
            'active_tab': active_tab,
            'active_downtime': active_downtime,
            'active_downtime_started_at': active_downtime_started_at,
            'active_downtime_elapsed_seconds': active_downtime_elapsed_seconds,
            'active_downtime_elapsed_label': active_downtime_elapsed_label,
            'shift_downtime_total_seconds': shift_downtime_total_seconds,
            'shift_downtime_total_label': shift_downtime_total_label,
            'downtime_calculated_at': downtime_calculated_at.isoformat(),
            'shift_downtime_report_total_label': shift_downtime_report_total_label,
            'active_downtime_status_key': active_downtime_status_key,
            'downtime_reasons': downtime_reasons,
            'driver_quick_reason_ids': driver_quick_reason_ids,
            'driver_quick_reasons_min': DRIVER_QUICK_REASONS_MIN,
            'driver_quick_reasons_updated_at': (
                access.driver_quick_reasons_updated_at.isoformat()
                if access.driver_quick_reasons_updated_at else ''
            ),
            'shift_trips': shift_trips,
            'shift_trip_count': shift_trip_count,
            'driver_shift_report_trip_rows': driver_shift_report_trip_rows,
            'driver_shift_downtime_rows': driver_shift_downtime_rows,
            'driver_shift_timeline': driver_shift_timeline,
            'driver_shift_report_date': timezone.localtime(report_shift.opened_at).strftime('%d.%m.%Y') if report_shift else '—',
            'driver_shift_report_shift': report_shift.get_shift_type_display() if report_shift else 'Смена не открыта',
            'driver_shift_report_driver': driver_employee_short_name(access.employee),
            'driver_shift_report_truck': driver_equipment_number(report_truck) if report_truck else '—',
            'driver_shift_report_end_fuel': report_shift.end_fuel if report_shift and report_shift.closed_at else None,
            'driver_shift_report_end_mileage': report_shift.end_mileage if report_shift and report_shift.closed_at else None,
            'driver_shift_report_end_engine_hours': report_shift.end_engine_hours if report_shift and report_shift.closed_at else None,
            'shift_plan_percent': shift_plan_percent,
            'shift_plan_status': shift_plan['status'],
            'shift_plan_status_label': shift_plan['status_label'],
            'shift_plan_short_label': shift_plan['short_label'],
            'shift_plan_has_plan': shift_plan['has_plan'],
            'shift_plan_value': shift_plan['value'],
            'shift_plan_unit': shift_plan['unit'],
            'shift_plan_group_name': shift_plan['group_name'],
            'shift_plan_visual': shift_plan['visual'],
            'driver_status': driver_status,
            'driver_status_class': driver_status_class,
            'driver_has_open_trip': driver_has_open_trip,
            'driver_has_loaded_trip': driver_has_loaded_trip,
            'driver_free_bucket_can_open': driver_free_bucket_can_open,
            'driver_free_bucket_catalog': driver_free_bucket_catalog,
            'driver_free_bucket_state': driver_free_bucket_state,
            'driver_free_bucket_primary_label': driver_free_bucket_primary_label,
            'driver_waiting_operation_active': driver_waiting_operation_active,
            'driver_loading_wait_active': driver_loading_wait_active,
            'driver_unloading_wait_active': driver_unloading_wait_active,
            'active_downtime_flow': active_downtime_flow,
            'driver_target_label': driver_target_label,
            'driver_header_label': driver_header_label,
            'driver_header_truck_label': driver_header_truck_label,
            'driver_header_person_label': driver_header_person_label,
            'driver_excavator_label': driver_excavator_label,
            'driver_complex_label': driver_complex_label,
            'driver_geology_parts': driver_geology_parts,
            'driver_manual_workspace': driver_manual_workspace,
            'driver_context_parts': driver_context_parts,
            'driver_context_label': driver_context_label,
            'driver_dial_label': driver_dial_label,
            'driver_dial_note': driver_dial_note,
            'driver_new_assignment_label': driver_new_assignment_label,
            'driver_assignment_action_label': driver_assignment_action_label,
            'driver_assignment_effective_at': driver_assignment_effective_at,
            'driver_assignment_countdown': driver_assignment_countdown,
            'pending_assignment_action': pending_assignment_action,
            'unload_points': unload_points,
            'active_trip_assigned_dump_point': active_trip_assigned_dump_point,
            'active_trip_current_dump_point': active_trip_current_dump_point,
            'active_trip_actual_dump_point_id': active_trip_actual_dump_point_id,
            'trip_status_loaded': TripStatus.LOADED_WAITING_UNLOAD,
            'driver_shell_version': DRIVER_SHELL_VERSION,
            'driver_operational_fragment': requested_fragment == 'driver',
            'driver_auth_generation': request.session.get(ACTIVE_ROLE_GENERATION_SESSION_KEY, ''),
            'operational_state_version': operational_state_version,
        },
    )
    if requested_fragment == 'driver':
        return operational_fragment_response(
            response,
            screen='driver',
            selector='[data-driver-shell]',
            version=operational_state_version,
            extra={
                'driver_free_bucket_catalog': driver_free_bucket_catalog,
                'driver_free_bucket_state': driver_free_bucket_state,
            },
        )
    response['Cache-Control'] = 'no-cache'
    return response


@require_POST
@transaction.atomic
def driver_accept_assignment_view(request, assignment_id):
    access_id = request.session.get('employee_access_id')
    access = (
        EmployeeAccess.objects.select_related('employee', 'role')
        .filter(id=access_id, is_active=True, role__code='driver')
        .first()
    )
    if not access:
        return JsonResponse({'ok': False, 'error': 'Нет доступа к приложению водителя.'}, status=403)
    Employee.objects.select_for_update().get(pk=access.employee_id)
    if not role_session_state(request, access)['is_active']:
        return JsonResponse(
            {
                'ok': False,
                'error': 'Роль неактивна — доступен только просмотр',
                'code': 'inactive_role',
            },
            status=409,
        )
    open_shift = (
        driver_open_shift_queryset(access.employee)
        .select_for_update(of=('self',))
        .select_related('equipment')
        .order_by('-opened_at')
        .first()
    )
    if not open_shift or not open_shift.equipment_id:
        return JsonResponse({'ok': False, 'error': 'Открытая смена водителя не найдена.'}, status=409)
    # Тот же порядок блокировок, что у диспетчера, таймера и
    # экскаваторщика: production -> truck -> haul assignments. Раньше здесь
    # сначала блокировалось назначение, из-за чего параллельное принятие и DnD
    # могли упереться друг в друга.
    lock_production_state()
    Equipment.objects.select_for_update().get(pk=open_shift.equipment_id)
    assignment = get_object_or_404(
        HaulAssignment.objects.select_for_update(),
        id=assignment_id,
        truck_id=open_shift.equipment_id,
        status=AssignmentStatus.PENDING,
        ended_at__isnull=True,
    )
    kept_pending = bool(
        assignment.effective_at
        and assignment.effective_at > timezone.now()
    )
    if kept_pending:
        # Подтверждение водителя не является подтверждением физического прибытия
        # и не сокращает единый серверный срок перевода.
        if assignment.accepted_at is None:
            assignment.accepted_at = timezone.now()
            assignment.save(update_fields=['accepted_at'])
        applied = assignment
    else:
        applied = apply_pending_haul_assignment(assignment.id)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'ok': bool(applied),
            'action': assignment.action,
            'transfer_pending': kept_pending,
            'transition_pending': kept_pending,
        })
    return redirect('driver_work')


def driver_close_shift_view(request):
    wants_json = driver_wants_json(request)
    access_id = request.session.get('employee_access_id')
    if not access_id:
        if wants_json:
            return JsonResponse({
                'ok': False,
                'error': 'Требуется повторный вход.',
                'has_active_shift': False,
            }, status=401)
        return redirect('login')
    access = EmployeeAccess.objects.select_related('employee', 'role').filter(id=access_id, is_active=True).first()
    if not access or access.role.code != 'driver':
        if wants_json:
            return JsonResponse({
                'ok': False,
                'error': 'Нет доступа к приложению водителя.',
                'has_active_shift': False,
            }, status=403)
        return redirect('role_home')

    client_action_id = request.POST.get('client_action_id', '').strip()
    existing_action = ShiftClientAction.objects.select_related('shift').filter(
        action_type='driver_shift_closed',
        client_action_id=client_action_id,
        employee=access.employee,
    ).first() if client_action_id else None
    posted_shift_id = (request.POST.get('shift_id') or '').strip()
    raw_occurred_at = (request.POST.get('occurred_at') or '').strip()
    occurred_at = parse_datetime(raw_occurred_at) if raw_occurred_at else None
    occurred_at_is_valid = not raw_occurred_at or (
        occurred_at is not None and not timezone.is_naive(occurred_at)
    )

    def posted_request_signature(shift_id):
        return driver_close_request_signature(
            shift_id=shift_id,
            employee_id=access.employee_id,
            actor_access_id=access.pk,
            readings={
                'end_fuel': request.POST.get('end_fuel', ''),
                'end_mileage': request.POST.get('end_mileage', ''),
                'end_engine_hours': request.POST.get('end_engine_hours', ''),
            },
            occurred_at=occurred_at if occurred_at_is_valid else raw_occurred_at,
        )

    def idempotency_conflict_response(error):
        error_messages = getattr(error, 'messages', None) or [str(error)]
        if wants_json:
            return JsonResponse({
                'ok': False,
                'code': 'client_action_conflict',
                'error': str(error_messages[0]),
                'has_active_shift': False,
            }, status=409)
        messages.error(request, 'Повтор действия содержит другие данные. Обновите экран.')
        return redirect(f"{reverse('driver_work')}?tab=manifest")

    if existing_action:
        try:
            ensure_driver_close_action_matches(
                existing_action,
                posted_request_signature(posted_shift_id or existing_action.shift_id),
                access.employee_id,
            )
        except DriverShiftCloseIdempotencyConflict as error:
            return idempotency_conflict_response(error)
        if wants_json:
            return JsonResponse({
                'ok': True,
                'status': 'already_applied',
                'client_action_id': client_action_id,
                'redirect_url': f"{reverse('driver_work')}?tab=manifest",
            })
        messages.success(request, 'Смена закрыта.')
        return redirect(f"{reverse('driver_work')}?tab=manifest")

    open_shift = driver_open_shift_queryset(access.employee).order_by('-opened_at').first()
    if not open_shift:
        if wants_json:
            return JsonResponse({
                'ok': False,
                'error': 'Открытая смена не найдена.',
                'has_active_shift': False,
            }, status=409)
        messages.error(request, 'Открытая смена не найдена.')
        return redirect('driver_work')

    if posted_shift_id and posted_shift_id != str(open_shift.pk):
        if wants_json:
            return JsonResponse({
                'ok': False,
                'error': 'Смена на сервере уже изменилась. Откройте приложение и проверьте её состояние.',
                'has_active_shift': True,
            }, status=409)
        messages.error(request, 'Смена на сервере уже изменилась. Обновите экран.')
        return redirect(f"{reverse('driver_work')}?tab=shift")

    form_data = request.POST.copy()
    if not form_data.get('client_action_id'):
        form_data['client_action_id'] = secrets.token_urlsafe(24)
    form = DriverCloseShiftForm(form_data, instance=open_shift)
    request._driver_close_form = form
    form_is_valid = form.is_valid()
    if form_is_valid and not occurred_at_is_valid:
        form.add_error(None, 'Время действия должно содержать часовой пояс.')
        form_is_valid = False
    if form_is_valid:
        readings = {
            'end_fuel': form.cleaned_data['end_fuel'],
            'end_mileage': form.cleaned_data['end_mileage'],
            'end_engine_hours': form.cleaned_data['end_engine_hours'],
        }
        resolved_client_action_id = form.cleaned_data['client_action_id']
        request_signature = driver_close_request_signature(
            shift_id=open_shift.pk,
            employee_id=access.employee_id,
            actor_access_id=access.pk,
            readings=readings,
            occurred_at=occurred_at,
        )
        try:
            with transaction.atomic():
                Employee.objects.select_for_update().get(pk=access.employee_id)
                if not role_session_state(request, access)['is_active']:
                    raise ValidationError('Роль неактивна — доступен только просмотр.')
                close_driver_shift(
                    shift=open_shift,
                    employee=access.employee,
                    readings=readings,
                    client_action_id=resolved_client_action_id,
                    confirmation_token=form.cleaned_data.get('reading_confirmation_token') or '',
                    occurred_at=occurred_at,
                    actor_access_id=access.pk,
                    request_signature=request_signature,
                )
        except DriverShiftCloseConfirmationRequired as confirmation:
            warning_payload = {
                'ok': False,
                'error': 'Проверьте подозрительные показания и подтвердите их.',
                'confirmation_required': True,
                'confirmation_token': confirmation.confirmation_token,
                'warnings': confirmation.warnings,
                'client_action_id': resolved_client_action_id,
                'shift_id': open_shift.pk,
                'has_active_shift': True,
            }
            if wants_json:
                return JsonResponse(warning_payload, status=422)
            request._driver_close_confirmation = warning_payload
        except DriverShiftCloseIdempotencyConflict as error:
            return idempotency_conflict_response(error)
        except ValidationError as error:
            form.add_error(None, error)
        else:
            if wants_json:
                return JsonResponse({
                    'ok': True,
                    'status': 'applied',
                    'shift_id': open_shift.pk,
                    'client_action_id': resolved_client_action_id,
                    'redirect_url': f"{reverse('driver_work')}?tab=manifest",
                })
            messages.success(request, 'Смена закрыта.')
            return redirect(f"{reverse('driver_work')}?tab=manifest")
    if wants_json:
        field_errors = {
            field_name: [str(message) for message in error_list]
            for field_name, error_list in form.errors.items()
        }
        first_error = next(
            (
                str(message)
                for error_list in form.errors.values()
                for message in error_list
            ),
            'Проверьте показания на конец смены.',
        )
        return JsonResponse({
            'ok': False,
            'error': first_error,
            'field_errors': field_errors,
            'confirmation_required': False,
            'shift_id': open_shift.pk,
            'has_active_shift': True,
        }, status=422)
    request.GET = request.GET.copy()
    request.GET['tab'] = 'shift'
    return driver_shift_view(request)


DRIVER_QUICK_REASONS_MIN = 3


def driver_quick_reason_ids_for(access, reasons):
    """Личный набор причин для барабана: только существующие для этого водителя,
    без дублей, в порядке справочника. Короче минимума — считается незаданным."""
    available = [reason.id for reason in reasons]
    raw = access.driver_quick_reasons if isinstance(access.driver_quick_reasons, list) else []
    chosen = set()
    for value in raw:
        try:
            chosen.add(int(value))
        except (TypeError, ValueError):
            continue
    ids = [reason_id for reason_id in available if reason_id in chosen]
    if len(ids) < DRIVER_QUICK_REASONS_MIN:
        return []
    return ids


@require_POST
def driver_quick_reasons_view(request):
    """Сохранить личный набор причин простоя для барабана водителя."""
    access_id = request.session.get('employee_access_id')
    if not access_id:
        return JsonResponse({'ok': False, 'error': 'Нет доступа к экрану водителя.'}, status=403)
    access = EmployeeAccess.objects.select_related('employee', 'role').filter(id=access_id, is_active=True).first()
    if not access or access.role.code != 'driver':
        return JsonResponse({'ok': False, 'error': 'Нет доступа к экрану водителя.'}, status=403)
    payload = driver_json_payload(request)
    raw_ids = payload.get('reason_ids') if isinstance(payload, dict) else None
    if raw_ids is None and hasattr(payload, 'getlist'):
        raw_ids = payload.getlist('reason_ids')
    if isinstance(raw_ids, str):
        raw_ids = [part for part in raw_ids.split(',') if part.strip()]
    if not isinstance(raw_ids, (list, tuple)):
        raw_ids = []
    available = list(DowntimeReason.for_workplace('truck_driver'))
    available_ids = {reason.id for reason in available}
    chosen = set()
    for value in raw_ids:
        try:
            reason_id = int(value)
        except (TypeError, ValueError):
            continue
        if reason_id in available_ids:
            chosen.add(reason_id)
    ids = [reason.id for reason in available if reason.id in chosen]
    if ids and len(ids) < DRIVER_QUICK_REASONS_MIN:
        return JsonResponse({
            'ok': False,
            'error': f'В барабане должно быть не меньше {DRIVER_QUICK_REASONS_MIN} причин.',
            'min': DRIVER_QUICK_REASONS_MIN,
        }, status=422)
    access.driver_quick_reasons = ids
    access.driver_quick_reasons_updated_at = timezone.now()
    access.save(update_fields=['driver_quick_reasons', 'driver_quick_reasons_updated_at'])
    return JsonResponse({
        'ok': True,
        'reason_ids': ids,
        'updated_at': access.driver_quick_reasons_updated_at.isoformat(),
        'min': DRIVER_QUICK_REASONS_MIN,
    })


@transaction.atomic
def driver_downtime_action_view(request):
    wants_json = driver_wants_json(request)
    access_id = request.session.get('employee_access_id')
    if not access_id:
        if wants_json:
            return JsonResponse({'ok': False, 'error': 'Нет доступа к экрану водителя.'}, status=403)
        return redirect('login')
    access = EmployeeAccess.objects.select_related('employee', 'role').filter(id=access_id, is_active=True).first()
    if not access or access.role.code != 'driver':
        if wants_json:
            return JsonResponse({'ok': False, 'error': 'Нет доступа к экрану водителя.'}, status=403)
        return redirect('role_home')


    if request.method != 'POST':
        if wants_json:
            return JsonResponse({'ok': False, 'error': 'Некорректный метод действия простоя.'}, status=405)
        return redirect(f'{reverse("driver_work")}?tab=downtimes')

    Employee.objects.select_for_update().get(pk=access.employee_id)
    if not role_session_state(request, access)['is_active']:
        if wants_json:
            return JsonResponse(
                {
                    'ok': False,
                    'error': 'Роль неактивна — доступен только просмотр',
                    'code': 'inactive_role',
                },
                status=409,
            )
        messages.error(request, 'Роль неактивна — доступен только просмотр.')
        return redirect(f'{reverse("driver_work")}?tab=downtimes')

    open_shift = (
        driver_open_shift_queryset(access.employee)
        .select_for_update(of=('self',))
        .select_related('equipment', 'equipment__equipment_type')
        .order_by('-opened_at')
        .first()
    )
    if not open_shift or not open_shift.equipment:
        if wants_json:
            return JsonResponse({'ok': False, 'error': 'Нельзя зафиксировать простой: открытая смена с самосвалом не найдена.'}, status=409)
        messages.error(request, 'Нельзя зафиксировать простой: открытая смена с самосвалом не найдена.')
        return redirect(f'{reverse("driver_work")}?tab=downtimes')

    payload = driver_json_payload(request)
    action = (payload.get('action') or '').strip()
    locked_equipment = Equipment.objects.select_for_update().get(pk=open_shift.equipment_id)
    open_shift.equipment = locked_equipment
    if action == 'close':
        active_event = (
            DowntimeEvent.objects
            .select_for_update(of=('self',))
            .select_related('reason', 'reason__equipment_state')
            .filter(equipment=open_shift.equipment, ended_at__isnull=True)
            .order_by('-started_at')
            .first()
        )
        if active_event:
            active_event.ended_at = timezone.now()
            active_event.save(update_fields=['ended_at'])
            if wants_json:
                return JsonResponse(driver_downtime_event_payload(active_event, action='downtime_closed', closed=True, shift=open_shift))
        else:
            if wants_json:
                response_payload = {
                    'ok': True,
                    'active': False,
                    'closed': False,
                    'elapsed_seconds': 0,
                    'elapsed_label': '00:00:00',
                }
                response_payload.update(
                    driver_downtime_totals_payload(open_shift.equipment, open_shift)
                )
                return JsonResponse(response_payload)
            messages.error(request, 'Активный простой не найден.')
        return redirect(f'{reverse("driver_work")}?tab=downtimes')

    reason_id = payload.get('reason_id')
    reason = DowntimeReason.for_workplace('truck_driver', open_shift.equipment.equipment_type).filter(id=reason_id).first()
    if not reason:
        if wants_json:
            return JsonResponse({'ok': False, 'error': 'Причина простоя не найдена.'}, status=400)
        messages.error(request, 'Причина простоя не найдена.')
        return redirect(f'{reverse("driver_work")}?tab=downtimes')
    workflow = driver_downtime_flow(reason)
    # Гружёный / пустой самосвал и точка рейса — общие правила driver_workflow.
    start_conflict = driver_downtime_start_conflict(reason, open_shift.equipment)
    if start_conflict:
        code, error = start_conflict
        if wants_json:
            return JsonResponse(
                {
                    'ok': False,
                    'error': error,
                    'code': code,
                    'workflow': workflow,
                },
                status=409,
            )
        messages.error(request, error)
        return redirect(f'{reverse("driver_work")}?tab=downtimes')
    active_event = (
        DowntimeEvent.objects
        .select_for_update(of=('self',))
        .select_related('reason', 'reason__equipment_state')
        .filter(equipment=open_shift.equipment, ended_at__isnull=True)
        .order_by('-started_at')
        .first()
    )
    if active_event:
        if active_event.employee_id != access.employee_id:
            error = (
                'Этот непрерывный простой уже начат другим сотрудником. '
                'Сменщик может завершить его, но не менять причину или автора.'
            )
            if wants_json:
                return JsonResponse(
                    {'ok': False, 'error': error, 'code': 'transferred_downtime_read_only'},
                    status=409,
                )
            messages.error(request, error)
            return redirect(f'{reverse("driver_work")}?tab=downtimes')
        if active_event.reason_id == reason.id:
            # Re-selecting the current reason must not reset its timer.
            event = active_event
            action_label = 'downtime_unchanged'
        else:
            switched_at = timezone.now()
            active_event.ended_at = switched_at
            active_event.save(update_fields=['ended_at'])
            event = DowntimeEvent.objects.create(
                equipment=open_shift.equipment,
                employee=access.employee,
                reason=reason,
                started_at=switched_at,
                comment='Зафиксировано водителем самосвала',
            )
            action_label = 'downtime_switched'
    else:
        event = DowntimeEvent.objects.create(
            equipment=open_shift.equipment,
            employee=access.employee,
            reason=reason,
            started_at=timezone.now(),
            comment='Зафиксировано водителем самосвала',
        )
        action_label = 'downtime_started'
    if wants_json:
        return JsonResponse(driver_downtime_event_payload(event, action=action_label, shift=open_shift))
    if driver_downtime_opens_work(reason):
        return redirect(f'{reverse("driver_work")}?tab=work')
    return redirect(f'{reverse("driver_work")}?tab=downtimes')

# Create your views here.
